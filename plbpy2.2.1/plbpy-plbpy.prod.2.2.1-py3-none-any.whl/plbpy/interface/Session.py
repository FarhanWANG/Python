"""
Session creates an API configuration object and stores a client that has access to the relevant endpoints
"""

from __future__ import annotations

__all__ = ["Session"]

from plbpy.core.loader.SessionLoader import SessionLoader
from plbpy import logger, console, log_factory, DEBUG, INFO


class Session:
    @log_factory(logger, DEBUG)
    def __init__(self, api_key: str, api_secret: str, **kwargs) -> None:
        """Constructor

        :param api_key: API Key provided by PremiaLab
        :type api_key: str
        :param api_secret: API Secret provided by PremiaLab
        :type api_secret: str
        """
        # Keyword Arguments for future-proofing
        self.kwargs: dict = kwargs
        self.__loader = SessionLoader(api_key, api_secret, kwargs)

    @property
    def api_key(self) -> str:
        """Gets the API Key saved in session

        :rtype: str
        """
        return self.__loader.key

    @property
    def api_secret(self) -> str:
        """Gets the API Secret saved in session

        :rtype: str
        """
        return self.__loader.secret

    @property
    def token_expiry(self) -> int:
        """Gets the expiration

        :rtype: int
        """
        return self.__loader.token_expiry

    @property
    def access_token(self):
        """
        Gets the bearer access token
        """
        return self.__loader.access_token

    def _validate_configuration(self):
        """Validates configuration input before calling the API
        """
        return self.__loader.validate_configuration()

    @log_factory(logger, DEBUG)
    def initialize(self):

        """Initialize the session.
        Additional parameters can be added here if required
        """
        return self.__loader.validate_configuration()

