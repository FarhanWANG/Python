"""
This  module is integrated with :func:`~plbpy.interface.Universe` Universe module, accessible via mylab property.
Use this to upload your private tracks to the web platform and/or update the current private tracks
"""


from __future__ import annotations

__all__ = ["MyLab"]

from plbpy.interface import Universe
from plbpy.core.loader.MyLabLoader import MyLabLoader
from plbpy.interface.Session import Session
from plbpy import session as _gl_session

class MyLab:
    def __init__(self, universe: Universe, get_info=[], session: Session = _gl_session) -> None:
        """Constructor

        Initialises a MyLab module.

        :param universe: plbpy.Universe object
        :param session: plbpy.Session object

        .. note::

            It is recommended to use this class directly via the :func:`~plbpy.interface.Universe` Universe module for ease of access

        """

        self.session = session
        self.universe = universe
        self.__loader = MyLabLoader(session=self.session, universe=self.universe, get_info=get_info)

    def upload_private_tracks(self,input_track, static_info=[], track_type='price'):
        """
        Accepts a private track and uploads to user account

        .. note::

            - Pandas dataframe as input tracks is recommended over excel files.
            - A list of dictionaries is recommended for static info

        .. tip::

            Re-initialize the universe object to for the change to be reflected. Use plb.Universe()


        :param input_track: Pandas DataFrame containing tracks with dates as index and asset names as columns or path of excel
        :param track_type: Indicator whether your track values are Prices or Returns.
        :param static_info: A list of dictionaries that contain static information for tracks in the uploaded file or a pandas DataFrame

        :type input_track: str , pd.DataFrame
        :type track_type: str
        :type static_info: list, str , pd.DataFrame

        :raises AssertionError: if index is not YYY-MM-DD date
        :raises AssertionError: if track values are not numerical values
        :raises AssertionError: if there is no "name" key in static info dictionary

        :return: The current universe object.
        :rtype: Universe

        Example:

        >>> static_info = [
            {"name": "Track1", "assetClass" : "Equity", "region":"US", "style":"alpha"},
            {"name": "Track1", "assetClass" : "Equity", "region":"US", "style":"alpha"}
            ]

        >>> plb.universe.upload_private_tracks(df,static_info, 'price', )


        """
        return self.__loader.upload_private_tracks(input_track=input_track, track_type=track_type, static_info=static_info)


    def update_private_tracks(self, static_info: dict=None, input_track = None, reference_type:str=None):
        """
        Update metadata and/or timeseries of already uploaded private tracks

        .. note::

            - Current version only accepts track code as reference type; accessible via plb.universe.codes
            - When updating timeseries, dataframe headers should include the codes
            - reference type must specified either as a part of static info dictionaries or as argument

        .. tip::

            Re-initialize the universe object to for the change to be reflected. Use plb.Universe()

        :param static_info: Dictionary containing static information
        :type static_info: list

        :param input_track: Pandas DataFrame containing tracks with dates as index and asset CODES as columns or path of excel
        :type input_track: str , pd.DataFrame

        :param reference_type: Should be either None or "Code". More reference types will be accepted in future versions
        :type reference_type: str

        :raises AssertionError: if static info is not list
        :raises AssertionError: if index is not YYY-MM-DD date
        :raises AssertionError: if track values are not numerical values
        :raises AssertionError: if current universe object does not contain the tracks being updated


        :return: The current universe object
        :rtype: Universe

        Example:

        >>> static_info = [
            {"reference": "xyz", "assetClass" : "Equity", "region":"US", "style":"alpha"}
            ]

        >>> plb.universe.update_private_tracks(static_info, reference_type='Code' )

        """
        return self.__loader.update_private_tracks(static_info=static_info, input_track=input_track, reference_type=reference_type)


    def view_private_tracks(self):
        """
        View details of tracks that have been uploaded previously.
        Important Information accessible:
            - static information such as internal reference, ric, isin etc
            - dates corresponding to initial upload, history start date, date of last update

        :return: A pandas datframe with details about private track upload history
        :rtype: pandas DataFrame
        """

        return self.__loader.view_private_tracks()

    def delete_private_tracks(self, references:list):
        """
        DELETE specified private tracks

        .. tip::

            Re-initialize the universe object to for the change to be reflected. Use plb.Universe()


        """

        return self.__loader.delete_private_tracks(references=references)

    @property
    def info(self):
        """
        Access the 'get' output JSON, 'put' input JSON and 'post' input JSON objects

        .. note ::

            For all requests expect GET, the info object will represent the more recent calls made

        """
        return self.__loader.info

    # ---------------------- To be deprecated ------------------------

    def update_metadata(self, static_info: dict, input_track, reference_type):
        """
        Update metadata and/or timeseries of already uploaded private tracks

        .. warning::

            This function will be deprecated in future versions. Please use :func:`update_private_tracks` instead


        .. note::

            - Current version only accepts track code as reference type; accessible via plb.universe.codes
            - When updating timeseries, dataframe headers should include the codes
            - reference type must specified either as a part of static info dictionaries or as argument


        :param static_info: Dictionary containing static information
        :type static_info: list

        :param input_track: Pandas DataFrame containing tracks with dates as index and asset CODES as columns or path of excel
        :type input_track: str , pd.DataFrame

        :param reference_type: Should be either None or "Code". More reference types will be accepted in future versions
        :type reference_type: str

        :raises AssertionError: if static info is not list
        :raises AssertionError: if index is not YYY-MM-DD date
        :raises AssertionError: if track values are not numerical values
        :raises AssertionError: if current universe object does not contain the tracks being updated

        :return: The current universe object
        :rtype: Universe

        Example:

        >>> static_info = [
            {"reference": "xyz", "assetClass" : "Equity", "region":"US", "style":"alpha"}
            ]

        >>> plb.universe.update_private_tracks(static_info, reference_type='Code' )

        """
        self.__loader.update_private_tracks(static_info=static_info, input_track=input_track,
                                            reference_type=reference_type)
        return self.universe
