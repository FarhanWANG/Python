"""
Universe pulls and stores metadata available to a user in memory and provides pre-built filter methods to filter the universe. Host of convenience methods available such as translation of Data Objects to a pandas DataFrame
"""
from __future__ import annotations

__all__ = ["Universe"]

from typing import Iterable, List, Union, Callable

import numpy as np
import pandas as pd

from plbpy.interface.Session import Session

from plbpy import session as _gl_session

from plbpy.utility.date_utils import to_date, date, datetime
from plbpy import log_factory, DEBUG, logger, console
from functools import wraps
from plbpy.core.loader.UniverseLoader import UniverseLoader
from plbpy.utility.string_utils import to_camel_case


class __Filter__(object):

    @staticmethod
    def _filter_metrics(info, codes):
        return [{ 'period': i['period'],
                  'startDate': i['startDate'],
                  'endDate': i['endDate'],
                  'metrics': [k for k in i['metrics'] if k['instruments']['reference'] in codes]}
         for i in info]

    @staticmethod
    def _filter_get_info(info, codes):
        return [i for i in info if i['instrument']['reference'] in codes]

    @classmethod
    def category_filter(cls, fn) -> Callable:
        @wraps(fn)
        def _filter(obj, *args: str) -> Universe:
            """Filter Docstring"""
            arguments = np.unique(np.array(args, dtype=str).flatten())  # noqa
            assert len(obj.data) != 0, console.info(
                f"No more objects to subset. Please check filter sequence before "
                f"{fn.__name__}({arguments})"
            )

            key = to_camel_case(fn.__name__) if fn.__name__ != 'global_category' else 'globalCat'

            input_static_info = [info for info in obj.data if info[key] in arguments]

            filtered_universe = Universe(metadata=input_static_info)

            if len(input_static_info) != 0 and obj._metrics is not None:
                fixed_metrics_info = cls._filter_metrics(obj.metrics.info['fixed'], filtered_universe.codes)
                custom_metrics_info = cls._filter_metrics(obj.metrics.info['custom'], filtered_universe.codes) if len(obj.metrics.info['custom']) != 0 else []
                filtered_universe = filtered_universe._set_metrics(fixed=fixed_metrics_info, custom=custom_metrics_info)

            if obj._mylab is not None:
                get_info = cls._filter_get_info(obj._mylab.info['get'], filtered_universe.codes) if len(obj._mylab.info['get']) != 0 else []
                filtered_universe = filtered_universe._set_mylab(get_info=get_info)

            return filtered_universe

        @wraps(fn)
        def _primary_benchmark_filter(obj, *args) -> Universe:
            arguments = np.unique(np.array(args, dtype=str).flatten())
            assert len(obj.data) !=0, console.info(
                f"No more objects to subset. Please check filter sequence before "
                f"{fn.__name__}({arguments})"
            )
            key1 = 'benchmarks'
            key2 = 'primary_prospectus_benchmarks'
            anchor = fn.__name__.split('_')[-1]
            input_static_info = [info for info in obj.data if info[key1] is not None and key2 in list(info[key1].keys()) and info[key1][key2][0][anchor] in arguments]

            filtered_universe = Universe(metadata=input_static_info)
            if len(input_static_info) != 0 and obj._metrics is not None:
                fixed_metrics_info = cls._filter_metrics(obj.metrics.info['fixed'], filtered_universe.codes)
                custom_metrics_info = cls._filter_metrics(obj.metrics.info['custom'], filtered_universe.codes) if len(obj.metrics.info['custom']) != 0 else []
                filtered_universe = filtered_universe._set_metrics(fixed=fixed_metrics_info, custom=custom_metrics_info)

            if obj._mylab is not None:
                get_info = cls._filter_get_info(obj._mylab.info['get'], filtered_universe.codes) if len(obj._mylab.info['get']) != 0 else []
                filtered_universe = filtered_universe._set_mylab(get_info=get_info)

            return filtered_universe

        @wraps(fn)
        def _ucits_filter(obj, *args: str) -> Universe:
            arguments = np.unique(np.array(args, dtype=str).flatten())
            assert len(obj.data) != 0, console.info(
                f"No more objects to subset. Please check filter sequence before "
                f"{fn.__name__}({arguments})"
            )
            assert len(arguments) == 1, "filter can either be yes OR no"
            assert arguments[0].lower() in ['yes', 'no'], "filter can either be yes OR no"

            if arguments[0].lower() == 'yes':
                input_static_info = [info for info in obj.data if info['ucits'] == 1]

            elif arguments[0].lower() == 'no':
                input_static_info = [info for info in obj.data if info['ucits'] == 0]

            filtered_universe = Universe(metadata=input_static_info)
            if len(input_static_info) != 0 and obj._metrics is not None:
                fixed_metrics_info = cls._filter_metrics(obj.metrics.info['fixed'], filtered_universe.codes)
                custom_metrics_info = cls._filter_metrics(obj.metrics.info['custom'], filtered_universe.codes) if len(obj.metrics.info['custom']) != 0 else []
                filtered_universe = filtered_universe._set_metrics(fixed=fixed_metrics_info, custom=custom_metrics_info)

            if obj._mylab is not None:
                get_info = cls._filter_get_info(obj._mylab.info['get'], filtered_universe.codes) if len(obj._mylab.info['get']) != 0 else []
                filtered_universe = filtered_universe._set_mylab(get_info=get_info)

            return filtered_universe


        @wraps(fn)
        def _remove_filter(obj, *args: str) -> Universe:
            """Remove Codes"""
            arguments: List[str] = list(
                set(np.array(args, dtype=str).flatten().tolist())
            )  # noqa
            assert len(obj.data) != 0, console.info(
                f"No more objects to subset. Please check filter sequence before "
                f"{fn.__name__}({arguments})"
            )

            input_static_info = [info for info in obj.data if info['code'] not in arguments]

            filtered_universe = Universe(metadata=input_static_info)
            if len(input_static_info) != 0 and obj._metrics is not None:
                fixed_metrics_info = cls._filter_metrics(obj.metrics.info['fixed'], filtered_universe.codes)
                custom_metrics_info = cls._filter_metrics(obj.metrics.info['custom'], filtered_universe.codes) if len(obj.metrics.info['custom']) != 0 else []
                filtered_universe = filtered_universe._set_metrics(fixed=fixed_metrics_info, custom=custom_metrics_info)

            if obj._mylab is not None:
                get_info = cls._filter_get_info(obj._mylab.info['get'], filtered_universe.codes) if len(obj._mylab.info['get']) != 0 else []
                filtered_universe = filtered_universe._set_mylab(get_info=get_info)

            return filtered_universe

        @wraps(fn)
        def _find_filter(obj, *args: str) -> Universe:
            arguments = list(map(lambda x: x.lower(), np.unique(np.array(args, dtype=str).flatten())))
            assert len(obj.data) != 0, console.info(
                f"No more objects to subset. Please check filter sequence before "
                f"{fn.__name__}({arguments})"
            )
            input_static_info = []
            for arg in arguments:
                input_static_info += [
                    info
                    for info in obj.data
                    if (arg in info['assetClass'].lower())
                    or (arg in info['code'].lower())
                    or (arg in info['currency'].lower())
                    or (arg in info['factor'].lower())
                    or (arg in info['provider'].lower())
                    or (arg in info['shortName'].lower())
                    or (arg in info['type'].lower())
                    or (arg in info['style'].lower())
                ]

            filtered_universe = Universe(metadata=input_static_info)
            if len(input_static_info) != 0 and obj._metrics is not None:
                fixed_metrics_info = cls._filter_metrics(obj.metrics.info['fixed'], filtered_universe.codes)
                custom_metrics_info = cls._filter_metrics(obj.metrics.info['custom'], filtered_universe.codes) if len(obj.metrics.info['custom']) != 0 else []
                filtered_universe = filtered_universe._set_metrics(fixed=fixed_metrics_info, custom=custom_metrics_info)

            if obj._mylab is not None:
                get_info = cls._filter_get_info(obj._mylab.info['get'], filtered_universe.codes) if len(obj._mylab.info['get']) != 0 else []
                filtered_universe = filtered_universe._set_mylab(get_info=get_info)

            return filtered_universe

        if fn.__name__ == "remove":
            return _remove_filter
        elif fn.__name__ == "find":
            return _find_filter
        elif fn.__name__ == 'ucits':
            return _ucits_filter
        elif fn.__name__ == 'primary_benchmark_name' or fn.__name__ == 'primary_benchmark_id':
            return _primary_benchmark_filter
        else:
            return _filter

    @classmethod
    def date_filter(cls, var: str) -> Callable:
        def _date_filter(fn):
            @wraps(fn)
            def before_filter(obj, date_str: str) -> Universe:
                """Filters universe available before a date"""
                assert len(obj.data) != 0, (
                    f"No more objects to subset. Please check filter sequence before "
                    f"{fn.__name__}({date_str})"
                )

                key = to_camel_case(var)
                input_static_info = [info for info in obj.data if to_date(info[key]) <= to_date(date_str)]
                filtered_universe = Universe(metadata=input_static_info)
                if len(input_static_info) != 0 and obj._metrics is not None:
                    fixed_metrics_info = cls._filter_metrics(obj.metrics.info['fixed'], filtered_universe.codes)
                    custom_metrics_info = cls._filter_metrics(obj.metrics.info['custom'],
                                                              filtered_universe.codes) if len(
                        obj.metrics.info['custom']) != 0 else []
                    filtered_universe = filtered_universe._set_metrics(fixed=fixed_metrics_info,
                                                                       custom=custom_metrics_info)

                if obj._mylab is not None:
                    get_info = cls._filter_get_info(obj._mylab.info['get'], filtered_universe.codes) if len(
                        obj._mylab.info['get']) != 0 else []
                    filtered_universe = filtered_universe._set_mylab(get_info=get_info)

                return filtered_universe

            @wraps(fn)
            def after_filter(obj, date_str: str) -> Universe:
                """Filters universe available after a date"""
                assert len(obj.data) != 0, (
                    f"No more objects to subset. Please check filter sequence before "
                    f"{fn.__name__}({date_str})"
                )
                key = to_camel_case(var)
                input_static_info = [info for info in obj.data if to_date(info[key]) >= to_date(date_str)]
                filtered_universe = Universe(metadata=input_static_info)
                if len(input_static_info) != 0 and obj._metrics is not None:
                    fixed_metrics_info = cls._filter_metrics(obj.metrics.info['fixed'], filtered_universe.codes)
                    custom_metrics_info = cls._filter_metrics(obj.metrics.info['custom'],
                                                              filtered_universe.codes) if len(
                        obj.metrics.info['custom']) != 0 else []
                    filtered_universe = filtered_universe._set_metrics(fixed=fixed_metrics_info,
                                                                       custom=custom_metrics_info)

                if obj._mylab is not None:
                    get_info = cls._filter_get_info(obj._mylab.info['get'], filtered_universe.codes) if len(
                        obj._mylab.info['get']) != 0 else []
                    filtered_universe = filtered_universe._set_mylab(get_info=get_info)

                return filtered_universe

            return before_filter if "before" in fn.__name__ else after_filter

        return _date_filter


class Universe:
    def __init__(
        self,
        session: Session = _gl_session,
        metadata: Iterable[dict] = None,
        **kwargs,
    ) -> None:
        """Constructor

        :param session: The current session object provided
        :type session: Session
        :param metadata: List of Static Information objects, defaults to None
        :type metadata: List[api.StaticInfoResponse], optional
        """

        self.session = session
        self.data = metadata

        self._metrics = None
        self._mylab = None

        self.__loader = UniverseLoader(self.session, metadata=self.data)
        self._metrics = None

        if self.data is None:
            self.data = self.__loader.metadata

        logger.debug("Success")

    @property
    def data(self) -> dict:
        """
        Access raw data of the current universe object

        :return: a list of raw data
        :rtype: dict

        """
        return self._data

    @data.setter
    def data(self, value):
        self._data = value

    # Filters
    @log_factory(logger, DEBUG)
    @__Filter__.category_filter
    def provider(self, *providers) -> Universe:
        """Filters universe based on strategy providers

        :param providers:
            Data providers
        :type provders:
            Union[str, List[str]]

        Filtering one provider

        >>> plbpy.Universe(session).provider("PremiaLab")

        Filtering a list of providers

        >>> plbpy.Universe(session).provider("PremiaLab", "Societe Generale")
        """
        pass

    @log_factory(logger, DEBUG)
    @__Filter__.category_filter
    def currency(self, *currencies) -> Universe:
        """Filters universe based on currencies

        :param currencies:
            Strategy Base Currency
        :type currencies:
            Union[str, List[str]]

        Filtering one factor

        >>> plbpy.Universe(session).currency("USD")

        Filtering a list of factors

        >>> plbpy.Universe(session).currency("USD", "EUR")
        """
        pass

    @log_factory(logger, DEBUG)
    @__Filter__.category_filter
    def type(self, *types) -> Universe:
        """Filters universe based on type

        :param types:
            Type of time series
        :type type:
            Union[str, List[str]]

        Filtering one type

        >>> plbpy.Universe(session).type("Strategy")

        Filtering a list of types

        >>> plbpy.Universe(session).type("Strategy", "Benchmark")
        """
        pass

    @log_factory(logger, DEBUG)
    @__Filter__.category_filter
    def style(self, *styles) -> Universe:
        """Filters universe based on style

        :param styles:
            Style of time series
        :type styles:
            Union[str, List[str]]

        Filtering one style

        >>> plbpy.Universe(session).style("Alpha")

        Filtering a list of styles

        >>> plbpy.Universe(session).style("Alpha", "Smart Beta")
        """
        pass

    @log_factory(logger, DEBUG)
    @__Filter__.category_filter
    def factor(self, *factors) -> Universe:
        """Filters universe based on factor

        :param factors:
            Underlying factor of a strategy
        :type factors:
            Union[str, List[str]]

        Filtering one factor

        >>> plbpy.Universe(session).factor("Momentum")

        Filtering a list of factors

        >>> plbpy.Universe(session).factor("Momentum", "Value")
        """
        pass

    @log_factory(logger, DEBUG)
    @__Filter__.category_filter
    def asset_class(self, *assetclasses) -> Universe:
        """Filters universe based on asset class

        :param assetclasses:
            Underlying asset class of a strategy
        :type assetclasses:
            Union[str, List[str]]

        Filtering one asset class

        >>> plbpy.Universe(session).asset_class("Equity")

        Filtering a list of asset classes

        >>> plbpy.Universe(session).asset_class("Equity", "Commodity")
        """
        pass

    @log_factory(logger, DEBUG)
    @__Filter__.category_filter
    def return_type(self, *returntype) -> Universe:
        """Filters universe based on return type

        :param returntype:
            returntype of a strategy
        :type returntype:
            Union[str, List[str]]

        Filtering to only include Total Return strategies

        >>> plbpy.Universe(session).return_type("Total Return")

        """
        pass


    @log_factory(logger, DEBUG)
    @__Filter__.category_filter
    def region(self, *regions) -> Universe:
        """Filters universe based on region

        :param regions:
            Underlying region of a strategy
        :type regions:
            Union[str, List[str]]

        Filtering one region

        >>> plbpy.Universe(session).region("US")

        Filtering a list of regions

        >>> plbpy.Universe(session).region("US", "Europe")
        """
        pass

    @log_factory(logger, DEBUG)
    @__Filter__.category_filter
    def legal_structure(self, *legal_structure) -> Universe:
        """Filters universe based on legal structure

        :param legal_structure:
            Underlying legal strucutures of a strategy
        :type legal_structure:
            Union[str, List[str]]

        """
        pass

    @log_factory(logger, DEBUG)
    @__Filter__.category_filter
    def dividend_frequency(self, *dividend_frequency) -> Universe:
        """Filters universe based on dividend frequency

        :param dividend_frequency:
            dividend_frequency of a fund
        :type dividend_frequency:
            Union[str, List[str]]

        """
        pass

    @log_factory(logger, DEBUG)
    @__Filter__.category_filter
    def domicile(self, *domicile) -> Universe:
        """Filters universe based on domicile

        :param domicile:
            domicile of a fund
        :type domicile:
            Union[str, List[str]]

        """
        pass

    @log_factory(logger, DEBUG)
    @__Filter__.category_filter
    def global_category(self, *global_category) -> Universe:
        """Filters universe based on the global category

        :param global_category:
            global_category of a fund
        :type global_category:
            Union[str, List[str]]

        """
        pass

    @log_factory(logger, DEBUG)
    @__Filter__.category_filter
    def ucits(self, *ucits) -> Universe:
        """Filters universe based on ucits labeling of funds

        :param ucits:
            yes or no
        :type ucits:
            str

        """
        pass

    @log_factory(logger, DEBUG)
    @__Filter__.category_filter
    def primary_benchmark_id(self, *benchmark_id) -> Universe:
        """Filters universe based on the benchmark of funds

        :param benchmark_id:
            benchmark id of the fund
        :type benchmark_id:
            Union(str, List[str])

        """
        pass

    @log_factory(logger, DEBUG)
    @__Filter__.category_filter
    def primary_benchmark_name(self, *benchmark_name) -> Universe:
        """Filters universe based on the benchmark of funds

        :param benchmark_name:
            benchmark name of the fund
        :type benchmark_name:
            Union(str, List[str])

        """
        pass

    @log_factory(logger, DEBUG)
    @__Filter__.date_filter("history_start_date")
    def before(self, date: Union[str, datetime, date]) -> Universe:
        """Filters universe that has a history start date before the input date

        :param date:
            Date. If str, the string format must be YYYY-MM-DD
        :type date:
            Union[str, datetime, date]

        Filtering strategies published before 2010-01-01

        >>> plbpy.Universe(session).before("2010-01-01")
        """
        pass

    @log_factory(logger, DEBUG)
    @__Filter__.date_filter("history_start_date")
    def after(self, date: Union[str, datetime, date]) -> Universe:
        """Filters universe that has a history start date after the input date

        :param date:
            Date. If str, the string format must be YYYY-MM-DD
        :type date:
            Union[str, datetime, date]

        Filtering strategies published after 2010-01-01

        >>> plbpy.Universe(session).after("2010-01-01")
        """
        pass

    @log_factory(logger, DEBUG)
    def history_after(self, date: Union[str, datetime, date]) -> Universe:
        """Filters universe that has a history start date after the input date

        :param date:
            Date. If str, the string format must be YYYY-MM-DD
        :type date:
            Union[str, datetime, date]

        Filtering strategies published after 2010-01-01

        >>> plbpy.Universe(session).after("2010-01-01")
        """
        return self.after(date)

    @log_factory(logger, DEBUG)
    def history_before(self, date: Union[str, datetime, date]) -> Universe:
        """Filters universe that has a history start date before the input date

        :param date:
            Date. If str, the string format must be YYYY-MM-DD
        :type date:
            Union[str, datetime, date]

        Filtering strategies published before 2010-01-01

        >>> plbpy.Universe(session).before("2010-01-01")
        """
        return self.before(date)

    @log_factory(logger, DEBUG)
    @__Filter__.date_filter("inception_date")
    def inception_after(self, date: Union[str, datetime, date]) -> Universe:
        """Filters universe that has an inception start date after the input date

        :param date:
            Date. If str, the string format must be YYYY-MM-DD
        :type date:
            Union[str, datetime, date]

        Filtering strategies that traded live after 2010-01-01

        >>> plbpy.Universe(session).inception_after("2010-01-01")
        """
        pass

    @log_factory(logger, DEBUG)
    @__Filter__.date_filter("inception_date")
    def inception_before(self, date: Union[str, datetime, date]) -> Universe:
        """Filters universe that has an inception start date before the input date

        :param date:
            Date. If str, the string format must be YYYY-MM-DD
        :type date:
            Union[str, datetime, date]

        Filtering strategies that traded live before 2010-01-01

        >>> plbpy.Universe(session).inception_before("2010-01-01")
        """
        pass

    @log_factory(logger, DEBUG)
    @__Filter__.category_filter
    def code(self, *tickers) -> Universe:
        """Select specific input tickers from universe

        :param tickers:
            Primary identifiers of the strategy
        :type tickers:
            Union[str, List[str]]

        Filtering one strategy

        >>> plbpy.Universe(session).code("SPX")

        Filtering a list of strategies

        >>> plbpy.Universe(session).code("SPX", "SBWGU")
        """
        pass

    @__Filter__.category_filter
    def remove(self, *tickers) -> Universe:
        """Remove specific input tickers from a universe

        :param tickers:
            Primary identifiers of the strategy
        :type tickers:
            Union[str, List[str]]

        Filtering one strategy

        >>> plbpy.Universe(session).remove("SPX")

        Filtering a list of strategies

        >>> plbpy.Universe(session).remove("SPX", "SBWGU")
        """
        pass

    @log_factory(logger, DEBUG)
    @__Filter__.category_filter
    def short_name(self, *shortnames) -> Universe:
        """Filters universe based on shortname


        :param shortnames:
            Short name of a strategy
        :type shortnames:
            Union[str, List[str]]

        .. note:: The universe will be filtered on an exact match. For keyword search try :py:meth:`find`

        Filtering one strategy

        >>> plbpy.Universe(session).short_name("S&P Global 1200 Total Return")

        Filtering a list of strategies

        >>> plbpy.Universe(session).short_name("Pure Factor Commodity Carry Global", "S&P Global 1200 Total Return")
        """
        pass

    @log_factory(logger, DEBUG)
    @__Filter__.category_filter
    def find(self, *keywords) -> Universe:
        """Filters universe based on a keyword or a set of keywords.

        :param keywords:
            Keyword to search
        :type keywords:
            Union[str, List[str]]

        Filtering based on one keyword

        >>> plbpy.Universe(session).find("Merger")

        Filtering the universe based on multiple keywords

        >>> plbpy.Universe(session).find("Merger", "Intraday")

        .. note::
            The subset will be the :py:meth:`union` between each of the input keywords.

            >>> plbpy.Universe(session).find("Merger").union(
                    plbpy.Universe(session).find("Intraday")
                )
        """
        pass

    @log_factory(logger, DEBUG)
    def union(self, other: Universe) -> Universe:
        """Union between two Universe objects

        :param other: Another universe object
        :type other: Universe
        :return: Returns a union between 2 universe objects
        :rtype: Universe

        >>> plbpy.Universe(session).factor("Value").union(
                plbpy.Universe(session).factor("Momentum")
            )
        """
        input_static_info = self.data + other.data
        return Universe(metadata=input_static_info)

    # Output Objects
    def to_frame(self) -> pd.DataFrame:
        """Pandas interface to work with the universe dataset.

        The method will output a DataFrame which can be manipulated using the usual pandas methods

        :return: DataFrame object of strategy metadata
        :rtype: pd.DataFrame
        :raises AssertionError: AssertionError raised if universe is empty
        """

        return self.__loader.to_frame()

    # Getters

    @property
    def codes(self) -> List[str]:
        """Gets the list of tickers currently available in the universe

        :return:
        :rtype: List[str]
        """
        return list(map(lambda x: x["code"], self.data))


    @property
    def short_names(self) -> List[str]:
        """Gets the list of short names currently available in the universe

        :return:
        :rtype: List[str]
        """
        return list(map(lambda x: x["shortName"], self.data))

    @property
    def last_date(self) -> str:
        """Gets the date of the most recent published strategy within the universe

        :return:
        :rtype: str
        """
        return max(list(map(lambda x: x["historyStartDate"], self.data)))

    @property
    def first_date(self) -> str:
        """Gets the date of the first published strategy within the universe

        :return:
        :rtype: str
        """
        return min(list(map(lambda x: x["historyStartDate"], self.data)))

    @log_factory(logger, DEBUG)
    def tracks(self, threads=10, start=None, end=None, **kwargs):
        """Gets Historical timeseries of the strategies in the universe.

        :param threads: Number of threads to use to call the API concurrently, defaults to 10
        :type threads: int, optional
        :return: Dataframe
        :rtype: pd.DataFrame

        .. note::
            This method is designed to be a lazy evaluator, i.e, the method should only be called when the historical values are needed.
            The timeseries data will not be stored as a parameter of the Universe instance and should be stored into another variable

            >>> historical_tracks = plbpy.Universe(session).code("SPX", "SBWGU").tracks()
            >>> historical_tracks.to_frame()
        """
        return self.__loader.tracks(threads=threads, start=start, end=end, codes=self.codes, **kwargs)

    @log_factory(logger, DEBUG)
    def request_funds(self, ids: list = [], id_type: str = 'Morningstar', **kwargs):
        """
        Requests funds from Morningstar and adds them to your universe.

        :param ids: List of fund IDs to request, can be ISINs or Morningstar IDs
        :type ids: Union[str, List[str]]

        :param id_type: Type of IDs being requested. Can be either ISIN , Morningstar (Mstar/MstarID).
        :type id_type: str

        .. note::
            User will need to reinitialize the universe object to view the changes.
        
        .. warning::
            Number of funds you can request are subject to your PremiaLab subscription.

        Requesting ISIN

            >>> u = plb.universe
            >>> u.request_funds(ids = ['abc','xyz'], Type = 'ISIN')
            >>> updated_u = plb.Universe()

        Requesting Morningstar ID

            >>> u = plb.universe
            >>> plb.universe.request_funds(ids = ['abc','xyz'], Type = 'mstar')
            >>> updated_u = plb.Universe()
        
        """        

        self.__loader.request_funds(ids, id_type, **kwargs)

    def _populate_metrics(self):
        from plbpy.interface.Metrics import Metrics
        self._metrics = Metrics(universe=self)
        return self


    @property
    def metrics(self):
        """
        Access the :func:`~plbpy.interface.Metrics` metrics module for current universe

        :return: An instance of Metrics module containing the fixed period and custom period metrics
        :rtype: Metrics

        View fixed period metrics

            >>> plbpy.universe.metrics.fixed

        View 5 year metrics

            >>> plbpy.universe.fixed5y

        View custom metrics if computed

            >>> plbpy.universe.metrics.custom

        """
        if self._metrics is None:
            self._populate_metrics()
        return self._metrics

    @property
    def mylab(self):
        """
        Access the :func:`~plbpy.interface.MyLab` MyLab module. This module is used to upload and update private tracks

        :return: An instance of MyLab module

        """
        if self._mylab is None:
            from plbpy.interface.MyLab import MyLab
            self._mylab = MyLab(universe=self)
        return self._mylab

    @log_factory(logger, DEBUG)
    def compute_custom_metrics(self, start, end, return_interval='Weekly'):
        """
        Compute metrics on a user defined period. By default, Premialab offers metrics for 6M, 1Y, 3Y, 5Y and 10Y periods
        Updates the property custom of metrics property of current universe

        :param start: start date of metrics computation in YYYY-MM-DD format
        :type start: string

        :param end: end date of metrics compuatation in YYYY-MM-DD format
        :type end: string

        :param return_interval: return interval to use for computing metrics
        :type return_interval: string

        :raises AssertionError: AssertionError raised if number of assets is more than 50

        :return: None

        .. warning::
            This method is computationally expensive.
            It is recommended to use this function for a limited number of assets


        """
        self.metrics.compute_custom_metrics(start, end, return_interval)
        return self

    @log_factory(logger, DEBUG)
    def screen(self, metric, minimum=None, maximum=None, period='1Y', rank='all'):
        """
        Filter the universe based on any metric

        :param metric: the metric filtering is based on
        :type metric: string

        :param minimum: lower bound
        :type minimum: float

        :param maximum: upper bound
        :type maximum: float

        :param period: the period on which the chosen metric is compared. Valid options : 6M, 1Y, 3Y, 5Y, 10Y, custom
        :type period: string

        :param rank: top N, bottom N or all
        :type rank: string

        :return: A new universe object with assets where the target metric is within the specified bounds
        :rtype: Universe

        .. note::
            See property :py:meth:`metric options` for a list of available metrics

        Get positive performers over the past 3 years

            >>> plbpy.universe.screen(metric = "Return p.a.", minimum = 0, period='3Y')

        Get top 5 performers by info ratio over the past 5 years with a mininm info ratio of 1

            >>> plbpy.universe.screen(metric = 'Info Ratio', period='5Y', minimum=1 , rank='top 5')

        Get least 10 volatile assets in March 2020

            >>> u = plb.universe.compute_custom_metrics(start='2020-03-01', end='2020-03-31', return_interval='Daily')
            >>> u.screen(metric='Volatility', period='custom', rank='bottom 10')

        """
        screened_codes = self.metrics.screen(metric, minimum, maximum, period, rank)

        return self.code(screened_codes)

    def _set_metrics(self, fixed, custom):
        from plbpy.interface.Metrics import Metrics
        self._metrics = Metrics(universe=self, fixed=fixed, custom=custom)
        return self

    def _set_mylab(self, get_info):
        from plbpy.interface.MyLab import MyLab
        self._mylab = MyLab(universe=self, get_info=get_info)
        return self

    @property
    def metric_options(self):
        """
        Access available metrics for screening

        :return: An Options object

        .. tip::
            Press tab after adding a period to this property in order to view all metrics in a jupyter environment


        """
        return self.metrics.metric_options
    
    @log_factory(logger, DEBUG)
    def upload_private_tracks(self, input_track, static_info=[], track_type='price') -> Universe:
        """
        .. note::

             Pandas dataframe as input tracks is recommended over excel files.
             A list of dictionaries is recommended for static info

        Uploads Private Tracks
        :param input_track: Pandas DataFrame containing tracks with dates as index and asset names as columns or path of excel
        :param track_type: Indicator whether your track values are Prices or Returns.
        :param static_info: A list of dictionaries that contain static information for tracks in the uploaded file or a pandas DataFrame

        :type input_track: str , pd.DataFrame
        :type track_type: str
        :type static_info: list, str , pd.DataFrame

        :raises:
            AssertionError: if index is not YYYY-MM-DD date
            AssertionError: if track values are not numerical values
            AssertionError: if there is no "name" key in static info dictionary


        :return: The current universe object
        :rtype: Universe

        Example:

         >>> static_info = [
             {"name": "Track1", "assetClass" : "Equity", "region":"US", "style":"alpha"},
             {"name": "Track1", "assetClass" : "Equity", "region":"US", "style":"alpha"}
             ]

         >>> plb.universe.upload_private_tracks(df,static_info, 'price', )


         """

        return self.mylab.upload_private_tracks(input_track=input_track, static_info=static_info,  track_type=track_type)







