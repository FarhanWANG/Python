"""
Access metrics for assets in your universe. Immediate access for 6M, 1Y, 3Y, 5Y, 10Y periods. Also access ability to compute metrics on a custom period for a limited number of assets.
Use this module to screen and filter the universe based on these metrics.
"""
from __future__ import annotations

__all__ = ["Metrics"]

from plbpy.core.loader.MetricsLoader import MetricsLoader


class Metrics:
    def __init__(self, universe=None, fixed=None, custom=None):
        """Constructor

        Initialises a Metrics module.

        :param universe: plbpy.Universe object
        :param fixed: dictionary of fixed metrics
        :param custom: dictionary of custom metrics

        .. note::

            It is highly recommended to use this class directly via the universe module for ease of access

        """
        self.universe = universe
        self.__loader = MetricsLoader(universe=universe, fixed=fixed, custom=custom)

    def compute_custom_metrics(self, start, end, return_interval='Weekly'):
        """
        Compute metrics on a user defined period. By default, Premialab offers metrics for 6M, 1Y, 3Y, 5Y and 10Y periods
        Updates the property custom of metrics property of current universe

        :param start: start date of metrics computation in YYYY-MM-DD format
        :type start: string

        :param end: end date of metrics compuatation in YYYY-MM-DD format
        :type end: string

        :param return_interval: return interval to use for computing metrics
        :type return_interval: string

        :raises AssertionError: AssertionError raised if number of assets is more than 100

        :return: None

        .. warning::
            This method is computationally expensive. Therefore, it can only be used for a limited number of assets


        """

        return self.__loader.compute_custom_metrics(start, end, return_interval)

    # ------ cached metrics -------
    @property
    def fixed(self):
        """
        View fixed period metrics for all assets. Periods : 6M, 1Y, 3Y, 5Y, 10Y
        """
        return self.__loader.fixed

    @property
    def fixed6m(self):
        """
        View metrics for the previous 6 months from today
        """
        return self.__loader.fixed6m

    @property
    def fixed1y(self):
        """
        View metrics for the previous year from today
        """
        return self.__loader.fixed1y

    @property
    def fixed3y(self):
        """
        View metrics for the previous 3 years from today
        """
        return self.__loader.fixed3y

    @property
    def fixed5y(self):
        """
        View metrics for the previous 5 years from today
        """
        return self.__loader.fixed5y

    @property
    def fixed10y(self):
        """
        View metrics for the previous 10 years from today
        """
        return self.__loader.fixed10y

    # ---------- custom metrics

    @property
    def custom(self):
        """
        View custom period metrics for selected assets
        """
        return self.__loader.custom

    @property
    def info(self):
        """
        Extract custom and fixed metrics in a list format
        """
        return self.__loader.info

    def screen(self, metric, minimum=None, maximum=None, period='1Y', rank='all'):
        """
        Filter the universe based on any metric

        :param metric: the metric filtering is based on
        :type metric: string

        :param minimum: lower bound
        :type minimum: float

        :param maximum: upper bound
        :type maximum: float

        :param period: the period on which the chosen metric is compared. Valid options : 6M, 1Y, 3Y, 5Y, 10Y, custom
        :type period: string

        :param rank: top N, bottom N or all
        :type rank: string

        :return: A new universe object with assets where the target metric is within the specified bounds
        :rtype: Universe


        .. note::
            See property :py:meth:`metric options` for a list of available metrics

        Get positive performers over the past 3 years

            >>> plbpy.universe.screen(metric = "Return p.a.", minimum = 0, period='3Y')

        Get top 10 by info ratio over the past 5 years. With a minimum info ratio of 1

            >>> plbpy.universe.screen(metric='Info Ratio', minimum = 1, period='5Y', rank='top 10')



        """
        return self.__loader.screen(metric, minimum, maximum, period, rank)

    @property
    def metric_options(self):
        """
        Access available metrics for screening

        :return: An Options object

        .. tip::
            Press tab after adding a period to this property in order to view all metrics in a jupyter environment


        """
        return self.__loader.metric_options


    @property
    def params(self):
        """
        View time periods of various metric calculations

        :return: Dataframe

        """
        return self.__loader.params
