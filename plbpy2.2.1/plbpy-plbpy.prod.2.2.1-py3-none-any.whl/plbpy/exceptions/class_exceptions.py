class TrackAccessException(Exception):
    def __init__(self, reason=None):
        self.error = "No Historical Track Access in scope. Please contact PremiaLab"
        self.reason = reason

    def __str__(self):
        """Custom error message for exception"""
        error_message = f"{self.error}"
        if self.reason:
            error_message = f"{error_message}\nReason: {self.reason}\n"

        return error_message


class PortfolioError(Exception):
    def __init__(self, reason=None):
        self.error = "Portfolio Error"
        self.reason = reason

    def __str__(self):
        """Custom error message for exception"""
        error_message = f"{self.error}"
        if self.reason:
            error_message = f"\n{error_message}\nReason: {self.reason}\n"

        return error_message


class PortfolioValidationError(PortfolioError):
    def __init__(self, reason=None):
        self.error = "Validation Error"
        self.reason = reason

    def __str__(self):
        """Custom error message for exception"""
        error_message = f"{self.error}"
        if self.reason:
            error_message = f"\n{error_message}\nReason: {self.reason}\n"

        return error_message


class RiskDataException(Exception):
    def __init__(self, reason=None):
        self.error = "Risk Data Error"
        self.reason = reason

    def __str__(self):
        error_message = f"{self.error}"
        if self.reason:
            error_message = f"\n{error_message}\nReason: {self.reason}\n"

        return error_message


class SessionError(Exception):
    def __init__(self, reason=None):
        self.error = "Session Error"
        self.reason = reason

    def __str__(self):
        error_message = f"{self.error}"
        if self.reason:
            error_message = f"\n{error_message}\nReason: {self.reason}\n"

        return error_message


class PCAError(Exception):
    def __init__(self, reason=None):
        self.error = "PCA Error"
        self.reason = reason

    def __str__(self):
        """Custom error message for exception"""
        error_message = f"{self.error}"
        if self.reason:
            error_message = f"\n{error_message}\nReason: {self.reason}\n"

        return error_message


class PCAValidationError(PCAError):
    def __init__(self, reason=None):
        self.error = "Validation Error"
        self.reason = reason

    def __str__(self):
        """Custom error message for exception"""
        error_message = f"{self.error}"
        if self.reason:
            error_message = f"\n{error_message}\nReason: {self.reason}\n"

        return error_message


class RegressionError(Exception):
    def __init__(self, reason=None):
        self.error = "Regression Error"
        self.reason = reason

    def __str__(self):
        """Custom error message for exception"""
        error_message = f"{self.error}"
        if self.reason:
            error_message = f"\n{error_message}\nReason: {self.reason}\n"

        return error_message


class RegressionValidationError(RegressionError):
    def __init__(self, reason=None):
        self.error = "Validation Error"
        self.reason = reason

    def __str__(self):
        """Custom error message for exception"""
        error_message = f"{self.error}"
        if self.reason:
            error_message = f"\n{error_message}\nReason: {self.reason}\n"

        return error_message


class HClusterError(Exception):
    def __init__(self, reason=None):
        self.error = "HCluster Error"
        self.reason = reason

    def __str__(self):
        """Custom error message for exception"""
        error_message = f"{self.error}"
        if self.reason:
            error_message = f"\n{error_message}\nReason: {self.reason}\n"

        return error_message


class HClusterValidationError(HClusterError):
    def __init__(self, reason=None):
        self.error = "Validation Error"
        self.reason = reason

    def __str__(self):
        """Custom error message for exception"""
        error_message = f"{self.error}"
        if self.reason:
            error_message = f"\n{error_message}\nReason: {self.reason}\n"

        return error_message


class MSTError(Exception):
    def __init__(self, reason=None):
        self.error = "MST Error"
        self.reason = reason

    def __str__(self):
        """Custom error message for exception"""
        error_message = f"{self.error}"
        if self.reason:
            error_message = f"\n{error_message}\nReason: {self.reason}\n"

        return error_message


class MSTValidationError(MSTError):
    def __init__(self, reason=None):
        self.error = "Validation Error"
        self.reason = reason

    def __str__(self):
        """Custom error message for exception"""
        error_message = f"{self.error}"
        if self.reason:
            error_message = f"\n{error_message}\nReason: {self.reason}\n"

        return error_message


class DispersionError(Exception):
    def __init__(self, reason=None):
        self.error = "Dispersion Error"
        self.reason = reason

    def __str__(self):
        """Custom error message for exception"""
        error_message = f"{self.error}"
        if self.reason:
            error_message = f"\n{error_message}\nReason: {self.reason}\n"

        return error_message


class DispersionValidationError(DispersionError):
    def __init__(self, reason=None):
        self.error = "Validation Error"
        self.reason = reason

    def __str__(self):
        """Custom error message for exception"""
        error_message = f"{self.error}"
        if self.reason:
            error_message = f"\n{error_message}\nReason: {self.reason}\n"

        return error_message


class RiskError(Exception):
    def __init__(self, reason=None):
        self.error = "Risk Error"
        self.reason = reason

    def __str__(self):
        error_message = f"{self.error}"
        if self.reason:
            error_message = f"\n{error_message}\nReason: {self.reason}\n"

        return error_message


class VisualiserError(Exception):
    def __init__(self, reason=None):
        self.error = "Visualiser Error"
        self.reason = reason

    def __str__(self):
        error_message = f"{self.error}"
        if self.reason:
            error_message = f"\n{error_message}\nReason: {self.reason}\n"

        return error_message


class UniverseError(Exception):
    def __init__(self, reason=None):
        self.error = "Universe Error"
        self.reason = reason

    def __str__(self):
        error_message = f"{self.error}"
        if self.reason:
            error_message = f"\n{error_message}\nReason: {self.reason}\n"

        return error_message

class MetricsError(Exception):
    def __init__(self, reason=None):
        self.error = "Metrics Error"
class MyLabError(Exception):
    def __init__(self, reason=None):
        self.error = "Upload Error"
        self.reason = reason

    def __str__(self):
        error_message = f"{self.error}"
        if self.reason:
            error_message = f"\n{error_message}\nReason: {self.reason}\n"

        return error_message