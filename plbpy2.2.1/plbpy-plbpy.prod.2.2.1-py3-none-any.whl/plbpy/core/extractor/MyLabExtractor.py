from __future__ import annotations
__all__ = ["MyLabExtractor"]

import requests
from urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

class MyLabExtractor:
    def __init__(self, session) -> None:
        self._session = session
        self._url = self._session.kwargs.get('api_endpoint')
        self._request_header = {
            'Accept': 'application/json',
            'Content-type': 'application/json',
            'Authorization': f'Bearer {session.access_token}',
            'x-api-key': session.api_key
        }
    
    def upload_private_tracks(self, input_json):
        url = self._url + 'mylab/private-track'
        response = requests.post(url=url,
                                 data=input_json,
                                 headers=self._request_header,
                                 verify=self._session.kwargs.get('ssl_verify'))
        return response
    
    def update_private_tracks(self, input_json):
        url = self._url + 'mylab/private-track'
        response = requests.put(url=url,
                                data=input_json,
                                headers=self._request_header,
                                verify=self._session.kwargs.get('ssl_verify'))
        return response

    def delete_private_tracks(self, input_json):
        url = f'{self._url}mylab/private-track'
        response = requests.delete(url=url,
                                   params=input_json,
                                   headers=self._request_header,
                                   verify=self._session.kwargs.get('ssl_verify'))

        # print(response.__dict__['raw'].__dict__)
        return response

    def extract_uploaded_tracks(self):
        url = self._url + 'mylab/private-track'
        response = requests.get(url=url,
                                headers=self._request_header,
                                verify=self._session.kwargs.get('ssl_verify'))
        return response