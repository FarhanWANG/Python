from __future__ import annotations
__all__ = ["DispersionExtractor"]

import requests
from urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)


class DispersionExtractor:
    def __init__(self, session):
        self.session = session

        self._request_header = {
            'Accept': 'application/json',
            'Content-type': 'application/json',
            'Authorization': f'Bearer {session.access_token}',
            'x-api-key': session.api_key
        }
        self._url = self.session.kwargs.get('api_endpoint')+'analytics/dispersion'

    def extract_dispersion_results(self, input_json):
        response = requests.post(
            url=self._url,
            json=input_json,
            headers=self._request_header,
            verify=self.session.kwargs.get('ssl_verify'))

        return response
