from __future__ import annotations

__all__ = ["UniverseExtractor"]

import requests
from urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)



class UniverseExtractor:
    def __init__(self, session) -> None:
        self.session = session
        self.url = self.session.kwargs.get('api_endpoint')
        self._request_header = {
            'Accept': 'application/json',
            'Content-type': 'application/json',
            'Authorization': f'Bearer {session.access_token}',
            'x-api-key': session.api_key
        }
        
    def POST_data(self, input_json):
        response=requests.post(
            url=self.url + "subscriptions",
            headers=self._request_header,
            data=input_json,
            verify=self.session.kwargs.get('ssl_verify')
        )
        return response

    def get_limit(self):
        response = requests.get(
            url=self.url + "subscriptions/limit/mstar",
            headers=self._request_header,
            verify=self.session.kwargs.get('ssl_verify')

        )
        return response

    def get_static_info(self):
        return requests.get(
            url=self.url + 'data/static-infos',
            headers=self._request_header,
            verify=self.session.kwargs.get('ssl_verify')
            )

    def extract_prices(self, code, start, end):
        if start is not None and end is not None:
            url = self.url+f'data/{code}/prices?startDate={start}&endDate={end}'
        else:
            url = self.url + f'data/{code}/prices'

        return requests.get(url=url, headers=self._request_header,verify=self.session.kwargs.get('ssl_verify'))

