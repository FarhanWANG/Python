from __future__ import annotations
__all__ = ["MetricsExtractor"]

import requests
from urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

class MetricsExtractor:
    def __init__(self, session):
        self.session = session

        self._request_header = {
            'Accept': 'application/json',
            'Content-type': 'application/json',
            'Authorization': f'Bearer {self.session.access_token}',
            'x-api-key': self.session.api_key
        }
        self._url = self.session.kwargs.get('api_endpoint')+'analytics/'

    def extract_metrics(self, input_json):
        return requests.post(
            url=self._url + 'metrics/',
            data = input_json,
            headers = self._request_header,
            verify=self.session.kwargs.get('ssl_verify')
        )