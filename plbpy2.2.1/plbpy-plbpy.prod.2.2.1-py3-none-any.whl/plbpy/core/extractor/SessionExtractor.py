from __future__ import annotations
__all__ = ["SessionExtractor"]

import requests
from urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

class SessionExtractor:

    def __init__(self, url, ssl_verify):
        self._url = url+'token'
        self._ssl_verify = ssl_verify
        pass

    def extract_token(self, header, body):
        return requests.post(url=self._url,
                             json=body,
                             headers=header,
                             verify=self._ssl_verify)



