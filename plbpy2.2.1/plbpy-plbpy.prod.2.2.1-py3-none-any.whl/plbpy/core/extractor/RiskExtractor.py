from __future__ import annotations
__all__ = ["RiskExtractor"]

from plbpy.exceptions.class_exceptions import RiskDataException
import requests
from urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

class RiskExtractor:
    def __init__(self, session):

        self.session = session
        self._request_header = {
            'Accept': 'application/json',
            'Content-type': 'application/json',
            'Authorization': f'Bearer {session.access_token}',
            'x-api-key': session.api_key
        }
        self._url = self.session.kwargs.get('api_endpoint')+'risk/'

    def call_portfolio_ids(self):
        raw = requests.get(url=self._url,
                            headers=self._request_header, verify=self.session.kwargs.get('ssl_verify'))
        if raw.status_code >= 300:
            reason = raw.json() if raw.json() is not None else " "
            raise RiskDataException(f'{raw} {raw.status_code} {reason}')
        return raw.json()

    def set_slug(self, value):
        self.slug = value

    def call_available_dates(self):
        raw = requests.get(url=f'{self._url}{self.slug}/dates',
                            headers=self._request_header, verify=self.session.kwargs.get('ssl_verify'))

        if raw.status_code >= 300:
            reason = raw.json() if raw.json() is not None else " "
            raise RiskDataException(f'{raw} {raw.status_code} {reason}')

        return raw.json()

    def call_strategy_values(self, dates):
        raw = requests.get(url=f'{self._url}{self.slug}/strategies?startDate={dates[0]}&endDate={dates[-1]}',
                            headers=self._request_header, verify=self.session.kwargs.get('ssl_verify'))

        if raw.status_code >= 300:
            reason = raw.json() if raw.json() is not None else " "
            raise RiskDataException(f'{raw} {raw.status_code} {reason}')
        return raw.json()

    def call_options(self, dates):
        raw = requests.get(url=f'{self._url}{self.slug}/options?date={dates[-1]}',
                            headers=self._request_header, verify=self.session.kwargs.get('ssl_verify'))

        if raw.status_code >= 300:
            reason = raw.json() if raw.json() is not None else " "
            raise RiskDataException(f'{raw} {raw.status_code} {reason}')
        return raw.json()

    # ----------- Metric Data methods --------------

    def call_metrics_api_v2(self, input_json):
        results = []
        while True:
            raw = requests.post(url=f'{self._url}{self.slug}/query', json=input_json, headers=self._request_header,
                                verify=self.session.kwargs.get('ssl_verify'))
            if raw.status_code >= 300:
                reason = raw.json() if raw.json() is not None else " "
                raise RiskDataException(f'{raw} {raw.status_code} {reason}')
            raw = raw.json()
            results += raw['responses']
            if 'next' not in list(raw.keys()):
                break
            else:
                input_json['start'] = raw['next']

        return results