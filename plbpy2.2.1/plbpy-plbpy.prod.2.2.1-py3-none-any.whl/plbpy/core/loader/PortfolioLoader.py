
from __future__ import annotations
__all__ = ["PortfolioLoader"]

from typing import Optional
from plbpy import session as _gl_session
from plbpy import universe as _gl_universe
from plbpy.interface.Universe import Universe
from plbpy.core.extractor.PortfolioExtractor import PortfolioExtractor
from plbpy.core.transformer.PortfolioTransformer import PortfolioTransformer
from plbpy.utility.date_utils import datetime2str, today, to_date, date, datetime, next_business_day
from plbpy.utility.func_utils import Options
from plbpy.exceptions.class_exceptions import (
    PortfolioValidationError,
    SessionError,
    PortfolioError,
)
import json
from plbpy import console  # Log tools
import copy


class PortfolioLoader:

    def _delete_keys(self, keys):
        for k in keys:
            try:
                del self.info[k]
            except KeyError:
                pass

    def _create_inital_info_object(self):
        """
        Create the bare minimum Portfolio JSON input
        """
        return {
            'endDate': datetime2str(today()),
            'listCodes': self.universe.codes,
            'listStartDates': [self.universe.last_date],
            'returnInterval': 'Daily'
        }

    def _set_info_object(self, new_info):
        self.info = copy.copy(new_info)

    def _validate_portfolio_build(self) -> None:
        """manual checks of info object"""

        if len(self.codes) != len(self.universe.codes) != len(self.info['listCodes']):
            raise PortfolioValidationError("Inconsistency in universe")
        if (
            str(self.start) != self.info['listStartDates'][0]
            or str(self.end) != self.info['endDate']
        ):
            raise PortfolioValidationError("Inconsistency in start/end dates")

        if len(self.codes) >= 20:
            raise PortfolioValidationError(
                "Number of strategies in Portfolio must be less than 20"
            )
        if str(self.start) < self.universe.last_date:
            raise PortfolioValidationError(
                "Portfolio start date must be before max start date of its constituents"
            )
        if self.end < self.start:
            raise PortfolioValidationError(
                "Portfolio start date must be before info end date"
            )
        if self.rebalance_dates is not None:  # Check if info has rebalancing dates
            if any(
                to_date(i) > self._end or to_date(i) < self._start
                for i in self._rebalance_dates
            ):
                raise PortfolioValidationError(
                    "Rebalance dates must be between start and end dates"
                )

    def __init__(self, universe):
        self.session = _gl_session
        if isinstance(universe, list):
            self.universe = _gl_universe.code(universe)
        elif isinstance(universe, Universe):
            self.universe = universe

        self.info = self._create_inital_info_object()
        self.rebalance_dates = None
        self.result = None
        self._result_holder = {}

    # ------------------ PROPERTIES --------------
    @property
    def universe(self):
        return self._universe

    @universe.setter
    def universe(self, value):
        self._universe = value

    @property
    def session(self):
        return self._session

    @session.setter
    def session(self, value):
        self._session = value

    @property
    def info(self):
        return self._info

    @info.setter
    def info(self, value):
        self._info = value

    @property
    def start(self):
        return self._info['listStartDates'][0]

    @property
    def end(self):
        return self._info['endDate']

    @property
    def return_interval(self):
        return self._info['returnInterval']

    @property
    def codes(self):
        return self._info['listCodes']
    
    @property
    def result(self):
        return self._result

    @result.setter
    def result(self, value):
        self._result = value

    # -------------- METHODS ----------

    def set_start(self, start_date):
        try:
            lower, upper = to_date(self.universe.last_date), to_date(self.end)

            if not (lower <= to_date(start_date) <= upper):
                raise PortfolioValidationError(
                    f"Trying to set end date {start_date} "
                    f"outside the acceptable range {datetime2str(lower)} "
                    f"to {datetime2str(upper)} "
                )

            self.info['listStartDates'] = [datetime2str(to_date(start_date))]
        except Exception as e:
            console.info(PortfolioValidationError(), exc_info=e)

    def set_end(self, end_date):
        try:
            lower, upper = to_date(self.start), to_date(today())

            if not (lower <= to_date(end_date) <= upper):
                raise PortfolioValidationError(
                    f"Trying to set end date {end_date} "
                    f"outside the acceptable range {datetime2str(lower)} "
                    f"to {datetime2str(upper)} "
                )

            self.info['endDate'] = datetime2str(to_date(end_date))
        except Exception as e:
            console.info(PortfolioValidationError(), exc_info=e)

    def set_return_interval(self, return_interval):
        try:
            if return_interval.lower() not in ['daily', 'weekly', 'monthly']:
                raise PortfolioValidationError("Return interval must be either Daily, Weekly or Monthly (case insensitive)")

            self.info['returnInterval'] = return_interval.title()
        except Exception as e:
            console.info(PortfolioValidationError(), exc_info=e)

    def set_volatility_interval(self, vol_interval):
        try:
            valid_options = ["1M", "3M", "6M", "1Y", "2Y", "3Y", "4Y", "5Y"]
            if vol_interval not in valid_options:
                raise PortfolioValidationError('Vol interval must be in '+','.join(valid_options))

            self.info['volatilityInterval'] = vol_interval
        except Exception as e:
            console.info(PortfolioValidationError(), exc_info=e)

    def set_sharpe_interval(self, sharpe_interval):
        try:
            valid_options = ["1M", "3M", "6M", "1Y", "2Y", "3Y", "4Y", "5Y"]
            if sharpe_interval not in valid_options:
                raise PortfolioValidationError('Sharpe interval must be in '+','.join(valid_options))

            self.info['sharpeInterval'] = sharpe_interval
        except Exception as e:
            console.info(PortfolioValidationError(), exc_info=e)

    def set_benchmark(self, benchmark, correlation_window):
        try:
            if isinstance(benchmark, list):
                assert len(benchmark) == 1, "Can't set more than 1 benchmark"
                benchmark = benchmark[0]

            if isinstance(benchmark, Universe):
                assert len(benchmark.codes) == 1, "Can't set more than 1 benchmark"
                benchmark = benchmark.codes[0]

            valid_options = ['1M', '3M', '6M', '1Y', '2Y', '3Y', '4Y', '5Y']
            assert correlation_window in valid_options, f'Correlation window must be in {valid_options}'

            self.info['correlBenchmark'] = benchmark
            self.info['correlInterval'] = correlation_window

        except Exception as e:
            console.info(PortfolioValidationError(), exc_info=e)

    def set_minimum_allocation(self, allocation):
        try:
            if not isinstance(allocation, list):
                raise ValueError('Allocation must be list type')
            if len(allocation)!=1 and len(allocation)!=len(self.codes):
                raise ValueError('Number of Strategies != Number of weights')
            if len(allocation) == 1:
                allocation = allocation*len(self.codes)
            self.info['listMinAllocation'] = allocation
        except Exception as e:
            console.info(PortfolioValidationError(), exc_info=e)

    def set_maximum_allocation(self, allocation):
        try:
            if not isinstance(allocation, list):
                raise ValueError('Allocation must be list type')
            if len(allocation)!=1 and len(allocation)!=len(self.codes):
                raise ValueError('Number of Strategies != Number of weights')
            if len(allocation) == 1:
                allocation = allocation*len(self.codes)
            self.info['listMaxAllocation'] = allocation
        except Exception as e:
            console.info(PortfolioValidationError(), exc_info=e)

    def set_rebalance_dates(self, rebalance_dates=None):
        if rebalance_dates is None:
            self._delete_keys('listRebalancingDates')
            return
        try:
            if not isinstance(rebalance_dates, (str, list)):
                raise ValueError(
                    f"Invalid value given to rebalance dates ({rebalance_dates})"
                )
            elif isinstance(rebalance_dates, str):
                import pandas as pd
                if rebalance_dates == 'D':
                    rebalance_dates = datetime2str(pd.date_range(self.start, self.end, freq='B')).tolist()
                else:
                    rebalance_dates = datetime2str(pd.date_range(self.start, self.end, freq=rebalance_dates)).tolist()
                    rebalance_dates = [next_business_day(d) for d in rebalance_dates]

            elif isinstance(rebalance_dates, list):
                if not isinstance(rebalance_dates[0], str):
                    rebalance_dates = list(map(datetime2str, rebalance_dates))

            self.info['listRebalancingDates'] = rebalance_dates

        except Exception as e:
            console.info(PortfolioValidationError(), exc_info=e)

    def set_equal_weight(self, rebalance_dates=None):
        self.set_rebalance_dates(rebalance_dates)
        try:
            self._delete_keys(['listMinAllocation',
                               'listMaxAllocation',
                               'varInterval',
                               'varReturnInterval',
                               'manualWeights'])

            self.info['allocationModel'] = 'Fixed'
            self.info['leverageOrVol'] = 1

        except Exception as e:
            console.info(PortfolioValidationError(), exc_info=e)

    def set_fixed_weight(self, weights, rebalance_dates=None):
        self.set_rebalance_dates(rebalance_dates)
        try:
            self._delete_keys(['varReturnInterval','varInterval','manualWeights']) # only used in ERC and RP

            if isinstance(weights, dict):
                if any([i not in self._universe.codes for i in list(weights.keys())]):
                    raise PortfolioValidationError('All assets must be in weights dictionary')

                weights = [weights[i] for i in self._universe.codes]

            if len(self.codes) != len(weights):
                raise PortfolioValidationError(f"Dimension of weights != Number of Strategies")

            levered_weights = [w_ / sum(weights) for w_ in weights]

            self.info['allocationModel'] = 'Fixed'
            self.info['leverageOrVol'] = sum(weights)
            self.info['scalingType'] = 'Fixed Leverage'
            self.info['listMinAllocation'] = levered_weights
            self.info['listMaxAllocation'] = levered_weights

        except Exception as e:
            console.info(PortfolioValidationError(), exc_info=e)

    def set_erc(self, erc_interval, return_interval, rebalance_dates=None):
        self.set_rebalance_dates(rebalance_dates)
        try:
            self._delete_keys(['listMinAllocation',
                               'listMaxAllocation',
                               'manualWeights'])

            if return_interval not in ['Daily','Weekly','Monthly']:
                raise PortfolioValidationError('Return interval must be Daily, Weekly or Monthly')

            if erc_interval not in ['1M','3M','6M','1Y','2Y','4Y','5Y']:
                raise PortfolioValidationError('ERC Interval must be in 1M,3M,6M,1Y,2Y,4Y,5Y')

            self.info['allocationModel'] = 'ERC'
            self.info['varInterval'] = erc_interval
            self.info['varReturnInterval'] = return_interval

        except Exception as e:
            console.info(PortfolioValidationError(), exc_info=e)

    def set_custom_weight(self, weights, rebalance_dates=None):
        import numpy as np
        from plbpy.utility.string_utils import repeat_list

        self.set_rebalance_dates(rebalance_dates)
        try:
            self._delete_keys(['listMinAllocation',
                               'listMaxAllocation',
                               'varReturnInterval',
                               'varInterval'
                               ])

            if not isinstance(weights, list):
                raise PortfolioValidationError('Weights must be list type')

            rbd = self.info['listRebalancingDates']

            if len(np.array(weights).shape) == 2:
                if np.array(weights).shape[1] != len(self.codes):
                    raise PortfolioValidationError('Number of weights != Number of assets')
                if np.array(weights).shape[0] != len(rbd):
                    raise PortfolioValidationError('Each allocation must correspond to a rebalancing date')

            elif len(np.array(weights).shape) == 1:
                if len(weights) != len(self.codes):
                    raise PortfolioValidationError('Number of weights != Number of assets')
                weights = repeat_list(weights, rbd)

            self.info['allocationModel'] = 'Manual'
            self.info['manualWeights'] = weights

        except Exception as e:
            console.info(PortfolioValidationError(), exc_info=e)

    def set_risk_parity(self, parity_interval, return_interval, rebalance_dates=None):
        self.set_rebalance_dates(rebalance_dates)
        try:
            self._delete_keys(['listMinAllocation',
                               'listMaxAllocation',
                               'manualWeights'])
            if return_interval not in ['Daily','Weekly','Monthly']:
                raise PortfolioValidationError('Return interval must be Daily, Weekly or Monthly')

            if parity_interval not in ['1M','3M','6M','1Y','2Y','4Y','5Y']:
                raise PortfolioValidationError('Parity Interval must be in 1M,3M,6M,1Y,2Y,4Y,5Y')

            self.info['allocationModel'] = 'VRP'
            self.info['varInterval'] = parity_interval
            self.info['varReturnInterval'] = return_interval

        except Exception as e:
            console.info(PortfolioValidationError(), exc_info=e)

    def set_leverage_parameters(self, method, target, vol_interval, min_vol, max_vol):
        try:
            if method is not None and method.lower() not in ['leverage', 'volatility']:
                raise PortfolioValidationError('method must either be None, leverage or volatility')

            if method.lower() == 'volatility':
                if vol_interval is None:
                    raise PortfolioValidationError('Must pass vol_interval with volatility method')

                if vol_interval not in ['1M', '3M', '6M', '1Y', '2Y', '3Y', '4Y', '5Y']:
                    raise PortfolioValidationError('vol_interval must be in 1M, 3M, 6M, 1Y, 2Y, 3Y, 4Y, 5Y')

                if min_vol > max_vol:
                    raise PortfolioValidationError(
                        'Maximum volatility target must be greater than minimum volatility target')

                if min_vol < 0:
                    raise PortfolioValidationError('Minimum volatility target must be greater than 0')

                self.info['scalingType'] = 'Target Volatility'
                self.info['volatilityTargetInterval'] = vol_interval
                self.info['targetVolMinLeverage'] = min_vol
                self.info['targetVolMaxLeverage'] = max_vol
                self.info['leverageOrVol'] = target

            elif method.lower() == 'leverage':
                self.info['scalingType'] = 'Fixed Leverage'
                self.info['leverageOrVol'] = target
                self._delete_keys(['targetVolMinLeverage',
                                   'targetVolMaxLeverage'])

            elif method is None:
                self._delete_keys(['scalingType',
                                   'leverageOrVol',
                                   'targetVolMinLeverage',
                                   'targetVolMaxLeverage'])

        except Exception as e:
            console.info(PortfolioValidationError(), exc_info=e)

    def run_backtest(self):
        self.session._validate_configuration()

        self._validate_portfolio_build()

        input_json = json.dumps(self.info)
        __extractor = PortfolioExtractor(self.session, self.universe)
        raw_response = __extractor.extract_backtest_results(input_json)

        if raw_response.status_code >= 300:
            raise PortfolioError(raw_response.status_code)
        else:
            raw_response = raw_response.json()
            self._transform_metrics(raw_response)
            self.result = Options._from_dict(self._result_holder)

    def _transform_metrics(self, raw_response):
        __transformer = PortfolioTransformer(self._session,
                                             portfolio_input=self.info,
                                             portfolio_response=raw_response[0])

        self._result_holder['params'] = __transformer.params
        self._result_holder['static_metric'] = __transformer.static_metric
        self._result_holder['rolling_metric'] = __transformer.rolling_metric
        self._result_holder['track'] = self._check_access_right(__transformer)
        self._result_holder['monthly_return'] = __transformer.monthly_return()
        self._result_holder['monthly_return_styled'] = __transformer.monthly_return(style=True)
        self._result_holder['yearly_return'] = __transformer.yearly_return
        self._result_holder['weights'] = __transformer.weights
        self._result_holder['correlation_matrix'] = __transformer.correlation_matrix
        self._result_holder['asset_class_allocation'] = __transformer.asset_class_allocation
        self._result_holder['factor_allocation'] = __transformer.factor_allocation
        self._result_holder['cash_replacement_metrics'] = __transformer.cash_replacement_metrics
        self._result_holder['raw_backtest_response'] = __transformer._response

    def _check_access_right(self, transformer):
        if not self._session.kwargs.get("track_access", True) and len(self._assets) == 1:
            return "Access to Strategy Track restricted. Please contact Premialab for more info"
        else:
            return transformer.track

    def reset(self):
        self.info = self._create_inital_info_object()
        self.rebalance_dates = None
        self._result_holder = {}
        self.result = Options._from_dict(self._result_holder)

    def efficient_frontier(self):
        import plbpy.visualizer.Visualiser as viz
        import pandas as pd
        import plotly.graph_objects as go
        self._validate_portfolio_build()

        input_dict = {
            "listCodes": self.codes,
            "startDate": next_business_day(self.start),
            "endDate":  next_business_day(self.end),
            "returnInterval": self.return_interval
            }

        input_json = json.dumps(input_dict)
        __extractor = PortfolioExtractor(self.session, self.universe)
        raw_response = __extractor.extract_frontier_results(input_json)
        
        if raw_response.status_code >= 300:
            raise PortfolioError(raw_response.json())

        __transformer = PortfolioTransformer(self.session,
                                            portfolio_input=input_json,
                                            portfolio_response=raw_response)

        line = __transformer.frontier_line
        weight = __transformer.frontier_weights
        maxSharpe = __transformer.frontier_max_sharpe
        self._result_holder['frontier_line'] = line
        self._result_holder['frontier_weights'] = weight
        self._result_holder['frontier_maxSharpe'] = maxSharpe
        combined_data = pd.concat([line, weight], axis=1)

        fig = viz.Visualiser().frontier_plot(combined_data, kind='xygraph')
        y_text = round(maxSharpe.iloc[0,1],2)
        x_text = round(maxSharpe.iloc[0,0],2)
        mxs_header = '<b>Tangent Portfolio</b>' + f'<br>Return: {y_text}%' + f'<br>Volatility: {x_text}%<br>'
        mxs_w = maxSharpe.iloc[0,2:-1].to_dict()
        mxs_text = "<br>".join([x[0]+": "+str(round(x[1],2))+"%" for x in mxs_w.items()])
        fig.add_trace(go.Scatter(
            x = maxSharpe['Volatility'],
            y = maxSharpe['Return'],
            hovertemplate = mxs_header + mxs_text,
            mode = 'markers',
            name = "Tangent Portfolio",
            marker_size=15,
            marker_color = viz.Visualiser()._get_plb_colors()[2]
        ))

        self._result_holder['frontier_line_plot'] = fig
        self._result_holder['frontier_weight_plot'] = viz.Visualiser().frontier_plot(combined_data, kind='weights')
        self.result = Options._from_dict(self._result_holder)
