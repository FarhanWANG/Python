from __future__ import annotations

__all__ = ["DispersionLoader"]

from plbpy.interface.Universe import Universe
from plbpy import universe as _gl_universe
from plbpy import session as _gl_session
from plbpy.interface.Portfolio import Portfolio
from plbpy.utility.date_utils import (
    datetime2str,
    today,
    to_date,
)
from plbpy.exceptions.class_exceptions import (
    DispersionValidationError,
    DispersionError
)

from plbpy.core.extractor.DispersionExtractor import DispersionExtractor
from plbpy.utility.func_utils import Options

class DispersionLoader:
    @staticmethod
    def _create_initial_object(universe):
        return {
            'endDate': datetime2str(today()),
            'listStartDates': [universe.last_date],
            'listCodes': universe.codes,
            'metric': 'Information Ratio',
            'returnInterval': 'Daily',
            'rollingWindow': 252.0
        }

    def __init__(self, universe, portfolio, codes, subset):

        self.session = _gl_session

        if universe is not None:
            if isinstance(universe, Universe):
                self.universe = universe

            elif isinstance(universe, list):
                self.universe = _gl_universe.code(codes)

            elif isinstance(universe, Portfolio):
                self.universe = portfolio.universe

        elif codes is not None:
            self.universe = _gl_universe.code(codes)

        elif portfolio is not None:
            self.universe = portfolio.universe

        self.__extractor = DispersionExtractor(self.session)
        self.info = self._create_initial_object(self.universe)

        if subset is not None:
            self.set_subset(subset)

        self.result = None
        self._result_holder = {}

    @property
    def session(self):
        return self._session

    @session.setter
    def session(self, value):
        self._session = value

    @property
    def info(self):
        return self._info

    @info.setter
    def info(self, value):
        self._info = value

    @property
    def start(self):
        return self._info['listStartDates'][0]

    @property
    def end(self):
        return self._info['endDate']

    @property
    def return_interval(self):
        return self._info['returnInterval']

    @property
    def codes(self):
        return self._info['listCodes']

    @property
    def result(self):
        return self._result

    @result.setter
    def result(self, value):
        self._result = value

    def set_start(self, start_date):
        lower, upper = to_date(self.universe.last_date), to_date(self.end)

        if not (lower <= to_date(start_date) <= upper):
            raise DispersionValidationError(
                    f"Trying to set start date {start_date} "
                    f"outside the acceptable range {datetime2str(lower)} "
                    f"to {datetime2str(upper)} "
                )

        self.info['listStartDates'] = [datetime2str(to_date(start_date))]

    def set_end(self, end_date):

        lower, upper = to_date(self.start), to_date(today())

        if not (lower <= to_date(end_date) <= upper):
            raise DispersionValidationError(
                f"Trying to set end date {end_date} "
                f"outside the acceptable range {datetime2str(lower)} "
                f"to {datetime2str(upper)} "
            )

        self.info['endDate'] = datetime2str(to_date(end_date))

    def set_return_interval(self, return_interval):
        valid = ["daily", "weekly", "monthly", "quarterly", "yearly"]
        if return_interval.lower() not in valid:
            raise DispersionValidationError(f"Return interval must be in {valid} (case insensitive)")

        self.info['returnInterval'] = return_interval.title()

    def set_rolling_window(self, window):
        if not (isinstance(window, float) or isinstance(window, int)):
            raise DispersionValidationError("Invalid window type")
        window = float(window) if isinstance(window, int) else window

        self.info['rollingWindow'] = window

    def set_metric(self, metric):
        allowed = [
            "return per annum",
            "volatility",
            "sharpe ratio",
            "information ratio",
            "cumulative return",
        ]
        if not (metric.lower() in allowed):
            raise DispersionValidationError(
                f"metric must be one of {allowed} (case insensitive)"
            )

        self.info['metric'] = metric.title()

    def set_subset(self, subset):
        assert isinstance(subset, Universe) or isinstance(subset, list), "Subset must be a list of codes or plbpy.universe object"

        if isinstance(subset, Universe):
            subset = subset.codes

        self.info['subset'] = subset

    def set_volatility_scale(self, vol_interval, vol_target, rebalance_dates):

        assert self.info['metric'] == "Cumulative Return", DispersionValidationError(
            f"Dispersion metric cannot be {self.info['metric']} for volatility scaling"
        )

        assert vol_interval in [
            "1M",
            "3M",
            "6M",
            "1Y",
            "2Y",
            "3Y",
            "4Y",
            "5Y",
        ], DispersionValidationError(
            """
        Need to provide volatility interval:
        Accepted inputs: ["1M", "3M", "6M", "1Y", "2Y", "3Y", "4Y", "5Y"]
        """
        )
        self.info['volatilityTargetInterval'] = vol_interval
        # Set Rebalancing Dates, if any
        if isinstance(rebalance_dates, str):
            import pandas as pd

            rebalance_dates = pd.date_range(
                self.info['start'], self.info['end'], freq='B' if rebalance_dates == 'D' else rebalance_dates
            ).tolist()

        if isinstance(rebalance_dates, list):
            if type(rebalance_dates[0]) != str:
                rebalance_dates = list(
                    map(datetime2str, rebalance_dates)
                )

        self.info['rebalancingDates'] = rebalance_dates

        if isinstance(vol_target, float):
            self.info['scalingType'] = "Static Vol Target"
            self.info['leverageOrVol'] = vol_target
        elif isinstance(vol_target, str):
            self.info['scalingType'] = "Strategy Vol Target"
            self.info['leverageOrVol'] = vol_target

    def _validate_dispersion_build(self):
        if 1 < len(self.universe.codes) >= 120:
            raise DispersionValidationError(
                f"Number of tickers ({len(self.universe.codes)}) cannot be less than 2"
            )
        if to_date(self.end) < to_date(self.start):
            raise DispersionValidationError(
                f"Start date ({self.start}) must be before end date ({self.end})"
            )
    def run_dispersion(self):
        self._validate_dispersion_build()
        self.session._validate_configuration()

        response = self.__extractor.extract_dispersion_results(self.info)

        if response.status_code >= 300:
            reason = response.json() if response.json() is not None else " "
            raise DispersionError(f'{response} {response.status_code} {reason}')
        else:
            response = response.json()
            result_holder = self._transform_results(response)
            self.result = Options._from_dict(result_holder)

            return

    def _transform_results(self, raw):
        from plbpy.core.transformer.DispersionTransformer import DispersionTransformer
        __transformer = DispersionTransformer(dispersion_input=self.info, dispersion_response=raw, universe=self.universe)

        result_holder = {}
        result_holder['params'] = __transformer.params
        result_holder['subset_dispersion'] = __transformer.subset_dispersion
        result_holder['universe_dispersion'] = __transformer.universe_dispersion
        result_holder['raw_api_response'] = raw

        return result_holder

    def reset(self):
        og_info = self.info['subset']
        self.info = self._create_initial_object()
        if 'subset' in list(og_info.keys()):
            self.set_subset(og_info['subset'])
        self._result_holder = {}
        self.result = Options._from_dict(self._result_holder)
