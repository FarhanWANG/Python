from __future__ import annotations

__all__ = ["MSTLoader"]

from plbpy.interface.Universe import Universe
from plbpy import universe as _gl_universe
from plbpy import session as _gl_session
from plbpy.interface.Portfolio import Portfolio
from plbpy.utility.date_utils import (
    datetime2str,
    today,
    to_date,
)
from plbpy.exceptions.class_exceptions import (
    MSTValidationError,
    MSTError
)

from plbpy.core.extractor.MSTExtractor import MSTExtractor
from plbpy.utility.func_utils import Options

class MSTLoader:
    @staticmethod
    def _create_initial_object(universe):
        return {
            'endDate': datetime2str(today()),
            'listStartDates': [universe.last_date],
            'listCodes': universe.codes,
            'correlationType': 'Pearson',
            'returnInterval': 'Daily'
        }

    def __init__(self, universe, portfolio, codes):
        self._portfolio = None
        self.session = _gl_session

        if universe is not None:
            if isinstance(universe, Universe):
                self.universe = universe

            elif isinstance(universe, list):
                self.universe = _gl_universe.code(codes)

            elif isinstance(universe, Portfolio):
                self.universe = portfolio.universe

        elif codes is not None:
            self.universe = _gl_universe.code(codes)

        elif portfolio is not None:
            self.universe = portfolio.universe

        self.__extractor = MSTExtractor(self.session)
        self.info = self._create_initial_object(self.universe)

        self.result = None
        self._result_holder = {}

    # ------------------ PROPERTIES --------------
    @property
    def universe(self):
        return self._universe

    @universe.setter
    def universe(self, value):
        self._universe = value

    @property
    def session(self):
        return self._session

    @session.setter
    def session(self, value):
        self._session = value

    @property
    def info(self):
        return self._info

    @info.setter
    def info(self, value):
        self._info = value

    @property
    def start(self):
        return self._info['listStartDates'][0]

    @property
    def end(self):
        return self._info['endDate']

    @property
    def return_interval(self):
        return self._info['returnInterval']

    @property
    def codes(self):
        return self._info['listCodes']
    @property
    def type(self):
        return self._info['correlationType']

    @property
    def result(self):
        return self._result

    @result.setter
    def result(self, value):
        self._result = value

    def set_start(self, start_date):
        """
        Sets MST start date

        :param start_date: Date at which MST should begin. If passing str, date should be in YYYY-MM-DD format
        :type start_date: Union[date, datetime, str]
        :return: Current MST object with an updated start date
        :rtype: MST
        :raise AssertionError: If attempting to set start date after end date

        Run MST with data from 1st Jan 2015

        >>> plbpy.MST(
                universe = universe.code("SPX", "SBWGU")
            ).set_start('2015-01-01')
        """
        lower, upper = to_date(self.universe.last_date), to_date(self.end)

        if not (lower <= to_date(start_date) <= upper):
            raise MSTValidationError(
                    f"Trying to set start date {start_date} "
                    f"outside the acceptable range {datetime2str(lower)} "
                    f"to {datetime2str(upper)} "
                )

        self.info['listStartDates'] = [datetime2str(to_date(start_date))]

    def set_end(self, end_date):
        """
        Sets MST end date

        :param end_date: Date at which MST should end. If passing str, date should be in YYYY-MM-DD format
        :type end_date: Union[date, datetime, str]
        :return: Current MST object with an updated end date
        :rtype: MST
        :raise AssertionError: If attempting to set end date after today

        Run MST with data until 1st Jan 2020

        >>> plbpy.MST(
                universe = universe.code("SPX", "SBWGU")
            ).set_end('2020-01-01')
        """

        lower, upper = to_date(self.start), to_date(today())

        if not (lower <= to_date(end_date) <= upper):
            raise MSTValidationError(
                f"Trying to set end date {end_date} "
                f"outside the acceptable range {datetime2str(lower)} "
                f"to {datetime2str(upper)} "
            )

        self.info['endDate'] = datetime2str(to_date(end_date))

    def set_return_interval(self, return_interval):
        valid = ["daily", "weekly", "monthly", "quarterly", "yearly"]
        if return_interval.lower() not in valid:
            raise MSTValidationError(f"Return interval must be in {valid} (case insensitive)")

        self.info['returnInterval'] = return_interval.title()

    def set_correlation_type(self, corr_type):
        valid = ["pearson", "spearman"]
        if corr_type.lower() not in valid:
            raise MSTValidationError(f"Type must be in {valid} (case insensitive)")

        self.info['correlationType'] = corr_type.title()

    def _validate_mst_build(self):
        if not (2 <= len(self.universe.codes) <= 400):
            raise MSTValidationError(
                f"Number of tickers ({len(self.universe.codes)}) cannot be more than 400 or less than 2"
            )
        if to_date(self.end) < to_date(self.start):
            raise MSTValidationError(
                f"Start date ({self.start}) must be before end date ({self.end})"
            )

    def run_mst(self):
        self._validate_mst_build()
        self.session._validate_configuration()

        response = self.__extractor.extract_mst_results(self.info)

        if response.status_code >= 300:
            reason = response.json() if response.json() is not None else " "
            raise MSTError(f'{response} {response.status_code} {reason}')
        else:
            response = response.json()
            result_holder = self._transform_results(response)
            self.result = Options._from_dict(result_holder)
        return

    def _transform_results(self, raw):
        from plbpy.core.transformer.MSTTransformer import MSTTransformer
        __transformer = MSTTransformer(mst_input=self.info, mst_response=raw, universe=self.universe)

        result_holder = {}
        result_holder['params'] = __transformer.params
        result_holder['tree'] = __transformer.tree
        result_holder['raw_api_response'] = raw

        return result_holder

    def reset(self):
        self.info = self._create_initial_object()
        self._result_holder = {}
        self.result = Options._from_dict(self._result_holder)