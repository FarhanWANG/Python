from __future__ import annotations
__all__ = ["MyLabLoader"]

from typing import Optional
from plbpy.core.extractor.MyLabExtractor import MyLabExtractor
from plbpy.core.transformer.MyLabTransformer import MyLabTransformer
from plbpy.exceptions.class_exceptions import (
    MyLabError
)
from plbpy.utility.string_utils import compare_str_list
import json
import pandas as pd
import copy
import numpy as np
from plbpy import console


class MyLabLoader:
    @staticmethod
    def _return_to_price(df):
        price_df = df.copy()
        for i in price_df.columns.tolist():
            d = price_df[[i]].dropna()
            price_df[i] = np.cumprod(1+d)*100

        return price_df

    def get_static_fields(self):
        return self._static_fields

    @staticmethod
    def _create_input_object(timeseries: pd.DataFrame, static_info: list = []):
        private_track_list = []
        for name in timeseries.columns.tolist():
            df = timeseries[[name]].fillna(method='ffill', limit=20).dropna().copy()
            assert 'date' in df.reset_index().columns.tolist(), "Index name should be date"
            price_history = list(df.reset_index().rename(columns={name: 'price'}).T.to_dict().values())

            if len(static_info) > 0:
                static_dict = [i for i in static_info if i['name'] == name]
                static_dict = static_dict[0] if len(static_dict) > 0 else {'name': name}
            else:
                static_dict = {'name': name}

            static_dict['priceHistory'] = price_history

            private_track_list.append(static_dict)

        return {'privateTrackList': private_track_list}

    def __init__(self, session, universe, get_info=[]):
        self.session = session
        self.universe = universe
        self._static_fields = ['reference','referenceType' ,'name', 'assetClass', 'region', 'factor', 'currency', 'style',
                               'returnType', 'returnCategory', 'liveDate','isin', 'morningStarId',
                               'ric', 'ticker', 'internalReference', 'volTarget', 'managementFee',
                               'description']
        self.valid_options = {
            'assetClass': ['Commodity', 'Credit', 'Equity', 'Fixed Income', 'Foreign Exchange', 'Multi Assets' ],
            'region': ['Europe', 'Asia', 'Emerging', 'US', 'Global', 'Japan', 'UK'],
            'factor': ['Carry', 'Volatility', 'Momentum', 'Low Vol', 'Quality', 'Size', 'Value', 'Multi', 'Low Volatility'],
            'style': ['Alpha', 'Beta', 'Smart Beta'],
            'returnType': ['Excess Return', 'Total Return'],
            'returnCategory': ['Net', 'Gross']
            }

        self.__extractor = MyLabExtractor(self.session)
        self.__transformer = MyLabTransformer()
        self._info = {'get': get_info, 'put': None, 'post': None, 'delete': None}
        self._uploaded_tracks = self.__transformer.transform_uploaded_tracks(self.info['get'])

    # --------------------- Private Methods ---------------------
    @staticmethod
    def _validate_tracks(df):
        if isinstance(df.columns, pd.MultiIndex) or isinstance(df.index, pd.MultiIndex):
            raise MyLabError('Multi Index dataframes not supported')

        try:
            df.index = pd.to_datetime(df.index)
        except Exception as e:
            raise MyLabError(f"Please ensure the the index is a Date column {e}")
        try:
            df = df.astype(float)
        except Exception as e:
            raise MyLabError(f"Please check your input file. Only numericals allowed {e}")
        df = df.sort_index()
        df.index = df.index.strftime('%Y-%m-%d')
        df.index.name = 'date'

        return df

    @staticmethod
    def _df2dict(df):
        df = df.copy().fillna(method='ffill', limit=20).dropna()
        assert 'date' in df.reset_index().columns.tolist(), "Index name should be date"
        return list(df.reset_index().rename(columns={df.columns[0]: 'price'}).T.to_dict().values())

    @staticmethod
    def _instrument_dict(info_dict:dict, reference_type=None, **kwargs):
        d = {key: value for key, value in info_dict.items() if key not in ['reference', 'referenceType']}

        if reference_type is None:
            reference_type = info_dict['referenceType']

        d['instrument'] = {'referenceType': reference_type, 'reference': info_dict['reference']}
        return d

    def _create_put_json(self, static_info=None, tracks=None, reference_type=None, input_type=0):
        print('Input Type',input_type)
        final = {'privateTrackList': []}
        try:
            if input_type == 0: # only static_info
                for instrument in static_info:
                    instrument_dict = self._instrument_dict(instrument)
                    final['privateTrackList'].append(instrument_dict)

            elif input_type == 1: # static_info + tracks
                for instrument in static_info:
                    price_history = self._df2dict(tracks[[instrument['reference']]])

                    instrument_dict = self._instrument_dict(instrument)
                    instrument_dict['priceHistory'] = price_history

                    final['privateTrackList'].append(instrument_dict)

            elif input_type == 2:
                for instrument in static_info:
                    price_history = self._df2dict(tracks[[instrument['reference']]])

                    instrument_dict = self._instrument_dict(instrument, reference_type=reference_type)
                    instrument_dict['priceHistory'] = price_history

                    final['privateTrackList'].append(instrument_dict)

            elif input_type == 3:
                for instrument in tracks.columns.tolist():
                    price_history = self._df2dict(tracks[[instrument]])
                    instrument_dict = {'priceHistory': price_history, 'instrument': {'referenceType': reference_type, 'reference':instrument}}

                    final['privateTrackList'].append(instrument_dict)

        except Exception as e:
            raise MyLabError(e)

        return final

    def _make_get_request(self):
        response = self.__extractor.extract_uploaded_tracks()

        if response.status_code >= 300:
            reason = response.json() if response.json() is not None else " "
            raise MyLabError(f'{response} {response.status_code} {reason}')

        resp = response.json()
        if len(resp) > 0:
            resp = [i for i in resp if i['instrument']['reference'] in self.universe.codes]

        self.info['get'] = resp
        self._uploaded_tracks = self.__transformer.transform_uploaded_tracks(self.info['get'])

    def _validate_static_info(self, static_info: dict, **kwargs):
        if kwargs.pop('upload_check', True): # name doesn't need to a part of
            assert 'name' in list(static_info.keys()), 'Please check static info. All static info dictionary must have a name corresponding to a private track name'

        assert len(np.setdiff1d(list(static_info.keys()), self._static_fields)) == 0, f"Keys must be in {self._static_fields} . Received { np.setdiff1d(list(static_info.keys()), self._static_fields)}"

        for field in static_info.keys():
            if field is 'name' or field not in list(self.valid_options.keys()): # No validation needed for these
                continue

            valid_options = [i.lower() for i in self.valid_options[field]]
            if static_info[field].lower() not in valid_options:
                raise MyLabError(f'{field} should contain the following values {self.valid_options[field]}')

    # --------------------- Public Methods ---------------------

    def upload_private_tracks(self, input_track, static_info: list, track_type):
        assert static_info is None or isinstance(static_info, list) or isinstance(static_info,
                                                                                  pd.DataFrame) or isinstance(
            static_info, str), 'Static info must be of type list, string, or pandas dataframe'
        input_static_info = copy.deepcopy(static_info)
        # Read input data
        if isinstance(input_track, str):
            extension = input_track.split(".")[-1]

            if extension == 'csv':
                assert not isinstance(input_static_info, str), 'Static info must be of type list or pandas dataframe'
                df = pd.read_csv(input_track, index_col=[0])

            elif extension == 'xlsx':
                excel_file = pd.ExcelFile(input_track)
                sheet_names = excel_file.sheet_names

                if isinstance(input_static_info, str):
                    assert len(
                        sheet_names) == 2, f"Expecting 2 sheets - one for tracks, one for static info. Received {len(sheet_names)}"
                    assert input_static_info in sheet_names, "Static info name not present in sheets"
                    input_static_info = excel_file.parse(sheet_name=input_static_info, index_col=[0])
                    sheet_names.remove(input_static_info)

                else:
                    assert len(sheet_names) == 1, f"Expecting 1 sheet for tracks. Received {len(sheet_names)}"
                    df = excel_file.parse(sheet_name=sheet_names[0], index_col=[0])

            else:
                raise MyLabError("Only csv or xlsx spreadsheets are allowed")

        # pandas dataframe upload
        elif isinstance(input_track, pd.DataFrame):
            if isinstance(input_static_info, str):
                raise AssertionError(f'Static info must be of type list or pandas dataframe')
            df = input_track.copy()

        else:
            raise MyLabError("Only Spreadsheet(xlsx or csv) or Pandas DataFrame is allowed")

        # ---------------- Static Info Validation -------------------
        if input_static_info is None:
            input_static_info = []

        elif isinstance(input_static_info, list):
            pass

        elif isinstance(input_static_info, pd.DataFrame):
            tickers = input_static_info.columns.tolist()
            info_fields = input_static_info.index.tolist()

            # there should be no elements in static info index that are not present in accepted fields
            assert len(np.setdiff1d(info_fields, self._static_fields)) == 0, f"Index should be in {self._static_fields}"
            assert len(np.setdiff1d(tickers, df.columns.tolist())) == 0, f'Columns should be in {df.columns.tolist()}'

            if 'name' not in info_fields:
                input_static_info.columns.name = 'name'
                input_static_info = input_static_info.T.reset_index().T
            input_static_info = list(input_static_info.to_dict().values())
        else:
            raise MyLabError("Static Info should be a list or Pandas DataFrame")

        # Validate static info and Set values in static info to Title Case.
        for info in input_static_info:
            self._validate_static_info(info)
            assert info[
                       'name'] in df.columns.tolist(), f'Name {info["name"]} present in static info but not in timeseries columns'
            for field in info.keys():
                if field is 'name':
                    continue
                info[field] = info[field].title() if info[field].lower() not in ['uk', 'us'] else info[field].upper()

        # Try catch blocks to validate dataframe format
        df = self._validate_tracks(df)

        assert track_type.lower() in ['return', 'price'], "input track_type should be Return or Price"
        df = self._return_to_price(df) if track_type.lower() == 'return' else df
        assert all([i == 0 for i in (df < 0).isna().sum()]), "Please check input, negative track values"

        input_body = self._create_input_object(df, input_static_info)


        response = self.__extractor.upload_private_tracks(json.dumps(input_body))
        if response.status_code >= 300:
            reason = response.json() if response.json() is not None else " "
            raise MyLabError(f'{response} {response.status_code} {reason}')
        self.info['post'] = input_body

        return self.universe

    def update_private_tracks(self, static_info:dict=None, input_track=None, reference_type:str=None, **kwargs):

        # input type 0 = Static info
        # input type 1 = Static info + tracks
        # input type 2 = Static info + tracks + reference type
        # input type 3 = tracks + reference type

        assert static_info is None or isinstance(static_info, list), "Static info must be either dict or None"
        assert input_track is None or isinstance(input_track, pd.DataFrame), "Input track must either be dataframe or none"
        assert reference_type is None or reference_type=='Code', "reference_type must either be none or 'Code'"

        if static_info is not None:
            input_static_info = copy.deepcopy(static_info)
            assert len(input_static_info) > 0, 'Cannot pass empty static_info list'
            assert all([isinstance(i, dict) for i in input_static_info]), 'Must pass a list of dictionaries only'

            for info in input_static_info:
                self._validate_static_info(info, upload_check=False)

            if input_track is None:
                assert all(['reference' in list(i.keys()) and 'referenceType' in list(i.keys()) for i in input_static_info]),"Must specify reference and reference type"
                input_codes = [i['reference'] for i in input_static_info]
                # this validation will be removed once we allow different identifiers
                assert len(np.setdiff1d(input_codes, self.universe.codes)) == 0, f"All codes must be present in the current universe. { np.setdiff1d(input_codes, self.universe.codes) } not present"
                input_type = 0

            else:
                input_track = self._validate_tracks(input_track)
                input_codes = input_track.columns.tolist()
                assert len(np.setdiff1d(input_codes, self.universe.codes)) == 0, f"All codes must be present in the current universe. {np.setdiff1d(input_codes, self.universe.codes)} not present"
                if reference_type is None:
                    assert all(['reference' in list(i.keys()) and 'referenceType' in list(i.keys()) for i in input_static_info]),"Must specify reference and reference type in static info"
                    input_type = 1
                else:
                    assert all(['reference' in list(i.keys()) for i in input_static_info]), "Must specify reference in static info"
                    input_type = 2
        else:
            assert input_track is not None, "Must either pass tracks or static info"
            assert reference_type is not None, "Must specify reference type corresponding to track headings"
            input_codes = input_track.columns.tolist()
            assert len(np.setdiff1d(input_codes, self.universe.codes)) == 0, f"All codes must be present in the current universe. { np.setdiff1d(input_codes, self.universe.codes) } not present"
            input_track = self._validate_tracks(input_track)
            input_type = 3

        input_json = self._create_put_json(static_info=static_info, tracks=input_track, reference_type=reference_type, input_type=input_type)

        response = self.__extractor.update_private_tracks(json.dumps(input_json))
        if response.status_code >= 300:
            reason = response.json() if response.json() is not None else " "
            raise MyLabError(f'{response} {response.status_code} {reason}')

        self.info['put'] = input_json
        return self.universe

    def delete_private_tracks(self, references):
        assert isinstance(references, list), f"References must be of list type."
        assert len(np.setdiff1d(references, self.universe.codes)) == 0, f"All codes must be present in the current universe. {np.setdiff1d(references, self.universe.codes)} not present"
        input_json = {'referenceType': 'Code', 'references[]': references}
        response = self.__extractor.delete_private_tracks(input_json)

        if response.status_code >= 300:
            reason = response.json() if response.json() is not None else " "
            raise MyLabError(f'{response} {response.status_code} {reason}')

        self.info['delete'] = input_json
        return self.universe

    def view_private_tracks(self):
        if len(self.info['get']) == 0:
            self._make_get_request()

        return self._uploaded_tracks

    # --------------- public properties --------------

    @property
    def info(self):
        return self._info

    @info.setter
    def info(self, value):
        self._info = value
    

