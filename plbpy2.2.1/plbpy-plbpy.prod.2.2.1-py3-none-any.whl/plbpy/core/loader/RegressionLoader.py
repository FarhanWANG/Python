
from __future__ import annotations
__all__ = ["RegressionLoader"]

from typing import Union, List, Iterable
from plbpy import session as _gl_session
from plbpy.interface.Universe import Universe
from plbpy.core.extractor.RegressionExtractor import RegressionExtractor
from plbpy.core.transformer.RegressionTransformer import RegressionTransformer
from plbpy.interface.Session import Session
from plbpy.interface.Portfolio import Portfolio
from plbpy.interface.Universe import Universe
from plbpy.utility.func_utils import Options
from plbpy.utility.date_utils import (
    datetime2str,
    today,
    to_date,
    date,
    difference,
)
import json
from plbpy import console, DEBUG  # Log tools
from plbpy.exceptions.class_exceptions import (
    RegressionValidationError,
    SessionError,
    RegressionError,
)
import copy


class RegressionLoader:
    def __init__(
        self,
        Y: Union[Universe, Portfolio, str, Iterable[str]],
        X: Union[Universe, str, Iterable[str]],
        session: Session = _gl_session,
    ) -> None:
        self.session = session
        self.y_universe, self.x_universe = self._validate_input(Y, X, session)
        self._regression = self._set_initial_object(self.y_universe, self.x_universe)
        self._portfolio = Y.info if isinstance(Y, Portfolio) else None
        self.info = { "regression" : self._regression, "portfolio" : self._portfolio}
        self.result = None
        self._result_holder = {}
        
    # --- Private Regression Info Getters ---
    @property
    def session(self):
        return self._session

    @session.setter
    def session(self, value):
        self._session = value

    @property
    def info(self):
        return self._info

    @info.setter
    def info(self, value):
        self._info = value

    @property
    def _start(self) -> date:
        return to_date(self.info['regression']['listStartDates'][0])

    @property
    def _end(self) -> date:
        return to_date(self.info['regression']['endDate'])

    @property
    def _y_codes(self) -> List[str]:
        return self.info['regression']['listCodes']

    @property
    def _x_codes(self) -> List[str]:
        return self.info['regression']['listPremia']

    @property
    def _lasso(self) -> int:
        return self.info['regression']['selection']

    @property
    def _return_interval(self) -> str:
        return self.info['regression']['returnInterval']

    @property
    def _rolling_window(self) -> str:
        return self.info['regression']['movingWindow']

    @property
    def _model_interval(self) -> int:
        return self.info['regression']['modelInterval']
    
    @property
    def _reg_order(self) -> int:
        return self.info['regression']['regOrder']

    # ------------------ PROPERTIES --------------

    
    @property
    def start(self):
        return self._info['regression']['listStartDates'][0]

    @property
    def end(self):
        return self._info['regression']['endDate']
    
    @property
    def result(self):
        return self._result

    @result.setter
    def result(self, value):
        self._result = value
    
    @property
    def x_universe(self):
        return self._x_universe

    @x_universe.setter
    def x_universe(self, value):
        self._x_universe = value

    @property
    def y_universe(self):
        return self._y_universe

    @y_universe.setter
    def y_universe(self, value):
        self._y_universe = value

    # ------- PRIVATE METHODS -------


    def _validate_regression_build(self) -> None:
        if self._portfolio is None:
            if len(self._y_codes) != 1:
                raise RegressionValidationError(
                    f'Dependent Variable ["listCodes"] can only be 1 code or a Portfolio must be present '
                    f'["portfolio"]\nRegression Input:\n{self.info}'
                )
            if (
                len(self._y_codes)
                != len(self.y_universe.codes)
                != len(self._regression["listCodes"])
            ):
                raise RegressionValidationError("Inconsistency in universe")
        if (
            len(self._x_codes)
            != len(self.x_universe.codes)
            != len(self._regression["listPremia"])
        ):
            raise RegressionValidationError("Inconsistency in universe")
        if (
            str(self._start) != self._regression["listStartDates"][0]
            or str(self._end) != self._regression["endDate"]
        ):
            raise RegressionValidationError("Inconsistency in universe")
        if self._start > self._end:
            raise RegressionValidationError(
                "Regression Start date must be before end date"
            )
    
    def _set_info_object(self, new_info):
        self.info = copy.copy(new_info)

    def _set_initial_object(self, y_universe, x_universe):
        regression = {
                "listCodes": y_universe.codes,
                "listPremia": x_universe.codes,
                "endDate": datetime2str(today()),
                "listStartDates": [y_universe.last_date],
                "movingWindow": None,
                "testEndDate": None,
                "modelInterval": 250,
                "returnInterval": 'Daily',
                "volScaling": None,
                "selection": 0,
                "signSelect": 0,
                "regOrder": 1
            }
        return regression
    
    def _validate_input(self, Y, X, session):
        x_universe = None
        y_universe = None
        if isinstance(Y, Universe):
            y_universe = Y
        elif isinstance(Y, List):
            y_universe = session.kwargs["universe"].code(Y)
        elif isinstance(Y, Portfolio):
            y_universe = Y.universe

        # Setting universe for list_premia
        if isinstance(X, Universe):
            x_universe = X
        elif isinstance(X, List):
            assert session is not None, console.info(
                SessionError("missing session token")
            )
            x_universe = session.kwargs["universe"].code(X)
        return y_universe, x_universe

    def _check_access_right(self, transformer):
        if not self._session.kwargs.get("track_access", True) and len(self._assets) == 1:
            return "Access to Strategy Track restricted. Please contact Premialab for more info"
        else:
            return transformer.observed_track
    
    # ----- PUBLIC METHODS -----
    def set_start(self, start_date):
        try:
            lower, upper = (
            to_date(max(self.x_universe.last_date, self.y_universe.last_date)),
            self._end,
        )

            if not (lower <= to_date(start_date) <= upper):
                raise RegressionValidationError(
                    f"Trying to set end date {start_date} "
                    f"outside the acceptable range {datetime2str(lower)} "
                    f"to {datetime2str(upper)} "
                )

            self.info['regression']['listStartDates'] = [datetime2str(to_date(start_date))]
        except Exception as e:
            console.info(RegressionValidationError(), exc_info=e)

    def set_end(self, end_date):
        try:
            lower, upper = (
            to_date(max(self.x_universe.last_date, self.y_universe.last_date)),
            to_date(today()),
        )

            if not (lower <= to_date(end_date) <= upper):
                raise RegressionValidationError(
                    f"Trying to set end date {end_date} "
                    f"outside the acceptable range {datetime2str(lower)} "
                    f"to {datetime2str(upper)} "
                )

            self.info['regression']['endDate'] = datetime2str(to_date(end_date))
        except Exception as e:
            console.info(RegressionValidationError(), exc_info=e)

    def set_return_interval(self, return_interval):
        try:
            if return_interval.lower() not in ['daily', 'weekly', 'monthly']:
                raise RegressionValidationError("Return interval must be either Daily, Weekly or Monthly (case insensitive)")

            self.info['regression']['returnInterval'] = return_interval.title()
        except Exception as e:
            console.info(RegressionValidationError(), exc_info=e)

    def set_y(self, Y: Union[Portfolio, Universe, str, List[str]]):
        if isinstance(Y, Universe):
            assert len(Y.codes) == 1, console.info(
                RegressionValidationError("Y length cannot be more than 1")
            )
            self.info['regression']['listCode'] = Y.codes
        elif isinstance(Y, str):
            assert Y in self.session.kwargs["universe"].codes, console.info(
                RegressionValidationError(f"No such code {Y} in universe")
            )
            self.info['regression']['listCodes'] = [Y]
        elif isinstance(Y, list):
            assert Y in self.session.kwargs["universe"].codes, console.info(
                RegressionValidationError(f"No such codes {Y} in universe")
            )
            self.info['regresion']['listCodes'] = Y
        elif isinstance(Y, Portfolio):
            self.info['regression']['listCodes'] = Y.universe.codes
            self.info['portfolio'] = Y.info
        else:
            raise RegressionValidationError("Y variable should be a Portfolio, Universe or list of String")
    
    def set_x(self, X: Union[Universe, List[str]]):
        if isinstance(X, Universe):
            self.info['regression']['listPremia'] = X.codes
        elif isinstance(X, list):
            assert X in self.session.kwargs["universe"].codes, console.info(
                RegressionValidationError(f"No such codes {X} in universe")
            )
            self.info['regresion']['listPremia'] = X
        else:
            raise RegressionValidationError("X variable should be a Universe or list of String")

    def set_lasso(self, selection: int = 0):
        self.info['regression']['selection'] = selection
        self.info['regression']['signSelect'] = 0

    def set_return_interval(self, return_interval: str = "Daily"):
        try:
            if not (
                return_interval.lower()
                in [
                    "daily",
                    "weekly",
                    "monthly",
                ]
            ):
                raise RegressionValidationError(
                    "Interval must be either Daily, Weekly or Monthly (case insensitive)"
                )
            self.info['regression']['returnInterval'] = return_interval.title()
        except Exception as e:
            console.info(RegressionValidationError(), exc_info=e)
        
    def set_rolling_window(self, window: str = None):
        try:
            if not (
                window.lower()
                in [
                    "monthly",
                    "quarterly",
                    "yearly",
                ]
            ):
                raise RegressionValidationError(
                    "Interval must be either Monthly, Quaterly or Yearly (case insensitive)"
                )
            self.info['regression']['movingWindow'] = window.title()
        except Exception as e:
            console.info(RegressionValidationError(), exc_info=e)
    
    def set_model_interval(self, interval: int):
        return_interval_multiple = {
            "Daily": 1,
            "Weekly": 5,
            "Monthly": 25,
        }
        try:
            if not (
                return_interval_multiple[self._return_interval] * interval
                < difference(self._start, self._end)
            ):
                raise RegressionValidationError(
                    "Model Interval invalid, choose a smaller interval"
                )
            self.info['regression']['modelInterval'] = interval
        except Exception as e:
            console.info(RegressionValidationError(), exc_info=e)

    def set_sign_select(self, sign: bool):
        try:
            if not isinstance(sign, bool):
                raise RegressionValidationError(
                    "Input must either be `True` or `False`"
                )

            info_param = 1 if sign else 0

            self.info['regression']['signSelect'] = info_param
            self.info['regression']['selection'] = 0
        except Exception as e:
            console.info(RegressionValidationError(), exc_info=e)
    
    def run_regression(self):
        self.session._validate_configuration()
        try:
            self._validate_regression_build()
            input_json = json.dumps(self.info)
            __extractor = RegressionExtractor(self.session)
            raw_response = __extractor.extract_regression_results(input_json)

            if raw_response.status_code >= 300:
                raise RegressionError(raw_response.json())
            else:
                raw_response = raw_response.json()
                self._transform_regression_results(raw_response)
                self.result = Options._from_dict(self._result_holder)
        except Exception as e:
            console.info(RegressionError(), exc_info=e)

    def _transform_regression_results(self, raw_response):
         __transformer = RegressionTransformer(self._session,
                                             regression_input=self.info,
                                             regression_response=raw_response)

         self._result_holder['params'] = __transformer.params
         self._result_holder['metric'] = __transformer.metric
         self._result_holder['model_summary'] = __transformer.model_summary
         self._result_holder['coefficients_2d'] = __transformer.coefficients_2d
         self._result_holder['coefficients_3d'] = __transformer.coefficients_3d
         self._result_holder['polynomial_r_squared'] = __transformer.polynomial_r_squared
         self._result_holder['observed_track'] = self._check_access_right(__transformer)
         self._result_holder['regression_track'] = __transformer.regression_track
         self._result_holder['cumulated_alpha_track'] = __transformer.cumulated_alpha_track
         self._result_holder['rolling_metric'] = __transformer.rolling_metric
         self._result_holder['rolling_model_summary'] = __transformer.rolling_model_summary
         self._result_holder['rolling_observed_track'] = __transformer.rolling_observed_track
         self._result_holder['rolling_regression_track'] = __transformer.rolling_regression_track
         self._result_holder['rolling_cumulated_alpha_track'] = __transformer.rolling_cumulated_alpha_track
         self._result_holder['tearsheet'] = __transformer.tearsheet
    
    def reset(self):
        self._regression = self._set_initial_object(self.y_universe, self.x_universe)
        self._portfolio = Portfolio(self.y_universe).info if len(self.y_universe.codes) > 1 else None
        self.info = { "regression" : self._regression, "portfolio" : self._portfolio}
        self.result = None
        self._result_holder = {}
