from __future__ import annotations

__all__ = ["PCALoader"]

from plbpy.interface.Universe import Universe
from plbpy import universe as _gl_universe
from plbpy import session as _gl_session
from plbpy.interface.Portfolio import Portfolio
from plbpy.utility.date_utils import (
    datetime2str,
    today,
    to_date,
    date,
    difference,
)
from plbpy.exceptions.class_exceptions import (
    PCAValidationError,
    PCAError,
)

from plbpy.core.extractor.PCAExtractor import PCAExtractor
from plbpy.utility.func_utils import Options

class PCALoader:
    @staticmethod
    def _create_initial_object(universe):
        return {
            'endDate': datetime2str(today()),
            'listStartDates': [universe.last_date],
            'listCodes': universe.codes,
            'covType': 'Covariance',
        }

    def __init__(self, universe, codes, portfolio):
        self._portfolio = None
        self.session = _gl_session
        if universe is not None:
            if isinstance(universe, Universe):
                self.universe = universe
            elif isinstance(universe, Portfolio):
                self.universe = universe.universe
                self._portfolio = universe.info

            elif isinstance(universe, list):
                self.universe = _gl_universe.code(codes)

        self.__extractor = PCAExtractor(self.session)
        self._pca = self._create_initial_object(self.universe)
        self.info = {'pca': self._pca, 'portfolio': self._portfolio}

        self.result = None
        self._result_holder = {}
    # ------------------ PROPERTIES --------------
    @property
    def universe(self):
        return self._universe

    @universe.setter
    def universe(self, value):
        self._universe = value

    @property
    def session(self):
        return self._session

    @session.setter
    def session(self, value):
        self._session = value

    @property
    def info(self):
        return self._info

    @info.setter
    def info(self, value):
        self._info = value

    @property
    def start(self):
        return self._info['pca']['listStartDates'][0]

    @property
    def end(self):
        return self._info['pca']['endDate']

    @property
    def return_interval(self):
        return self._info['pca']['returnInterval']

    @property
    def codes(self):
        return self._info['pca']['listCodes']
    @property
    def type(self):
        return self._info['pca']['covType']

    @property
    def result(self):
        return self._result

    @result.setter
    def result(self, value):
        self._result = value

    def set_start(self, start_date):
        """
        Sets PCA start date

        :param start_date: Date at which PCA should begin. If passing str, date should be in YYYY-MM-DD format
        :type start_date: Union[date, datetime, str]
        :return: Current PCA object with an updated start date
        :rtype: PCA
        :raise AssertionError: If attempting to set start date after end date

        Run PCA with data from 1st Jan 2015

        >>> plbpy.PCA(
                universe = universe.code("SPX", "SBWGU")
            ).set_start('2015-01-01')
        """
        lower, upper = to_date(self.universe.last_date), to_date(self.end)

        if not (lower <= to_date(start_date) <= upper):
            raise PCAValidationError(
                    f"Trying to set start date {start_date} "
                    f"outside the acceptable range {datetime2str(lower)} "
                    f"to {datetime2str(upper)} "
                )

        self.info['pca']['listStartDates'] = [datetime2str(to_date(start_date))]

    def set_end(self, end_date):
        """
        Sets PCA end date

        :param end_date: Date at which PCA should end. If passing str, date should be in YYYY-MM-DD format
        :type end_date: Union[date, datetime, str]
        :return: Current PCA object with an updated end date
        :rtype: PCA
        :raise AssertionError: If attempting to set end date after today

        Run PCA with data until 1st Jan 2020

        >>> plbpy.PCA(
                universe = universe.code("SPX", "SBWGU")
            ).set_end('2020-01-01')
        """

        lower, upper = to_date(self.start), to_date(today())

        if not (lower <= to_date(end_date) <= upper):
            raise PCAValidationError(
                f"Trying to set end date {end_date} "
                f"outside the acceptable range {datetime2str(lower)} "
                f"to {datetime2str(upper)} "
            )

        self.info['pca']['endDate'] = datetime2str(to_date(end_date))

    def set_return_interval(self, return_interval):
        valid = ["daily", "weekly", "monthly", "quarterly", "yearly"]
        if return_interval.lower() not in valid:
            raise PCAValidationError(f"Return interval must be in {valid} (case insensitive)")

        self.info['pca']['varReturnInterval'] = return_interval.title()

    def set_type(self, cov_type):
        valid = ["covariance", "correlation"]
        if cov_type.lower() not in valid:
            raise PCAValidationError(f"Type must be in {valid} (case insensitive)")

        self.info['pca']['covType'] = cov_type.title()

    def _validate_pca_build(self):
        if not (2 <= len(self.universe.codes) <= 50):
            raise PCAValidationError(
                f"Number of tickers ({len(self.universe.codes)}) cannot be more than 50 or less than 2"
            )
        if to_date(self.end) < to_date(self.start):
            raise PCAValidationError(
                f"Start date ({self.start}) must be before end date ({self.end})"
            )

    def run_pca(self):
        self._validate_pca_build()
        self.session._validate_configuration()

        response = self.__extractor.extract_pca_results(self.info)

        if response.status_code >= 300:
            reason = response.json() if response.json() is not None else " "
            raise PCAError(f'{response} {response.status_code} {reason}')
        else:
            response = response.json()
            result_holder = self._transform_results(response)
            self.result = Options._from_dict(result_holder)
        return

    def _transform_results(self, raw):
        from plbpy.core.transformer.PCATransformer import PCATransformer
        __transformer = PCATransformer(pca_input=self.info, pca_response=raw)

        result_holder = {}
        result_holder['params'] = __transformer.params
        result_holder['static_metric'] = __transformer.static_metric
        result_holder['track'] = __transformer.track
        result_holder['weights'] = __transformer.weights
        result_holder['variance_proportion'] = __transformer.variance_proportion
        result_holder['variance_decomposition'] = __transformer.variance_decomposition
        result_holder['raw_api_response'] = raw

        return result_holder

    def reset(self):
        self.info = {'pca': self._create_initial_object(), 'portfolio': self._portfolio}
        self._result_holder = {}
        self.result = Options._from_dict(self._result_holder)
