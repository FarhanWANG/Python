from __future__ import annotations
__all__ = ["SessionLoader"]

from plbpy.core.extractor.SessionExtractor import SessionExtractor
from plbpy.exceptions.class_exceptions import SessionError
import datetime as dt

class SessionLoader:

    def __init__(self, api_key, api_secret, kwargs):
        self.key = api_key
        self.secret = api_secret
        self.kwargs = kwargs
        self.__extractor = SessionExtractor(url=self.kwargs['api_endpoint'], ssl_verify=self.kwargs.get('ssl_verify'))

        self.access_token = None
        self.token_expiry = None

    def _request_token(self):
        header = {'Content-type': 'application/json',
                  'x-api-key': self.key}
        body = {"grant_type": "client_credentials",
                "client_secret": self.secret}

        response = self.__extractor.extract_token(header=header, body=body)

        if response.status_code >= 300:
            reason = response.json() if response.json() is not None else " "
            raise SessionError(f'{response} {response.status_code} {reason}')
        response = response.json()

        self.access_token = response['access_token']
        self.token_expiry = dt.datetime.now() + dt.timedelta(seconds=response['expires_in'])

        return

    def _is_token_expired(self) -> bool:
        """Checks whether token has expired"""
        if self.access_token is not None:
            return True
        else:
            return False

    def _check_token_exists(self) -> bool:
        """Checks whether token exists in the configuration object"""
        if self.token_expiry is None:
            return False
        now = dt.datetime.now()
        if self.token_expiry < now:
            return True
        else:
            return False

    def validate_configuration(self):
        if self._is_token_expired() and self._check_token_exists():
            return
        else:
            self._request_token()

