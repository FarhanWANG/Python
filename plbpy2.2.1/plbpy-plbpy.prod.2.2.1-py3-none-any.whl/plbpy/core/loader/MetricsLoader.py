from __future__ import annotations
__all__ = ["MetricsLoader"]

from typing import Optional

import pandas as pd
import numpy as np

from plbpy import session as _gl_session
from concurrent.futures import ThreadPoolExecutor
import tqdm
from plbpy import session as _gl_universe
from plbpy.interface.Universe import Universe
from plbpy.core.extractor.MetricsExtractor import MetricsExtractor

from plbpy.utility.date_utils import datetime2str, today, to_date, date, datetime, next_business_day

from plbpy.exceptions.class_exceptions import (
    MetricsError,
    SessionError,
    PortfolioError,
)
import json
from plbpy.utility import flatten
from plbpy import console  # Log tools
import copy
from plbpy.core.transformer.MetricsTransformer import MetricsTransformer


class MetricsLoader:
    def __init__(self, session=_gl_session, universe=None, fixed=None, custom=None):
        self.session = session
        self.universe = universe
        self.__extractor = MetricsExtractor(session=self.session)
        self.__transformer = MetricsTransformer()

        if fixed is None:
            input_json = json.dumps({
                'instruments': [{'reference': i, 'referenceType': 'Code'} for i in self.universe.codes]
            })
            try:
                raw_metrics = self.__extractor.extract_metrics(input_json)
            except Exception as e:
                raise e
            if raw_metrics.status_code >= 300:
                raise MetricsError(raw_metrics.json())

            else:
                __fixed_info = raw_metrics.json()

        else:
            __fixed_info = fixed

        __custom_info = [] if custom is None else custom
        self.info = {'fixed': __fixed_info, 'custom': __custom_info}

        self._params = None
        self._codes = universe.codes

        self.fixed = self.__transformer.transform_fixed_metrics(__fixed_info)
        self.custom = None

        self.metric_options = self.__transformer.options()

    def compute_custom_metrics(self, start, end, return_interval='Weekly', **kwargs):
        assert len(self._codes) < 100, "Number of assets must be less than 100 to compute metrics on custom period"
        if return_interval.lower() not in ['daily', 'weekly', 'monthly']:
            raise MetricsError("Return interval must be either Daily, Weekly or Monthly (case insensitive)")

        start = next_business_day(start)
        end = next_business_day(end)

        if to_date(start) >= to_date(end):
            raise MetricsError('Start date must be before end date')
        if to_date(start) < to_date(self.universe.last_date):
            raise MetricsError(f'Start date must be on or after {self.universe.last_date} (universe shortest history)')

        try:
            input_json = json.dumps({
                'instruments': [{'reference': i, 'referenceType': 'Code'} for i in self.universe.codes],
                'customPeriods': [{'startDate': start, 'endDate': end, 'returnInterval': return_interval}]
            })
            raw_custom_metrics = self.__extractor.extract_metrics(input_json)
        except Exception as e:
            raise e

        if raw_custom_metrics.status_code >= 300:
            raise MetricsError(raw_custom_metrics.json())
        else:
            raw_custom_metrics = raw_custom_metrics.json()
            self.info['custom'] = raw_custom_metrics
            self._custom = None # reset dataframe

    # [START] ---------- Fixed Metrics
    @property
    def fixed(self):
        return self._fixed

    @fixed.setter
    def fixed(self, value):
        self._fixed = value

    @property
    def fixed6m(self):
        return self.fixed.xs('6M', level='period').dropna(how='all', axis=0)

    @property
    def fixed1y(self):
        return self.fixed.xs('1Y', level='period').dropna(how='all', axis=0)

    @property
    def fixed3y(self):
        return self.fixed.xs('3Y', level='period').dropna(how='all', axis=0)

    @property
    def fixed5y(self):
        return self.fixed.xs('5Y', level='period').dropna(how='all', axis=0)

    @property
    def fixed10y(self):
        return self.fixed.xs('10Y', level='period').dropna(how='all', axis=0)

    # [END] ---------- Fixed Metrics


    # [START] ----------- Custom Metrics

    @property
    def custom(self) -> pd.DataFrame:
        if self._custom is None:
            if len(self.info['custom']) == 0:
                raise MetricsError('No custom metrics found. Please use plb.universe.compute_metrics()')

            self._custom = self.__transformer.transform_custom_metrics(info=self.info['custom'])
        return self._custom

    @custom.setter
    def custom(self, value):
        self._custom = value

    # [END] ------------ Custom Metrics

    def screen(self, metric, minimum=None, maximum=None, period='1Y', rank='all'):
        assert metric in list(self.__transformer._metric_mapping.values()), "Invalid Metric. Please check plbpy.universe.metric_options object for valid values"

        minimum = minimum if minimum is not None else -np.inf
        maximum = maximum if maximum is not None else np.inf

        minimum = float(minimum) if isinstance(minimum, int) else minimum
        maximum = float(maximum) if isinstance(maximum, int) else maximum

        assert isinstance(minimum, float), f'bounds must be of float or int type, received {minimum} or type {type(minimum)}'
        assert isinstance(maximum, float), f'bounds must be of float or int type, received {maximum} or type {type(maximum)}'
        assert maximum >= minimum, 'Lower bound cannot be higher than upper bound'

        period = np.array([period]).flatten()
        assert len(period.shape) == 1, "Check period type. Must be a string or a flat list"
        period = period.tolist()

        valid = ['6m', '1y', '3y', '5y', '10y', 'custom']

        assert all([i.lower() in valid for i in period]), "Period must be one of "+' '.join(valid)

        rank_params = rank.split(' ')
        if len(rank_params) == 1:
            assert rank_params[0].lower() == 'all', f"Rank must either be top/bottom N or all, received {rank_params[0]}"

        elif len(rank_params) == 2:
            assert rank_params[0].lower() in ['top','bottom'], f"Rank must either be top/bottom N or all, received {rank_params[0]}"
            try:
                rank_num = float(rank_params[1])
            except ValueError:
                raise MetricsError(f"In top N, N must be a number, received {rank_params[1]}")

        if period[0].lower() != 'custom':
            return self._screen_fixed(metric, minimum, maximum, period, rank_params)
        else:
            return self._screen_custom(metric, minimum, maximum, rank_params)

    def _screen_fixed(self, metric, minimum, maximum, period='1Y', rank_params=['all']):
        period = list(map(lambda x: x.lower(), period))
        target_info = [i for i in self.info['fixed'] if i['period'] in period][0]

        reverse_mapping = {value: key for key, value in self.__transformer._metric_mapping.items()}
        metric = reverse_mapping[metric]

        # ------------ Screen Metrics ----------------
        screened_dict = {i['instruments']['reference']: i[metric] for i in target_info['metrics'] if metric in list(i.keys())\
                             and i[metric] is not None\
                             and float(i[metric] >= minimum)\
                             and float(i[metric] <= maximum)
                         }

        # ------------- Handle Ranking ---------------
        if rank_params[0] == 'all':
            screened_codes = list(screened_dict.keys())
        else:
            pos = rank_params[0].lower()
            num = int(rank_params[1])

            # sort dict based on metrics
            sorted_dict = {k: v for k, v in sorted(screened_dict.items(), key=lambda item: item[1], reverse=True)}
            screened_codes = list(sorted_dict.keys())

            if len(screened_codes) <= num:
                pass
            else:
                if pos == 'top':
                    screened_codes = screened_codes[0:num]
                elif pos == 'bottom':
                    screened_codes = screened_codes[-num:]

        if len(screened_codes) == 0:
            raise MetricsError('No assets found with the current screen parameters')

        return screened_codes

    def _screen_custom(self, metric, minimum, maximum, rank_params):

        assert len(self.info['custom']) > 0,'No custom metrics found'

        reverse_mapping = {value: key for key, value in self.__transformer._metric_mapping.items()}
        metric = reverse_mapping[metric]

        # ------------ Screen Metrics ----------------
        screened_dict = {i['instruments']['reference']: i[metric] for i in self.info['custom'][0]['metrics'] if
                         metric in list(i.keys())\
                         and i[metric] is not None\
                         and float(i[metric] >= minimum)\
                         and float(i[metric] <= maximum)
                         }

        # ------------- Handle Ranking ---------------
        if rank_params[0] == 'all':
            screened_codes = list(screened_dict.keys())
        else:
            pos = rank_params[0].lower()
            num = int(rank_params[1])

            # sort dict based on metrics
            sorted_dict = {k: v for k, v in sorted(screened_dict.items(), key=lambda item: item[1], reverse=True)}
            screened_codes = list(sorted_dict.keys())

            if len(screened_codes) <= num:
                pass
            else:
                if pos == 'top':
                    screened_codes = screened_codes[0:num]
                elif pos == 'bottom':
                    screened_codes = screened_codes[-num:]

        if len(screened_codes) == 0:
            raise MetricsError('No assets found with the current screen parameters')

        return screened_codes

    @property
    def metric_options(self):
        return self._metric_options

    @metric_options.setter
    def metric_options(self, value):
        self._metric_options = value

    @property
    def params(self):
        return self.__transformer.transform_params(self.info)
