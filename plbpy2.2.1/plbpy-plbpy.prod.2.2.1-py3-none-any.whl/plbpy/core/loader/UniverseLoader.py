from __future__ import annotations
__all__ = ["UniverseLoader"]


from typing import Optional
from plbpy import log_factory, DEBUG, INFO, logger, console
from plbpy.core.extractor.UniverseExtractor import UniverseExtractor
from plbpy.core.transformer.UniverseTransformer import UniverseTransformer
from plbpy.exceptions.class_exceptions import (
    UniverseError
)
import json


class UniverseLoader:
    def __init__(self, session, metadata):
        self.session = session
        self.__extractor = UniverseExtractor(self.session)
        self.__transformer = UniverseTransformer()
        self.metadata = metadata

    def request_funds(self, ids=[], idType="Morningstar", **kwargs):
        ids = [ids] if isinstance(ids, str) else ids
        assert isinstance(ids, list), "Input ids must be type list or string"
        assert all(map(lambda x: isinstance(x, str), ids)), "Input should be a list of type strings"

        if len(ids) > 200:
            raise UniverseError('Cannot request more than 200 funds at a time')

        idTypeList = ['isin', 'morningstar', 'mstar', 'mstarid']
        if idType.lower() not in idTypeList:
            raise UniverseError("IdType should be one of the following: " + ', '.join(idTypeList))

        type='ISIN' if idType.lower() == idTypeList[0] else 'Morningstar'
        source = kwargs.pop('source','Morningstar')
        input_dict = {
            "provider": source,
            "idType": type,
            "idList": ids,
            "selectOption": "PrimaryShareClass",
            "isinFamily": ""
            }

        input_json = json.dumps(input_dict)

        limit_json = self.__extractor.get_limit().json()

        console.info("Requesting " + str(len(ids))+ " fund(s) from Morningstar\n")
        console.info(f"{source} Limit:")
        console.info("Already Requested: " + str(limit_json['consumed']))
        console.info("Remaining: " + str(limit_json['limit'] - limit_json['consumed']) + "\n")
        console.info("Please re-initialize universe to get new funds ( use plb.Universe() )")

        bufferSize = (1.25 * limit_json['limit']) - limit_json['consumed']
        if ( ( bufferSize > 0) and (len(ids) < bufferSize)):
            response = self.__extractor.POST_data(input_json)
            if response.status_code != 201:
                raise UniverseError(response.json())
        else:
            console.info("Morningstar Limit Exceeded. Please contact PremiaLab for more info")

    def get_static_info(self):
        try:
            self.session._validate_configuration()
            raw_response = self.__extractor.get_static_info()
            if raw_response.status_code >= 300:
                raise UniverseError(raw_response.status_code)
            else:
                return raw_response.json()
        except Exception as e:
            raise e

    @property
    def metadata(self):
        if self._metadata is None:
            logger.debug("Pulling Universe Static Information")
            self._metadata = self.get_static_info()

        return self._metadata

    @metadata.setter
    def metadata(self, value):
        self._metadata = value

    def to_frame(self):
        assert len(self.metadata) != 0, f"0 objects to show. Check filters"
        return self.__transformer.transform_metadata(self.metadata)

    @staticmethod
    def _verify_extract(raw, codes):
        error = []
        passed = {}
        for cnt,prices in enumerate(raw):
            if prices.status_code >= 300:
                error.append(codes[cnt])
            else:
                passed[codes[cnt]] = prices.json()
        return passed, error

    def tracks(self, threads, start, end, codes, **kwargs):
        assert len(codes) < 200, "Please pass less than 200 assets"

        from plbpy.utility.date_utils import datetime2str, today
        if start is not None and end is None:
            end = datetime2str(today())

        from concurrent.futures import ThreadPoolExecutor
        import tqdm

        with ThreadPoolExecutor(max_workers=threads) as executor:
            params = [{'code': c, 'start': start, 'end': end} for c in codes]
            call_api = lambda x: self.__extractor.extract_prices(**x)
            if kwargs.pop('show_progress', False):
                result = list(tqdm.tqdm(executor.map(call_api, params), total=len(codes), desc='Extracting Timeseries'))
            else:
                result = list(executor.map(call_api, params))

        passed, error = self._verify_extract(result, codes)
        if len(error) > 0:
            console.info(f"Error retrieving {len(error)} timeseries: {' '.join(error)}")

        df = self.__transformer.transform_tracks(passed)
        if kwargs.pop('direct', False):
            return df
        else:
            from plbpy.utility.func_utils import Options
            # only for backward compatibility. Will be removed in future versions
            def temp(df=df):
                return df
            return Options._from_dict({'to_frame':temp})
