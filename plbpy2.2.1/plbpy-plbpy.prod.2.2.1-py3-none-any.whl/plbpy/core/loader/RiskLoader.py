"""
The RiskLoader class is used to help the client facing Risk communicate with raw API endpoint. This class transforms the inputs from client and output from the endpoint
"""
__all__ = ["RiskLoader"]

from typing import List, Optional, Union, Dict


from plbpy.utility.func_utils import Options
from plbpy.utility.string_utils import flatten, flatten_irregular
from plbpy.utility.date_utils import to_date, date, datetime
from plbpy.interface.Universe import Universe
from plbpy.core.extractor.RiskExtractor import RiskExtractor
from plbpy.core.transformer.RiskTransformer import RiskTransformer
import pandas as pd
import warnings
import numpy as np

warnings.filterwarnings("ignore")


class RiskLoader:
    @staticmethod
    def _this_in_that(this: list, that: list, **kwargs):
        """
        Check if all this is a subset of that
        """
        if any([i not in that for i in this]):
            raise AttributeError(kwargs.pop("message", "All inputs must be in list"))

    def __init__(self, session):

        self.id = ""
        self.session = session
        self.__extractor = RiskExtractor(self.session)
        self.__transformer = RiskTransformer()
        self.portfolios = self.__transformer.transform_portfolio_ids(
            self.__extractor.call_portfolio_ids()
        )

    def set_id(self, value):
        self.id = value
        self.__extractor.set_slug(self.id)

        raw_output = self.__extractor.call_available_dates()
        self.available_dates = self.__transformer.transform_dates(raw_output)
        self.instrument_count = self.__transformer.transform_instrument_count(
            raw_output
        )
        self.strategy_values = self.__transformer.transform_strategy_values(
            self.__extractor.call_strategy_values(self.available_dates)
        )

        universe = Universe(self.session).code(list(set(self.strategy_values.columns)))
        try:
            self.static_info = self.__transformer.transform_static_info(
                self.strategy_values, universe
            )
        except:
            self.static_info = pd.DataFrame()

        self.available_strategies = self.strategy_values.columns.tolist()

        raw_options = self.__extractor.call_options(self.available_dates)
        self.options = self.__transformer.transform_options(raw_options, metrics=True)
        self.segments = self.__transformer.transform_options(raw_options, segments=True)

    @property
    def id(self):
        return self._id

    @id.setter
    def id(self, value):
        self._id = value

    @property
    def portfolios(self):
        return self._portfolios

    @portfolios.setter
    def portfolios(self, value):
        self._portfolios = value

    @property
    def available_dates(self):
        assert (
            self.id != ""
        ), "Please set portfolio id first using plb.Risk.set_id(<portfolio_id>) function"
        return self._available_dates

    @available_dates.setter
    def available_dates(self, value):
        self._available_dates = value

    @property
    def strategy_values(self):
        assert (
            self.id != ""
        ), "Please set portfolio id first using plb.Risk.set_id(<portfolio_id>) function"
        return self._strategy_values

    @strategy_values.setter
    def strategy_values(self, value):
        self._strategy_values = value

    @property
    def options(self):
        assert (
            self.id != ""
        ), "Please set portfolio id first using plb.Risk.set_id(<portfolio_id>) function"
        return self._options

    @options.setter
    def options(self, value):
        self._options = value

    @property
    def segments(self):
        assert (
            self.id != ""
        ), "Please set portfolio id first using plb.Risk.set_id(<portfolio_id>) function"
        return self._segments

    @segments.setter
    def segments(self, value):
        self._segments = value

    @property
    def static_info(self):
        assert (
            self.id != ""
        ), "Please set portfolio id first using plb.Risk.set_id(<portfolio_id>) function"
        return self._static_info

    @static_info.setter
    def static_info(self, value):
        self._static_info = value

    @property
    def available_strategies(self):
        assert (
            self.id != ""
        ), "Please set portfolio id first using plb.Risk.set_id(<portfolio_id>) function"
        return self._available_strategies

    @available_strategies.setter
    def available_strategies(self, value):
        self._available_strategies = value

    def get_api_metrics(
        self,
        metrics: List[str],
        aggregate_by: List[str] = ["Strategy"],
        filter_by: Optional[Dict[str, List[str]]] = None,
        start: Union[str, date, datetime] = None,
        end: Union[str, date, datetime] = None,
        threads: int = 15,
        **kwargs,
    ) -> pd.DataFrame:
        """
        Accepts inputs from clients requesting metrics. Validates inputs and send to API endpoint.
        Parses the raw api output into a dataframe and sends to client
        """

        # Validate all inputs first before sending to API endpoint
        assert (
            self.id != ""
        ), "Please set portfolio id first using plb.Risk.set_id(<portfolio_id>) function"

        assert isinstance(filter_by, dict) or (
            filter_by is None
        ), "Please input a dictionary of filters. Example { 'Segment': [ 'Asset Category', 'Currency' ] }"

        version = kwargs.get("version")

        # --- Metrics validation
        if not isinstance(metrics, list):
            metrics = [metrics]
        for cnt, m in enumerate(metrics):
            if isinstance(m, Options):
                metrics[cnt] = list(metrics[cnt].__dict__.values())
        metrics = flatten_irregular(metrics)
        possible_metric_values = flatten(
            [list(vars(v).values()) for v in vars(self.options).values()]
        )
        self._this_in_that(
            this=metrics, that=possible_metric_values, message="Risk Metric not valid"
        )

        # ---- aggregate_by validation
        if not isinstance(aggregate_by, list):
            aggregate_by = [aggregate_by]
        possible_segment_values = flatten(
            [list(vars(v).values()) for v in vars(self.segments).values()]
        )
        self._this_in_that(
            this=aggregate_by,
            that=possible_segment_values,
            message="Aggregate key not valid",
        )

        # ---- filter_by validation
        if filter_by is not None:
            filter_by = (
                [[k, v] for k, v in filter_by.items()] if version == 1 else filter_by
            )
            filter_categories = (
                [i[0] for i in filter_by] if version == 1 else filter_by.keys()
            )
            for i in filter_categories:
                self._this_in_that(
                    this=[i],
                    that=possible_segment_values,
                    message=f"Filter key `{i}` not valid",
                )

            filter_by = [{'segment': k,'value': v} for k,v in  filter_by.items()]

        # ---- create date range
        d1 = to_date(start) if start else to_date(self.available_dates[0])
        d2 = to_date(end) if end else to_date(self.available_dates[-1])
        date_range = list(
            filter(lambda x: d1 <= to_date(x) <= d2, self.available_dates)
        )

        d1 = d1.strftime("%Y-%m-%d")
        d2 = d2.strftime("%Y-%m-%d")

        input_json = {'startDate':d1, 'endDate':d2, 'fields':metrics, 'groupBy':aggregate_by, 'filterBy':filter_by}

        raw_data = self.__extractor.call_metrics_api_v2(input_json)

        # return raw_data
        if raw_data:
            clean_data = self.__transformer.transform_metrics_output_v2(
                raw_data, aggregate_by
            )

            return clean_data
        else:
            return raw_data