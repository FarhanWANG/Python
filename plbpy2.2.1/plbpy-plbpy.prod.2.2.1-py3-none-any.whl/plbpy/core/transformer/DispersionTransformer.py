"""
Initializes a Dispersion Parser object used by :func:`Dispersion <plbpy.interface.Dispersion>` to parse raw API outputs. This class is used to represent Dispersion computation results in a clean and readable way.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from typing import Union, List, Dict

from plbpy.utility.date_utils import to_date, date


class DispersionTransformer:
    def __init__(self, dispersion_input, dispersion_response, universe):
        self._request = dispersion_input
        self._response = dispersion_response
        self.universe = universe

    # --- Private DispersionParser members ---
    @property
    def universe(self):
        return self._universe

    @universe.setter
    def universe(self, value):
        self._universe = value

    @property
    def _response(self):
        return self._api_response

    @_response.setter
    def _response(self, value):
        self._api_response = value

    @property
    def _request(self):
        return self._api_input

    @_request.setter
    def _request(self, value):
        self._api_input = value

    @property
    def session(self):
        return self._session

    @session.setter
    def session(self, value):
        self._session = value

    # --- Private Request Parser Members ---
    @property
    def _subset_assets(self):
        return self._request['subset']

    @property
    def _assets(self):
        return self._request['list_codes']

    @property
    def _metric(self):
        return self._request['metric']

    @property
    def _interval(self):
        return self._request['returnInterval']

    @property
    def _window(self):
        return self._request['rollingWindow']

    # ----------- Private Response Members ------------------
    @property
    def _start(self):
        return self._response['startDate']

    @property
    def _end(self):
        return self._response['endDate']

    @property
    def _subset_dispersion(self):
        return self._response['subsetDispersion']

    @property
    def _dates(self):
        return list(map(to_date, self._response['timeseriesDates']))

    @property
    def _asset_dispersion(self):
        return self._response['universeDispersion']

    @property
    def _asset_average(self):
        return self._response['universeAverage']

    # ------ Public Response Parser Members ------
    @property
    def params(self) -> Union[pd.DataFrame, Dict[str, float]]:
        """
        Gets basic information about the computation. These include:
        - Start and End dates of track record
        - Performance Metric
        - Return Interval
        - Rolling Window

        :rtype: Union[pd.DataFrame, Dict[str, float]]

        """
        p = {
            "Start": self._start,
            "End": self._end,
            "Metric": self._metric,
            "Return Interval": self._interval,
            "Window": self._window,
        }

        return pd.DataFrame(p, index=["Dispersion"])

    def subset_dispersion(
        self, kind="dataframe"
    ) -> Union[pd.DataFrame, List[List[Union[date, float]]]]:
        """
        Creates a timeseries of the given metric for each subset asset

        :rtype: Union[pd.DataFrame, List[List[Union[date, float]]]]

        """
        assert kind in [
            "dataframe",
            "graph",
            "raw",
        ], f"Invalid argument {kind} Must be either dataframe, graph, raw"

        if kind == "dataframe":
            df = pd.DataFrame(
                data=np.array(self._subset_dispersion),
                index=list(map(to_date, self._dates)),
                columns=self._subset_assets,
            )
            return df.astype(float).round(4)
        elif kind == "graph":
            from plbpy.visualizer.DispersionVisualiser import DispersionVisualiser

            viz = DispersionVisualiser(parsed_response=self)
            viz.draw_subset_dispersion()

    def universe_dispersion(
        self, kind="dataframe", **mpl_kwargs
    ):
        """
        Creates a timeseries of the given performance metric for the whole universe. For each timestamp the following values can be found:
        - Minimum and Maximum value
        - Median and Average
        - 25th and 75th Percentile

        :rtype: Union[pd.DataFrame, List[List[Union[date, float]]]]

        """
        assert kind in [
            "dataframe",
            "graph",
            "raw",
        ], f"Invalid argument {kind} Must be either dataframe, graph, raw"
        if kind == "dataframe":
            df = pd.DataFrame(
                data=np.append(
                    np.array(self._asset_dispersion),
                    np.array(self._asset_average).reshape(-1, 1),
                    axis=1,
                ),
                index=list(map(to_date, self._dates)),
                columns=["Min", "25%", "Median", "75%", "Max", "Average"],
            ).dropna(how="all", axis=0)
            return df.astype(float).round(4)

        elif kind == "graph":
            from plbpy.visualizer.DispersionVisualiser import DispersionVisualiser

            viz = DispersionVisualiser(parsed_response=self)
            fig, lineplot_ax, kdeplot_ax = viz.draw_dispersion_chart(**mpl_kwargs)
            return fig, lineplot_ax, kdeplot_ax
