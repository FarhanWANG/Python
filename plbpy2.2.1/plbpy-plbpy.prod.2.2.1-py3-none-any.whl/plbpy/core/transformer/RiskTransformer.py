import pandas as pd
import numpy as np
from plbpy.exceptions.class_exceptions import RiskDataException
from plbpy.utility.func_utils import parse_options, parse_segments, Options
from plbpy.utility.string_utils import flatten


class RiskTransformer:
    @staticmethod
    def _filter_data(data, filter_by: list):
        if isinstance(filter_by, dict):
            filter_by = [[key, value] for key, value in filter_by.items()]

        for f in filter_by:
            if not isinstance(f[1], list):
                f[1] = [f[1]]
            if f[0] in data.columns.tolist():
                data = data[data[f[0]].isin(f[1])]
            else:
                pass
            if len(data) == 0:
                raise RiskDataException(
                    "No data matching filter_by criteria\nRaised at: {} = {} ".format(
                        f[0], f[1]
                    )
                )
        try:
            data.sort_values(by="Date", inplace=True)
        except Exception:
            data.sort_values(by="date", inplace=True)

        return data

    def __init__(self):
        pass

    def transform_dates(self, raw_output) -> list:
        return sorted([i['date'] for i in raw_output])

    def transform_instrument_count(self, raw_output) -> dict:
        return {i['date']: sum([float(j['value']) for j in i['count']]) for i in raw_output}

    def transform_strategy_values(self, raw_strategy_value) -> pd.DataFrame:
        df = (
            pd.DataFrame(raw_strategy_value)
            .set_index(["date", "name"])
            .unstack()
            .T.xs("value")
            .T
        )
        df.index = pd.to_datetime(df.index)
        df = df.replace(0.0, np.nan).astype(float)

        return df

    def transform_portfolio_ids(self, raw_output) -> Options:
        return Options._from_dict({i.replace("-", "_"): i for i in raw_output})

    def transform_static_info(self, strategy_values, universe):
        df = universe.to_frame().drop("history_start_date", axis=1)

        for index, row in df.iterrows():
            df.loc[index, "risk_start_date"] = strategy_values[
                index
            ].first_valid_index()
            df.loc[index, "risk_end_date"] = strategy_values[index].last_valid_index()
            df.loc[index, "gaps"] = strategy_values[index].isna().sum()

        return df

    def transform_options(self, raw_options, **kwargs):
        if kwargs.pop("metrics", False):
            return parse_options(raw_options["riskMetrics"])
        if kwargs.pop("segments", False):
            return parse_segments(raw_options["riskMetrics"])

    def transform_metrics_output(self, raw_data, metrics, filter_by, aggregate_by):
        df = pd.DataFrame(flatten(raw_data))

        if filter_by is not None:
            df = self._filter_data(df, filter_by)

        date_col = "Date"

        df = (
            df[df["Instrument"] != "No Instrument"][[date_col] + aggregate_by + metrics]
            .set_index([date_col] + aggregate_by)
            .replace(0.0, np.nan)
            .fillna(0.0)
        )

        if all(["Standalone" not in i for i in metrics]):
            df = df.groupby(level=[date_col] + aggregate_by)[metrics].sum()

        return df

    def transform_metrics_output_v2(self, raw_data, aggregate_by):
        df = pd.DataFrame(raw_data).rename(columns={"date": "Date"}).set_index(["Date"])
        df.index = pd.to_datetime(df.index)
        df = (
            df.reset_index()
            .set_index(["Date"] + aggregate_by)
            .replace(0.0, np.nan)
            .astype(float)
            .fillna(0.0)
        )
        return df

    def transform_summary_output(self, raw_data):
        df = pd.DataFrame(flatten(raw_data))
        df = df.set_index(["position_date", "strategy_ticker"])

        return df
