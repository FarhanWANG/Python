"""
Module to access universe metrics results. Properties of this module can be accessed via the result property of Portfolio construction module
"""


from __future__ import annotations
__all__ = ["MetricsTransformer"]

from plbpy.utility import datetime2str,to_date, date
import numpy as np
import pandas as pd
import json
from plbpy.utility.func_utils import Options


class MetricsTransformer:
    def __init__(self):
        pass

    @property
    def _metric_mapping(self):
        return {
            'returnPA': 'Return p.a.',
            'returnCumulated': 'Cumulative Return',
            'volatility': 'Volatility',
            'sharpe': 'Sharpe Ratio',
            'infoRatio':'Info Ratio',
            'skew': 'Skew',
            'kurtosis': 'Kurtosis',
            'sortino': 'Sortino Ratio',
            'maxDD': 'Max Drawdown',
            'avgDD': 'Avg Drawdown',
            'omega': 'Omega Ratio',
            'calmar': 'Calmar Ratio',
            'var': 'VaR',
            'modVar': 'MVaR',
            'cvar': 'CVaR',
            'worst20d':'Worst 20D',
            'autocor':'Autocorrelation',
            'percentPosWeeks':'Positive Weeks (%)',
            'percentPosMonths':'Positive Months (%)',
            'startDate':'Start',
            'endDate':'End'
        }

    @staticmethod
    def transform_params(info):
        dates = [{'Period': i['period'], 'Start': i['startDate'], 'End': i['endDate']} for i in info['fixed']]
        if len(info['custom']) > 0:
            custom = info['custom'][0]
            dates.append({'Period': custom['period'], 'Start': custom['startDate'], 'End': custom['endDate']})

        return pd.DataFrame(dates).set_index('Period')

    def transform_fixed_metrics(self, info):
        if len(info) == 0:
            return pd.DataFrame()
        else:
            raw_df = pd.DataFrame(info).explode('metrics')
            raw_df = pd.json_normalize(raw_df['metrics']).join(raw_df.reset_index(drop=True).drop('metrics', axis=1))
            fixed = raw_df.rename(columns={'instruments.reference': 'code'})
            fixed['period'] = [i.upper() if isinstance(i,str) else i for i in fixed['period'].tolist()]

            try:
                fixed = fixed.set_index(['code','period']).drop(
                    ['instruments.referenceType','startDate','endDate'], axis=1)

                fixed.columns = map(lambda x: self._metric_mapping[x], fixed.columns)
            except:
                pass

            return fixed.sort_index()

    def transform_custom_metrics(self, info):
        if len(info) == 0:
            return pd.DataFrame()
        else:
            s, e = to_date(info[0]['startDate']).strftime('%d %b\'%y'), to_date(info[0]['endDate']).strftime(
                '%d %b\'%y')
            raw_df = pd.DataFrame(info).explode('metrics')
            raw_df = pd.json_normalize(raw_df['metrics']).join(raw_df.reset_index(drop=True).drop('metrics', axis=1))
            custom = raw_df.rename(columns={'instruments.reference': 'code'})
            try:
                custom = custom.set_index(['code']).drop(
                    ['instruments.referenceType','period', 'startDate','endDate'], axis=1)

                custom.columns = map(lambda x: self._metric_mapping[x], custom.columns)
            except:
                pass
            custom.columns.name = f'{s} - {e}'


            return custom

    @staticmethod
    def _transform_string(string):
        return string.replace('(','').replace(')','').replace(' ','_').replace('%','pct').replace('.','_')

    def options(self):
        opts = {self._transform_string(value): value for key, value in self._metric_mapping.items()}
        return Options._from_dict(opts)




