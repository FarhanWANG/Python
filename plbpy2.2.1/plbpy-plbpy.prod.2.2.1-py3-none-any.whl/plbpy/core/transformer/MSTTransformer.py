from __future__ import annotations
__all__ = ["MSTTransformer"]

from plbpy.utility.date_utils import to_date, date
import numpy as np
import pandas as pd
import json

class MSTTransformer:

    def __init__(self, mst_input, mst_response, universe):
        self._request = mst_input
        self._response = mst_response
        self.universe = universe

    # ----------- MSTParser members ------------------
    @property
    def universe(self):
        return self._universe

    @universe.setter
    def universe(self, value):
        self._universe = value

    @property
    def _response(self):
        return self._api_response

    @_response.setter
    def _response(self, value):
        self._api_response = value

    @property
    def _request(self):
        return self._api_input

    @_request.setter
    def _request(self, value):
        self._api_input = value

    # -----------Private Request Parser Members ------------------
    @property
    def _correlation_type(self):
        return self._request['correlationType']

    @property
    def _correlation_interval(self):
        return self._request['returnInterval']

    # ----------- Private Response Members ------------------
    @property
    def _start(self):
        return self._response['startDate']

    @property
    def _end(self):
        return self._response['endDate']

    @property
    def _tickers(self):
        return [i['ticker'] for i in self._response['positions']]

    @property
    def _parents(self):
        return [i['parent'] for i in self._response['positions']]

    @property
    def _xlist(self):
        return [i['x'] for i in self._response['positions']]

    @property
    def _ylist(self):
        return [i['y'] for i in self._response['positions']]

    # ------ Public Response Parser Members ------

    @property
    def params(self):
        """
        Gets basic information about the computation. These include:
        - Start and End dates
        - Number of input assets
        - Correlation Type
        - Return Interval

        :rtype: Union[pd.DataFrame, Dict[str, float]]

        """
        p = {
            "Start": self._start,
            "End": self._end,
            "Tickers": len(self._tickers),
            "Correlation Type": self._correlation_type,
            "Return Interval": self._correlation_interval,
        }

        return pd.DataFrame(p, index=["MST"])

    def tree(self, kind="graph", **mpl_kwargs):
        """
        Get the (x,y) coordinates and parent of each node in the universe

        :rtype: Union[pd.DataFrame, Dict[float, str]]
        """
        assert kind in [
            "dataframe",
            "graph",
        ], f"Invalid argument {kind} Must be either dataframe, graph, raw"
        pos = {
            "Ticker": self._tickers,
            "Parent": self._parents,
            "x": self._xlist,
            "y": self._ylist,
        }
        if kind == "dataframe":
            return pd.DataFrame(pos)
        else:
            from plbpy.visualizer.MSTVisualiser import MSTVisualiser
            viz = MSTVisualiser(parsed_response=self)

            if mpl_kwargs.pop("interactive", False):
                return viz.draw_plotly_tree(**mpl_kwargs)
            else:
                fig, ax = viz.draw_seaborn_tree(**mpl_kwargs)
                return fig, ax

