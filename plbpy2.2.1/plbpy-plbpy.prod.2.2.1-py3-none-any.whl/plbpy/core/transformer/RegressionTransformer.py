from __future__ import annotations
__all__ = ["RegressionTransformer"]

from plbpy.utility.date_utils import to_date, date
import numpy as np
import pandas as pd
from typing import List, Union, Dict


class RegressionTransformer:

    def __init__(self,
                 session,
                 regression_input,
                 regression_response):
        self._session = session
        self._request = regression_input
        self._response = regression_response

    
    # ----- PRIVATE REGRESSION TRANSFORMER MEMBERS -----
    @property
    def _response(self):
        return self._api_response

    @_response.setter
    def _response(self, value):
        self._api_response = value

    @property
    def _request(self):
        return self._api_input

    @_request.setter
    def _request(self, value):
        self._api_input = value

    @property
    def _session(self):
        return self.__session

    @_session.setter
    def _session(self, value):
        self.__session = value

    # ----- PRIVATE REQUEST PARSER MEMBERS -----
    @property
    def _regression_type(self) -> str:
        return "Portfolio" if self._request['portfolio'] is not None else "Strategy"

    @property
    def _input_dependent_variable(self):
        return (
            "Portfolio"
            if self._regression_type == "Portfolio"
            else self._request['regression']['listCodes'][0]
        )

    @property
    def _input_factors(self) -> list:
        return self._request['regression']['listPremia']

    @property
    def _lasso(self):
        return self._request['regression']['selection']

    @property
    def _sign_select(self):
        return self._request['regression']['signSelect']

    @property
    def _return_interval(self):
        return self._request['regression']['returnInterval']

    @property
    def _rolling_window(self):
        return self._request['regression']['movingWindow']

    @property
    def _rolling_return_interval(self):
        return self._request['regression']['modelInterval']

    # --- PRIVATE RESPONSE PARSER MEMBERS ---

    @property
    def _observations(self):
        return int(self._response['noElements'])

    @property
    def _r2(self):
        return self._response['rSquared'] * 100

    @property
    def _r2_adjusted(self):
        return self._response['rSquaredAdj'] * 100

    @property
    def _f_prob(self):
        return self._response.get('fProb', None)

    @property
    def _f_stat(self):
        return self._response.get('fStat', None)

    @property
    def _start(self):
        return to_date(self._response['startDate'])

    @property
    def _end(self):
        return to_date(self._response['endDate'])

    @property
    def _active_premia(self):
        return list(map(int, self._response['activePremia']))

    @property
    def _betas(self):
        return self._response['beta']

    @property
    def _betas_error(self):
        return self._response['betaSE']

    @property
    def _betas_lower_bound(self):
        return self._response['lowerBound']

    @property
    def _betas_upper_bound(self):
        return self._response['upperBound']

    @property
    def _p_values(self):
        return self._response['pValue']

    @property
    def _t_stat(self):
        return self._response['tStat']

    @property
    def _poly_2df(self):
        return self._response['polyCoeff'][0]

    @property
    def _poly_3df(self):
        return self._response['polyCoeff'][1]

    @property
    def _return_attribution(self):
        return self._response['returnAttribution']

    @property
    def _return_proportion(self):
        return list(map(lambda x: x * 100, self._response['returnProp']))

    @property
    def _variance_attribution(self):
        return self._response['varAttribution']

    @property
    def _variance_proportion(self):
        return list(map(lambda x: x * 100, self._response['varProp']))

    @property
    def _dates(self):
        return list(map(to_date, self._response['timeseriesDates']))

    @property
    def _track_observed(self):
        return self._response['timeseriesObserved']

    @property
    def _track_regression(self):
        return self._response['timeseriesReplicated']

    @property
    def _track_cumulated_difference(self):
        return self._response['timeseriesCumDiff']

    @property
    def _polynomial_r_squared_residuals(self):
        return self._response['polyRSquared']

    @property
    def _polynomial_r_squared_portfolio(self):
        return self._response['polyRSquaredPft']
    # --- Rolling Properties ---

    @property
    def _rolling_r2(self):
        return list(map(lambda x: x * 100, self._response['rollingRSquared']))

    @property
    def _rolling_r2_adjusted(self):
        return list(map(lambda x: x * 100, self._response["rollingRSquaredAdj"]))

    @property
    def _rolling_f_prob(self):
        return self._response['rollingFProb']

    @property
    def _rolling_f_stat(self):
        return self._response['rollingFStat']

    @property
    def _rolling_dates(self):
        return list(map(to_date, self._response['rollingDates']))

    @property
    def _rolling_betas(self):
        return self._response['rollingBeta']

    @property
    def _rolling_betas_error(self):
        return self._response['rollingBetaSE']

    @property
    def _rolling_betas_lower_bound(self):
        return self._response['rollingLowerBound']

    @property
    def _rolling_betas_upper_bound(self):
        return self._response['rollingUpperBound']

    @property
    def _rolling_p_values(self):
        return self._response['rollingPValue']

    @property
    def _rolling_t_stat(self):
        return self._response['rollingTStat']

    @property
    def _rolling_return_attribution(self):
        return self._response['rollingReturnAttribution']

    @property
    def _rolling_variance_attribution(self):
        return self._response['rollingVarAttribution']

    @property
    def _rolling_return_proportion(self):
        return self._response['rollingReturnProp']

    @property
    def _rolling_variance_proportion(self):
        return self._response['rollingVarProp']

    @property
    def _rolling_timeseries_dates(self):
        return list(map(to_date, self._response['rollingTimeseriesDates']))

    @property
    def _rolling_timeseries_observed(self):
        return self._response['rollingTimeseriesObserved']

    @property
    def _rolling_timeseries_regression(self):
        return self._response['rollingTimeseriesReplicated']

    @property
    def _rolling_timeseries_cumulated_difference(self):
        return self._response['rollingTimeseriesCumDiff']

    @property
    def _id(self):
        return (
            self._regression_type
            if self._regression_type == "Portfolio"
            else self._input_dependent_variable
        )

    @property
    def _idx(self):
        return ["Alpha"] + np.array(self._input_factors)[self._active_premia].tolist()
    
    # ---- PUBLIC RESPONSE TRANSFORMER MEMBERS ----

    @property
    def params(self) -> pd.DataFrame:
        """
        Gets basic information of regression analysis. This includes:

        - Start and End dates
        - Regression type
        - Number of observations
        - The regressors
        - Moving window
        - Model interval

        :rtype: Union[pd.DataFrame, Dict[str, float]]

        """

        if bool(self._lasso):
            rtype = f"{self._regression_type} - LASSO({self._lasso})"
        elif bool(self._sign_select):
            rtype = f"{self._regression_type} - Constrained"
        else:
            rtype = f"{self._regression_type} - OLS"

        parameters = {
            "Start": self._start,
            "End": self._end,
            "Regression Type": rtype,
            "Observations": self._observations,
            "Return Interval": self._return_interval,
            "Exogenous Factors": len(self._input_factors),
            "Moving Window": self._rolling_window,
            "Model Interval": self._rolling_return_interval,
        }

        return pd.DataFrame(parameters, index=[self._id])

    @property
    def metric(self) -> pd.DataFrame:
        """
        Gets the static metrics of regression:

        - R2
        - Adjusted R2
        - F-Stat
        - Prob(F-stat)

        :rtype: pd.DataFrame

        """
        metrics = {
            "R-Squared": self._r2,
            "Adjusted R-Squared": self._r2_adjusted,
            "F-Stat": self._f_stat,
            "Prob(F-stat)": self._f_prob,
        }

        return pd.DataFrame(metrics, index=[self._id])
    
    @property
    def coefficients_2d(self) -> pd.DataFrame:
        """
        2D (Quadratic) coefficients of Regression
        :rtype: pd.DataFrame
        """
        coeff = {
            "x0" : self._poly_2df[0],
            "x1" : self._poly_2df[1],
            "x2" : self._poly_2df[2],
        }

        return pd.DataFrame(coeff, index=['2D Coefficient']).T

    @property
    def coefficients_3d(self) -> pd.DataFrame:
        """
        3D (Polynomial) coefficients of Regression
        :rtype: pd.DataFrame
        """
        coeff = {
            "x0" : self._poly_3df[0],
            "x1" : self._poly_3df[1],
            "x2" : self._poly_3df[2],
            "x3" : self._poly_3df[3]
        }

        return pd.DataFrame(coeff, index=['3D Coefficient']).T
    
    @property
    def polynomial_r_squared(self) -> pd.DataFrame:
        """
        Get the 2D and 3D R-Squared Values for the Residual and Portfolio Returns
        :rtype: pd.DataFrame
        """
        rSquared = {
            "Residuals": {
                "2D" : self._polynomial_r_squared_residuals[0] * 100,
                "3D" : self._polynomial_r_squared_residuals[1] * 100
            },
            "Portfolio Returns": {
                "2D" : self._polynomial_r_squared_portfolio[0] * 100,
                "3D" : self._polynomial_r_squared_portfolio[1] * 100
            }
        }
        return pd.DataFrame(rSquared)

    @property
    def model_summary(self) -> pd.DataFrame:
        """
        Gets regression model's betas, errors, pvalues, attribution and proportions for each regressor asset.

        :rtype:
        """
        out = {
            "Beta": self._betas if bool(self._betas) else None,
            "Error": self._betas_error if bool(self._betas_error) else None,
            "t-stat": self._t_stat if bool(self._t_stat) else None,
            "p > |t-stat|": self._p_values if bool(self._p_values) else None,
            "[0.05": self._betas_lower_bound if bool(self._betas_lower_bound) else None,
            "0.95]": self._betas_upper_bound if bool(self._betas_upper_bound) else None,
            "Ret Attrib": self._return_attribution
            if bool(self._return_attribution)
            else None,
            "Var Attrib": self._variance_attribution
            if bool(self._variance_attribution)
            else None,
            "Ret Prop": self._return_proportion
            if bool(self._return_proportion)
            else None,
            "Var Prop": self._variance_proportion
            if bool(self._variance_proportion)
            else None,
        }

        return pd.DataFrame(out, index=self._idx)

    def observed_track(
        self, kind="dataframe", **mpl_kwargs
    ) -> Union[pd.DataFrame, List[List[Union[date, float]]]]:
        """
        Gets the timeseries of the regressand.

        :raises TrackAccessException: If no Track Access
        :rtype: Union[pd.DataFrame, List[List[Union[date,float]]]]

        .. note:: The API account must have access to tracks. Contact `PremiaLab <https://premialab.com>`_ for more details.
        """
        # Dont parse track if session.track_access is False and len(tickers) == 1
        track = list(zip(self._dates, self._track_observed))

        if kind == "dataframe":
            return pd.DataFrame(track, columns=["Date", self._id]).set_index("Date")
        elif kind == "graph":
            d = pd.DataFrame(track, columns=["Date", self._id]).set_index("Date")
            from plbpy.visualizer.RegressionVisualiser import RegressionVisualiser

            viz = RegressionVisualiser(parsed_response=self)
            ax = viz.plot_track(values=d, **mpl_kwargs)
            return ax

        return track

    def regression_track(
        self, kind="dataframe", **mpl_kwargs
    ) -> Union[pd.DataFrame, List[List[Union[date, float]]]]:
        """
        Gets the timeseries of the regressors.

        :raises TrackAccessException: If no Track Access
        :rtype: Union[pd.DataFrame, List[List[Union[date,float]]]]

        .. note:: The API account must have acces to tracks. Contact `PremiaLab <https://premialab.com>`_ for more details.
        """
        track = list(zip(self._dates, self._track_regression))

        if kind == "dataframe":
            return pd.DataFrame(track, columns=["Date", self._id]).set_index("Date")
        elif kind == "graph":
            d = pd.DataFrame(track, columns=["Date", self._id]).set_index("Date")
            from plbpy.visualizer.RegressionVisualiser import RegressionVisualiser

            viz = RegressionVisualiser(parsed_response=self)
            fig, ax = viz.plot_track(values=d, **mpl_kwargs)
            return fig, ax
        return track

    def cumulated_alpha_track(
        self, kind="dataframe", **mpl_kwargs
    ) -> Union[pd.DataFrame, List[List[Union[date, float]]]]:
        """
        Gets cumulated alpha track from response

        :rtype: Union[pd.DataFrame, List[List[Union[date,float]]]]
        """
        track = list(zip(self._dates, self._track_cumulated_difference))

        if kind == "dataframe":
            return pd.DataFrame(track, columns=["Date", "Cumulated Alpha"]).set_index(
                "Date"
            )
        elif kind == "graph":
            from plbpy.visualizer.RegressionVisualiser import RegressionVisualiser

            viz = RegressionVisualiser(parsed_response=self)
            return viz.cum_track(rolling=False, **mpl_kwargs)
        return track

    @property
    def rolling_metric(self) -> pd.DataFrame:
        """
        Gets a timeseries entaining the rolling metrics of the model. These include:

        - Date: datetime of each observation (index)
        - R-Squared
        - Adjusted R-Squared
        - F-stat
        - Prop F-Stat

        :rtype: Union[pd.DataFrame, List[List[Union[date, float]]]]

        .. note::
            The result wil be empty if the user does not specify a model interval or rolling window using :py:meth:`set_model_interval()` and :py:meth:`set_rolling_window()` methods of the :func:`Regression <plbpy.interface.Regression>` class.
        """
        # if self._rolling_return_interval is None or self._rolling_window is None:
        #     pd.DataFrame(columns=["Date", "R-Squared", "Adjusted R-Squared", "F-Stat", "Prob(F-stat)"]).set_index("Date")

        out = {
            "Date": self._rolling_dates,
            "R-Squared": self._rolling_r2,
            "Adjusted R-Squared": self._rolling_r2_adjusted,
            "F-Stat": self._rolling_f_stat if bool(self._rolling_f_stat) else None,
            "Prob(F-stat)": self._rolling_f_prob
            if bool(self._rolling_f_prob)
            else None,
        }

        return pd.DataFrame(out).set_index("Date")

    @property
    def rolling_model_summary(
        self,
    ) -> pd.DataFrame:
        """
        Gets a timeseries of model's betas, errors, bounds, proportions and attributions

        :rtype: Union[pd.DataFrame, List[List[Union[date, float]]]]

        .. note::
            The result wil be empty if the user does not specify a model interval or rolling window using :py:meth:`set_model_interval()` and :py:meth:`set_rolling_window()` methods of the :func:`Regression <plbpy.interface.Regression>` class.
        """
        if self._rolling_return_interval is None or self._rolling_window is None:
            return pd.DataFrame(columns= self.model_summary.columns)
       
        arrays = [
            np.array(self._rolling_betas),
            np.array(self._rolling_betas_error),
            np.array(self._rolling_t_stat),
            np.array(self._rolling_p_values),
            np.array(self._rolling_betas_lower_bound),
            np.array(self._rolling_betas_upper_bound),
            np.array(self._rolling_return_attribution),
            np.array(self._rolling_variance_attribution),
            np.array(self._rolling_return_proportion),
            np.array(self._rolling_variance_proportion),
        ]
        out = np.concatenate(arrays, axis=1).reshape(-1, len(arrays), len(self._idx))

        columns = self._idx
        index = self.model_summary.columns
        df = pd.concat(
            [
                pd.DataFrame(
                    data.T,
                    columns=index,
                    index=pd.MultiIndex.from_product([[i], columns]),
                )
                for i, data in zip(self._rolling_dates, out)
            ],
            axis=0,
        )
        df["Ret Prop"] = df["Ret Prop"] * 100
        df["Var Prop"] = df["Var Prop"] * 100
        return df

    def rolling_observed_track(
        self, kind="dataframe", **mpl_kwargs
    ) -> Union[pd.DataFrame, List[List[Union[date, float]]]]:
        """
        Gets the timeseries of the regressand.

        :raises TrackAccessException: If no Track Access
        :rtype: Union[pd.DataFrame, List[List[Union[date,float]]]]

        .. note:: The API account must have acces to tracks. Contact `PremiaLab <https://premialab.com>`_ for more details.
        """
        # Dont parse track if session.track_access is False and len(tickers) == 1
        if ~self._session.kwargs.get("track_access", True) and (
            self._id == "Portfolio" and len(self._request['portfolio']['listCodes']) == 1
        ):
            from plbpy.exceptions.class_exceptions import TrackAccessException

            raise TrackAccessException("Access to Strategy Track restricted")

        track = list(
            zip(self._rolling_timeseries_dates, self._rolling_timeseries_observed)
        )

        if kind == "dataframe":
            return pd.DataFrame(track, columns=["Date", self._id]).set_index("Date")
        elif kind == "graph":
            values = pd.DataFrame(track, columns=["Date", self._id]).set_index("Date")
            from plbpy.visualizer.RegressionVisualiser import RegressionVisualiser

            viz = RegressionVisualiser(parsed_response=self)
            return viz.plot_track(values, **mpl_kwargs)
        else:
            return track

    def rolling_regression_track(
        self, kind="dataframe", **mpl_kwargs
    ) -> Union[pd.DataFrame, List[List[Union[date, float]]]]:
        """
        Gets the timeseries of the regressors.

        :raises TrackAccessException: If no Track Access
        :rtype: Union[pd.DataFrame, List[List[Union[date,float]]]]

        .. note:: The API account must have acces to tracks. Contact `PremiaLab <https://premialab.com>`_ for more details.
        """
        track = list(
            zip(self._rolling_timeseries_dates, self._rolling_timeseries_regression)
        )

        if kind == "dataframe":
            return pd.DataFrame(track, columns=["Date", self._id]).set_index("Date")
        elif kind == "graph":
            values = pd.DataFrame(track, columns=["Date", self._id]).set_index("Date")
            from plbpy.visualizer.RegressionVisualiser import RegressionVisualiser

            viz = RegressionVisualiser(parsed_response=self)
            return viz.plot_track(values, **mpl_kwargs)
        else:
            return track

    def rolling_cumulated_alpha_track(
        self, kind="dataframe", **mpl_kwargs
    ) -> Union[pd.DataFrame, List[List[Union[date, float]]]]:
        """
        Gets cumulated alpha track from response

        :rtype: Union[pd.DataFrame, List[List[Union[date,float]]]]
        """
        track = list(zip(self._dates, self._rolling_timeseries_cumulated_difference))

        if kind == "dataframe":
            return pd.DataFrame(track, columns=["Date", "Cumulated Alpha"]).set_index(
                "Date"
            )
        elif kind == "graph":
            from plbpy.visualizer.RegressionVisualiser import RegressionVisualiser

            viz = RegressionVisualiser(parsed_response=self)
            return viz.cum_track(rolling=True, **mpl_kwargs)
        else:
            return track

    def tearsheet(self, **mpl_kwargs):
        from plbpy.visualizer.RegressionVisualiser import RegressionVisualiser

        viz = RegressionVisualiser(parsed_response=self)
        return viz.create_tearsheet(**mpl_kwargs)
