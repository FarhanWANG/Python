from __future__ import annotations
__all__ = ["PCATransformer"]

from plbpy.utility.date_utils import to_date, date
import numpy as np
import pandas as pd
import json

class PCATransformer:

    def __init__(self, pca_input, pca_response):

        self._request = pca_input
        self._response = pca_response

 # --- Private PCAParser members ---
    @property
    def _response(self):
        return self._api_response

    @_response.setter
    def _response(self, value):
        self._api_response = value

    @property
    def _request(self):
        return self._api_input

    @_request.setter
    def _request(self, value):
        self._api_input = value

    # --- Private Request Parser members ---
    @property
    def _assets(self):
        return self._request['pca']['listCodes']

    @property
    def _pca_type(self):
        return self._request['pca']['covType']

    # --- Private Response Parser members ---
    @property
    def _start(self):
        return to_date(self._response['startDate'])

    @property
    def _end(self):
        return to_date(self._response['endDate'])

    @property
    def _annualized_return(self):
        return np.round(list(map(lambda x: x * 100, self._response['return'])), 2)

    @property
    def _cumulated_return(self):
        return np.round(list(map(lambda x: x * 100, self._response['returnCum'])), 2)

    @property
    def _annualized_volatility(self):
        return np.round(list(map(lambda x: x * 100, self._response['volatility'])), 2)

    @property
    def _skewness(self):
        return self._response['skew']

    @property
    def _kurtosis(self):
        return self._response['kurtosis']

    @property
    def _max_drawdown(self):
        return self._response['maxDD']

    @property
    def _avg_drawdown(self):
        return self._response['avgDD']

    @property
    def _sharpe_ratio(self):
        return self._response['sharpe']

    @property
    def _information_ratio(self):
        return self._response['infoRatio']

    @property
    def _calmar_ratio(self):
        return self._response['calmar']

    @property
    def _omega_ratio(self):
        return self._response['omega']

    @property
    def _sortino_ratio(self):
        return self._response['sortino']

    @property
    def _value_at_risk(self):
        return np.round(list(map(lambda x: x * 100, self._response['var'])), 2)

    @property
    def _conditional_value_at_risk(self):
        return np.round(list(map(lambda x: x * 100, self._response['cvar'])), 2)

    @property
    def _modified_value_at_risk(self):
        return np.round(list(map(lambda x: x * 100, self._response['mvar'])), 2)

    @property
    def _variance_proportion(self):
        return self._response['varPropAfterEx']

    @property
    def _variance_decomposition(self):
        return self._response['varDecomposeAfterEx']

    # @property
    # def _correlation(self):
    #     """parses correlation"""
    #     return self._response['covar']

    @property
    def _covariance(self):
        """parses covariance"""
        return self._response['covar']

    @property
    def _strategy_allocation(self):
        """parses coeff_adjusted_after_ex as weight of strategy towards a PC"""
        return self._response['coeffAdjustedAfterEx']

    @property
    def _strategy_included(self):
        """parses boolean list representing whether a strategy was included in analysis"""
        return self._response['includedTimeseriesPCA']

    @property
    def _valid_pca_tracks(self):
        """parses boolean list representing whether a PC track in included in output"""
        return [True] * len(self._response['timeseriesPCAValid'])

    @property
    def _pca_index(self):
        return [f"PC{i}" for i, cond in enumerate(self._valid_pca_tracks, 1) if cond]

    @property
    def _invalid_pca_index(self):
        return [
            f"PC{i}"
            for i, cond in enumerate(self._response['timeseriesPCAValid'], 1)
            if not cond
        ]

    @property
    def _dates(self):
        """parses timeseries dates"""
        return list(map(to_date, self._response['timeseriesDates']))

    @property
    def _track_value(self):
        """parses all Prinn"""
        return self._response['timeseriesPCA']

    # ------ Public Response Parser members ------

    @property
    def params(self):
        """
        Gets basic PCA information

        :rtype: Union[pd.DataFrame, Dict[str, Union[str, float]]]
        """

        parameters = {
            "Start": self._start,
            "End": self._end,
            "Assets": len(self._assets),
            "PCA Type": self._pca_type,
        }

        return pd.DataFrame(parameters, index=["PCA"])

    @property
    def static_metric(self):
        """Gets metrics of the PCA. The metrics include performance values, statistical values and ratios:

        * Return per anum
        * Cumulated Return
        * Volatility per anum
        * Skew
        * Kurtosis
        * Max Drawdown
        * Average Drawdown
        * Sharpe Ratio
        * Information Ratio
        * Calmar Ratio
        * Omega Ratio
        * Sortino Ratio
        * Value at Risk
        * Condtitional Value at Risk
        * Modified Value at Risk

        :rtype: Union[pd.DataFrame, Dict[str, List[float]]]
        """
        metrics = {
            "Return": self._annualized_return,
            "Return Cumulated": self._cumulated_return,
            "Volatility": self._annualized_volatility,
            "Skew": self._skewness,
            "Kurtosis": self._kurtosis,
            "Max Drawdown": self._max_drawdown,
            "Avg Drawdown": self._avg_drawdown,
            "Sharpe Ratio": self._sharpe_ratio,
            "Information Ratio": self._information_ratio,
            "Calmar Ratio": self._calmar_ratio,
            "Omega Ratio": self._omega_ratio,
            "Sortino Ratio": self._sortino_ratio,
            "VaR": self._value_at_risk,
            "CVaR": self._conditional_value_at_risk,
            "MVaR": self._modified_value_at_risk,
        }

        df = (
            pd.DataFrame(metrics)
            .T.iloc[:, self._valid_pca_tracks]
            .replace(0.0, np.nan)
        )
        df.columns = self._pca_index
        return df.T

    @property
    def track(self):
        """
        Gets timeseries of PCs

        :rtype: Union[pd.DataFrame, List[List[Union[date, List[float]]]]]
        """
        track = list(
            map(
                lambda x: [x[0]] + x[1],
                zip(
                    self._dates,
                    np.array(self._track_value)[:, self._valid_pca_tracks].tolist(),
                ),
            )
        )

        return (
            pd.DataFrame(track, columns=["Date"] + self._pca_index)
            .set_index("Date")
            .replace(0.0, np.nan)
        )

    @property
    def weights(self):
        """
        Gets asset weights given to each PC

        :rtype: Union[pd.DataFrame, List[List[Union[str, float]]]]
        """
        out = self._strategy_allocation

        df = pd.DataFrame(out, columns=self._assets).T.iloc[
            :, self._valid_pca_tracks
        ]
        df.columns = self._pca_index
        df[self._invalid_pca_index] = np.nan
        return df.T

    @property
    def variance_proportion(self):
        """
        Gets Variance Explained by the PCs

        :rtype: Union[pd.DataFrame, List[List[Union[str, float]]]]
        """
        out = self._variance_proportion

        df = pd.DataFrame(out, columns=["PCA"]).T.iloc[:, self._valid_pca_tracks]
        df.columns = self._pca_index
        return df

    @property
    def variance_decomposition(self):
        """
        Gets PC decomposition of each asset in PCA

        :rtype: Union[pd.DataFrame, List[List[Union[str, float]]]]
        """
        out = self._variance_decomposition

        df = pd.DataFrame(out, index=self._assets).T.iloc[:, self._valid_pca_tracks]
        df.index = self._pca_index
        return df.T

