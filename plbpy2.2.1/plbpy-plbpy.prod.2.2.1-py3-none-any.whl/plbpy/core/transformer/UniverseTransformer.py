from __future__ import annotations
__all__ = ["UniverseTransformer"]

from plbpy.utility import datetime2str,to_date, date
import numpy as np
import pandas as pd
import json
from plbpy.utility.string_utils import to_snake_case


class UniverseTransformer:
    def __init__(self):
        pass

    @staticmethod
    def _extract_primary_id(x, anchor):
        return x['primary_prospectus_benchmarks'][0][anchor] if isinstance(x, dict) and len(
        x) > 0 and 'primary_prospectus_benchmarks' in list(x.keys()) else ''

    def transform_metadata(self, metadata):
        df = pd.DataFrame(data=metadata).set_index("code")
        benchmark_lst = df['benchmarks'].tolist()
        manager_lst = df['managerNames'].tolist()
        df = df.drop('benchmarks', axis=1)

        df['managerNames'] = [', '.join(i) if isinstance(i, list) else '' for i in manager_lst]
        df['primaryBenchmarkId'] = [self._extract_primary_id(i,'id') for i in benchmark_lst]
        df['primaryBenchmarkName'] = [self._extract_primary_id(i, 'name') for i in benchmark_lst]

        df = df.rename(columns = {'globalCat':'globalCategory'})

        df[['ucits']] = df[['ucits']].replace('-', 'No').replace(1, 'Yes')
        df = df.replace('', np.nan).replace(0,np.nan).dropna(how='all', axis=1).replace(np.nan,'-')
        df.columns = map(to_snake_case,df.columns)
        return df

    def transform_tracks(self, raw_dict):
        dfs = [pd.DataFrame(raw_dict[k]).rename(columns={'price': k}).set_index('date') for k in list(raw_dict.keys())]
        df = pd.concat(dfs, axis=1)
        df.index = pd.to_datetime(df.index)
        return df.sort_index()







