from __future__ import annotations
__all__ = ["MyLabTransformer"]

import plbpy.utility as utils
import numpy as np
import pandas as pd
import json
from plbpy.utility.string_utils import to_snake_case


class MyLabTransformer:
    def __init__(self):
        pass

    @staticmethod
    def _date_change(d):
        try:
            return utils.datetime2str(pd.to_datetime(d).date())
        except Exception:
            return d

    def transform_uploaded_tracks(self, obj):
        if len(obj) == 0:
            return pd.DataFrame()
        column_mapping = {
            'referenceType': 'Reference Type',
            'name': 'Track Name',
            'createdAt': 'Uploaded At',
            'updatedAt': 'Last Updated',
            'liveDate': 'Live Date',
            'internalReference':'Internal Reference',
            'ticker':'Ticker',
            'ric':'RIC',
            'moningStarId':'MStarID',
            'isin':'ISIN',
            'assetClass':'Asset Class',
            'factor':'Factor',
            'region':'Region',
            'currency':'Currency',
            'style':'Style',
            'returnType':'Return Type',
            'managementFee':'Management Fee'
        }
        try:
            df = pd.DataFrame(obj)
            df = df.drop('instrument', axis=1).join(pd.json_normalize(df['instrument'])).set_index('reference')
            cols = list(column_mapping.keys())

            df = df[[i for i in cols if i in df.columns.tolist()]]
            df['createdAt'] = list(map(self._date_change, df['createdAt'].tolist()))
            df['updatedAt'] = list(map(self._date_change, df['updatedAt'].tolist()))
            df.columns = map(lambda x: column_mapping[x], df.columns)

            return df
        except Exception as e:
            raise e


