"""
Module to access portfolio backtest results. Properties of this module can be accessed via the result property of Portfolio construction module
"""


from __future__ import annotations
__all__ = ["PortfolioTransformer"]

from plbpy.utility.date_utils import to_date, date
import numpy as np
import pandas as pd
import json


class PortfolioTransformer:

    def __init__(self,
                 session,
                 portfolio_input,
                 portfolio_response):
        self._session = session
        self._request = portfolio_input
        self._response = portfolio_response

    # --- Private PortfolioParser members ---

    @property
    def _response(self):
        return self._api_response

    @_response.setter
    def _response(self, value):
        self._api_response = value

    @property
    def _request(self):
        return self._api_input

    @_request.setter
    def _request(self, value):
        self._api_input = value

    @property
    def _session(self):
        return self.__session

    @_session.setter
    def _session(self, value):
        self.__session = value

    # --- Private Request Parser members ---
    @property
    def _assets(self):
        return self._request['listCodes']

    @property
    def _start(self):
        return self._request['listStartDates'][0]

    @property
    def _end(self):
        return self._request['endDate']

    @property
    def _return_interval(self):
        return self._request['returnInterval']

    # --- Private Response Parser members ---
    @property
    def _observations(self):
        return int(self._response['noElements'])

    @property
    def _start(self):
        return to_date(self._response['startDate'])

    @property
    def _end(self):
        return to_date(self._response['endDate'])

    @property
    def _annualized_return(self):
        return np.round(self._response['return'] * 100, 2)

    @property
    def _cumulated_return(self):
        return np.round(self._response['returnCum'] * 100, 2)

    @property
    def _annualized_volatility(self):
        return np.round(self._response['volatility'] * 100, 2)

    @property
    def _skewness(self):
        return self._response['skew']

    @property
    def _kurtosis(self):
        return self._response['kurtosis']

    @property
    def _max_drawdown(self):
        return np.round(self._response['maxDD'] * 100 , 2)

    @property
    def _avg_drawdown(self):
        return np.round(self._response['avgDD'] * 100, 2)

    @property
    def _sharpe_ratio(self):
        return self._response['sharpe']

    @property
    def _autocor(self):
        return self._response['autocor']

    @property
    def _information_ratio(self):
        return self._response['infoRatio']

    @property
    def _calmar_ratio(self):
        return self._response['calmar']

    @property
    def _omega_ratio(self):
        return self._response['omega']

    @property
    def _sortino_ratio(self):
        return self._response['sortino']

    @property
    def _value_at_risk(self):
        return np.round(self._response['var'] * 100, 2)

    @property
    def _conditional_value_at_risk(self):
        return np.round(self._response['cvar'] * 100, 2)

    @property
    def _modified_value_at_risk(self):
        return np.round(self._response['mvar'] * 100, 2)

    @property
    def _percentage_of_positive_week(self):
        return np.round(self._response['percentPosWeeks'] * 100, 2)

    @property
    def _percentage_of_positive_month(self):
        return np.round(self._response['percentPosMonths'] * 100, 2)

    @property
    def _dates(self):
        return list(map(to_date, self._response['timeseriesDates']))

    @property
    def _track_value(self):
        return self._response['timeseriesEquity']

    @property
    def _track_rolling_drawdown(self):
        return self._response['timeseriesRollingDrawDowns']

    @property
    def _track_rolling_volatility(self):
        return self._response['timeseriesRollingVolatility']

    @property
    def _track_rolling_correlation(self):
        return self._response['timeseriesRollingCorrel']

    @property
    def _track_rolling_sharpe(self):
        return self._response['timeseriesRollingSharpe']

    @property
    def _strategy_allocation(self):
        """parses weights"""
        return self._response['weights']

    @property
    def _asset_class_allocation(self):
        """parses weights_asset_classes_average"""
        return self._response['weightsAssetClassesAverage']

    @property
    def _factor_allocation(self):
        """parses weights_factors_average"""
        return self._response['weightsFactorsAverage']

    @property
    def _correlation(self):
        """parses correlation"""
        return self._response['correlation']

    @property
    def _incremental_return(self):
        """parses incremental return"""
        return [round(i*100, 2) for i in self._response['incrementalReturn']]

    @property
    def _incremental_volatility(self):
        """parses incremental volatility"""
        return [round(i * 100, 2) for i in self._response['incrementalVolatility']]

    @property
    def _incremental_var(self):
        """parses incremental VaR"""
        return [round(i * 100, 2) for i in self._response['incrementalVar']]

    @property
    def _incremental_cvar(self):
        """parses incremental CVaR"""
        return [round(i * 100, 2) for i in self._response['incrementalCvar']]

    @property
    def params(self) -> pd.DataFrame:
        """
        Gets the basic backtesting information: start, end, number of assets and return interval.

        :rtype: Union[pd.DataFrame, Dict[str, Union[str, float]]]
        """

        parameters = {
            "Start": self._start,
            "End": self._end,
            "Assets": len(self._assets),
            "Return Interval": self._return_interval,
        }
        return pd.DataFrame(parameters, index=["Portfolio"])

    @property
    def asset_class_allocation(self) -> pd.DataFrame:
        """
        Get the average exposure to various asset classes over the backtest period

        :rtype: Union[pd.DataFrame, Dict[str, Union[str, float]]]

        """

        out = self._asset_class_allocation

        return pd.DataFrame(index=list(out.keys()), data=list(out.values()), columns=['Average Weight'])

    @property
    def factor_allocation(self) -> pd.DataFrame:
        """
        Get the average exposure to various factors over the backtest period

        :rtype: Union[pd.DataFrame, Dict[str, Union[str, float]]]

        """

        out = self._factor_allocation

        return pd.DataFrame(index=list(out.keys()), data=list(out.values()), columns=['Average Weight'])


    @property
    def static_metric(self)-> pd.DataFrame:
        """Gets the metrics of the backtest. The metrics include performance values, statistical values and ratios:

        * Number of observations
        * Return per anum
        * Cumulated Return
        * Volatility per anum
        * Skew
        * Kurtosis
        * Max Drawdown
        * Average Drawdown
        * Sharpe Ratio
        * Information Ratio
        * Calmar Ratio
        * Omega Ratio
        * Sortino Ratio
        * Value at Risk
        * Condtitional Value at Risk
        * Modified Value at Risk
        * Number of weeks with positive return
        * Number of months with positive return

        :rtype: Union[pd.DataFrame, Dict[str,float]]
        """

        metrics = {
            "Observations": self._observations,
            "Return": self._annualized_return,
            "Return Cumulated": self._cumulated_return,
            "Volatility": self._annualized_volatility,
            "Skew": self._skewness,
            "Kurtosis": self._kurtosis,
            "Autocorrelation": self._autocor,
            "Max Drawdown": self._max_drawdown,
            "Avg Drawdown": self._avg_drawdown,
            "Sharpe Ratio": self._sharpe_ratio,
            "Information Ratio": self._information_ratio,
            "Calmar Ratio": self._calmar_ratio,
            "Omega Ratio": self._omega_ratio,
            "Sortino Ratio": self._sortino_ratio,
            "VaR": self._value_at_risk,
            "CVaR": self._conditional_value_at_risk,
            "MVaR": self._modified_value_at_risk,
            "Positive Weeks (%)": self._percentage_of_positive_week,
            "Positive Months (%)": self._percentage_of_positive_month,
        }

        return pd.DataFrame(metrics, index=["Portfolio"])

    @property
    def rolling_metric(self) -> pd.DataFrame:
        """Gets Drawdown, Rolling Correlation with benchmark (if requested in input), Rolling Sharpe Ratio and Rolling Volatility.

        The interval of the timeseries is set using :meth:`set_return_interval() <Portfolio.set_return_interval>` method.

        :rtype: Union[pd.DataFrame, List[List[Union[date,float]]]]
        """
        from itertools import zip_longest

        out = list(
            zip_longest(
                self._dates[::-1],
                self._track_rolling_drawdown[::-1],
                np.array(self._track_rolling_correlation).flatten().tolist()[::-1],
                self._track_rolling_sharpe[::-1],
                self._track_rolling_volatility[::-1],
                fillvalue=np.nan,
            )
        )

        try:
            corr_interval = self._request['correlInterval']
        except KeyError:
            corr_interval = '-'

        try:
            sharpe_interval = self._request['sharpeInterval']
        except KeyError:
            sharpe_interval = '-'

        try:
            volatility_interval = self._request['volatilityInterval']
        except KeyError:
            volatility_interval = '-'

        try:
            corr_benchmark = self._request['correlBenchmark']
        except KeyError:
            corr_benchmark = '-'

        return (
            pd.DataFrame(
                out,
                columns=[
                    "Date",
                    "Drawdown",
                    f"Correlation [{corr_interval}] - {corr_benchmark}",
                    f"Sharpe [{sharpe_interval}]",
                    f"Volatility [{volatility_interval}]",
                ],
            )
                .set_index("Date")
                .sort_index(ascending=True)
        )

    @property
    def track(self) -> pd.DataFrame:
        """Gets the timeseries of the portfolio from the backtest.

        :raises TrackAccessException: If no Track Access
        :rtype: Union[pd.DataFrame, List[List[Union[date,float]]]]

        .. note:: The API account must have acces to tracks. Contact `PremiaLab <https://premialab.com>`_ for more details.
        """
        # Dont parse track if session.track_access is False and len(tickers) == 1
        track = list(zip(self._dates, self._track_value))

        df = pd.DataFrame(track, columns=["Date", "Portfolio"]).set_index("Date")
        df.index = pd.to_datetime(df.index)
        return df

    def monthly_return(self, style=False) -> pd.DataFrame:
        """Gets a timeseries of monthly returns.

        :rtype: Union[pd.DataFrame, List[List[Union[date,float]]]]
        """
        out = list(
            zip(
                list(map(to_date, self._response['monthlyRtnDates'][-len(self._response['monthlyRtn']):])),
                list(map(lambda x: x * 100, self._response['monthlyRtn'])),
            )
        )
        df = pd.DataFrame(data=out, columns=["Date", "Monthly Return"]).set_index("Date")
        df.index = pd.to_datetime(df.index)

        if style:
            from plbpy.utility.func_utils import style_df
            mr = df.copy()
            mr['Month'] = [i.strftime("%B") for i in mr.index]
            mr['Year'] = [i.strftime("%Y") for i in mr.index]

            mr = mr.reset_index(drop=True)
            months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October',
                      'November', 'December']
            mr = mr.pivot_table(index='Year', columns='Month').T.groupby(level=[1]).sum().T
            mr = mr[[i for i in months if i in mr.columns.tolist()]]
            mr['Aggregate'] = mr.sum(axis=1)
            mr = mr.replace(0.0, '-')
            return style_df(mr, aggregate=True)
        else:
            return df

    @property
    def yearly_return(self) -> pd.DataFrame:
        """Gets a timeseries of yearly returns.

        :rtype: Union[pd.DataFrame, List[List[Union[date,float]]]]
        """
        out = list(
            zip(
                list(map(to_date, self._response['yearlyRtnDates'][-len(self._response['yearlyRtn']):])),
                list(map(lambda x: x * 100, self._response['yearlyRtn'])),
            )
        )

        df = pd.DataFrame(data=out, columns=["Date", "Yearly Return"]).set_index(
            "Date"
        )
        df.index = pd.to_datetime(df.index)
        return df

    @property
    def weights(self) -> pd.DataFrame:
        """Gets a timeseries of the weights given to each asset, according to the input allocation model,
        amount borrowed and amount lent (if leverage parameters applied).

        The weights are adjusted for drift.

        :rtype: Union[pd.DataFrame, List[List[Union[date,float]]]]
        """
        out = list(
            map(lambda x: [x[0]] + x[1], zip(self._dates, self._strategy_allocation))
        )
        df = pd.DataFrame(
            out, columns=["Date"] + self._assets + ["borrowing", "lending"]
        ).set_index("Date")
        df.index = pd.to_datetime(df.index)
        return df


    @property
    def correlation_matrix(self) -> pd.DataFrame:
        """Gets the :math:`(N+1 \\times{N+1})` correlation matrix of :math:`N` assets in the Portfolio and the Portfolio itself.

        :rtype: Union[pd.DataFrame, List[List[float]]]
        """
        out = self._correlation
        idx = self._assets + ["Portfolio"]

        return pd.DataFrame(out, columns=idx, index=idx)


    @property
    def cash_replacement_metrics(self) -> pd.DataFrame:
        """
        Get the metrics of the portfolio if each asset was replaced with cash

        :rtype: pd.DataFrame

        """
        replacement_return = np.array(self._annualized_return) - np.array(self._incremental_return)
        replacement_vol = np.array(self._annualized_volatility) - np.array(self._incremental_volatility)
        replacement_var = np.array(self._value_at_risk) - np.array(self._incremental_var)
        replacement_cvar = np.array(self._conditional_value_at_risk) - np.array(self._incremental_cvar)

        data = {
            'Return p.a.':replacement_return.tolist(),
            'Volatility':replacement_vol.tolist(),
            'VaR': replacement_var.tolist(),
            'CVaR': replacement_cvar.tolist()
        }

        df = pd.DataFrame(data, index=self._assets)

        # add portfolio metrics
        df.loc['None', 'Return p.a.'] = self._annualized_return
        df.loc['None', 'Volatility'] = self._annualized_volatility
        df.loc['None', 'VaR'] = self._value_at_risk
        df.loc['None', 'CVaR'] = self._conditional_value_at_risk

        df.index.name = 'Asset Replaced'
        df.columns.name = 'Portfolio Metric'
        return df




    @property
    def frontier_line(self) -> pd.DataFrame:
        """
        Gets the portfolio's efficient frontier line cooridnates

        :rtype: Pd.DataFrame
        """
        res = self._response.json()
        res = res['frontier']
        data = pd.DataFrame(data = res)
        cols = data.columns
        data = data[[cols[1], cols[0]]]
        data.columns = ['Return', 'Volatility']
        data = data * 100
        return data

    @property
    def frontier_weights(self):
        """
        Gets the portfolio's constituents weights on the efficeint frontier

        :rtype: Pd.DataFrame
        """
        res = self._response.json()
        res = res['frontier']
        raw_data = pd.DataFrame(data=res)
        weights = raw_data[['weights']]
        input_dict = json.loads(self._request)
        keys = input_dict['listCodes']
        values = [[x for x in weights.iloc[i, 0].values()] for i in range(len(weights))]
        data = pd.DataFrame(data=values, columns=keys)
        data = data * 100
        return data

    @property
    def frontier_max_sharpe(self):
        """
        Gets the portfolio's Maximum Sharpe point on the efficeint frontier

        :rtype: Pd.DataFrame
        """
        raw = self._response.json()
        raw = raw['maxSharpeValues']
        data = pd.DataFrame()
        data['Return'] = [raw['y']]
        data['Volatility'] = [raw['x']]
        for x in raw['weights'].keys():
            data[x] = [raw['weights'][x]]
        data['SharpeRatio'] = [raw['sharpeRatio']]
        data = data*100
        return data
        

