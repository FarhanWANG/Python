from __future__ import annotations
__all__ = ["HClusterTransformer"]

from plbpy.utility.date_utils import to_date, date
import numpy as np
import pandas as pd
import json

class HClusterTransformer:

    def __init__(self, hcluster_input, hcluster_response, universe):
        self._request = hcluster_input
        self._response = hcluster_response
        self.universe = universe

    # ----------- MSTParser members ------------------
    @property
    def universe(self):
        return self._universe

    @universe.setter
    def universe(self, value):
        self._universe = value

    @property
    def _response(self):
        return self._api_response

    @_response.setter
    def _response(self, value):
        self._api_response = value

    @property
    def _request(self):
        return self._api_input

    @_request.setter
    def _request(self, value):
        self._api_input = value

    # -----------Private Request Parser Members ------------------
    @property
    def _correlation_type(self):
        return self._request['correlationType']

    @property
    def _correlation_interval(self):
        return self._request['returnInterval']

    # ----------- Private Response Members ------------------
    @property
    def _start(self):
        return self._response['startDate']

    @property
    def _end(self):
        return self._response['endDate']

    @property
    def _correlation_values(self):
        return self._response['correlation']

    @property
    def _correlation_assets(self):
        return self._response['sortedIndex']

    @property
    def params(self):
        """
        Gets basic information about the computation. These include:
        - Start and End dates
        - Number of input assets
        - Correlation Type
        - Return Interval

        :rtype: Union[pd.DataFrame, Dict[str, float]]

        """
        p = {
            "Start": self._start,
            "End": self._end,
            "Assets": len(self._correlation_assets),
            "Correlation Type": self._correlation_type,
            "Return Interval": self._correlation_interval,
        }
        return pd.DataFrame(p, index=["Correlation Matrix"])

    @property
    def sorted_index(self):
        """
        Get the order list of assets

        """
        return self._correlation_assets

    def correlation_matrix(
        self, kind="graph", show_all_labels=False, **mpl_kwargs
    ):
        """
        Get the correlation matrix of hierarchically sorted input assets

        :rtype: Union[pd.DataFrame, Dict[float]]
        """

        assert kind in [
            "dataframe",
            "graph",
        ], f"Invalid argument {kind} Must be either dataframe, graph"

        df = pd.DataFrame(
            data=np.array(self._correlation_values),
            index=self._correlation_assets,
            columns=self._correlation_assets,
        )
        if kind == "dataframe":
            return df
        else:
            if show_all_labels:
                mpl_kwargs["yticklabels"] = 1
                mpl_kwargs["xticklabels"] = 1

            from plbpy.visualizer.HClusterVisualiser import HClusterVisualiser

            viz = HClusterVisualiser(parsed_response=self)

            fig, ax = viz.draw_matrix(**mpl_kwargs)

            ax.set_title(
                mpl_kwargs.pop(
                    "title",
                    f"{self._start} | {self._end} | {len(self._correlation_assets)} | {self._correlation_type} | {self._correlation_interval}",
                )
            )

            return fig, ax


