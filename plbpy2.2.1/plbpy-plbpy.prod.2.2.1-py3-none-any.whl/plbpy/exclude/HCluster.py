"""
HCluster takes a universe of assets, hierarcically sort them
"""

from __future__ import annotations

__all__ = ["HCluster"]

import copy
from typing import Union, List, Optional, Iterable, Tuple

from plbpy.core.loader.HClusterLoader import HClusterLoader
from plbpy.interface.Session import Session
from plbpy.utility.date_utils import datetime2str, today, to_date, date, datetime
from plbpy import session as _gl_session  # global session for fail case
from plbpy import log_factory, logger, console, DEBUG, INFO  # Log tools



class HCluster:
    @log_factory(logger, DEBUG)
    def __init__(
        self,
        universe=None,
        portfolio=None,
        codes: List[str] = None,
        session=_gl_session,
    ):
        """Constructor

        :param universe: An instance of Universe
        :type universe: Universe, optional

        :param portfolio: An instance of Portfolio
        :type portfolio: Portfolio, optional

        :param session: The current session object provided
        :type session: Session, optional

        :param codes: List of asset tickers
        :type codes: Iterable[str], optional

        .. note::

            The assets can be passed strictly via one of the three methods:

            - A Universe object with the required assets
            - A Portfolio of the required assets
            - A list of required asset codes AND Session object

            Also note that the number of assets passed must not exceed 120 using any method. This will result in an exception while executing :py:meth:`run_hcluster`

            Construction with Universe

            >>> plbpy.HCluster(universe=plbpy.universe.code('SPX','SBWGU'))

            Construction with Porfolio

            >>> plbpy.HCluster(portfolio=plbpy.Portfolio(codes=['SPX','SBWGU']))

            Construction with list of codes

            >>> plbpy.HCluster(codes=['SPX','SBWGU'])

        """
        self.__loader = HClusterLoader(universe=universe,portfolio=portfolio, codes=codes)


    # --- Public HCluster Methods ---

    @log_factory(logger, DEBUG)
    def run_hcluster(self) -> HCluster:
        """
        Computes the Hierarchical Clusters of the universe assets

        :return: Current HCluster object with an updated :py:attr:`result` attribute
        :rtype: HCluster

        Compute cluster:

        >>> plbpy.HCluster(codes=['SPX','SBWGU']).run_hcluster()
        """
        self.__loader.run_hcluster()
        return self

    # --- Private HCluster Methods ---

    @property
    def session(self) -> Session:
        """
        Gets current Session Object

        :rtype: Session

        """
        return self.__loader.session

    @property
    def universe(self):
        """
        Gets the Universe object of current Portfolio.

        :rtype: Universe

        """
        return self.__loader.universe

    @property
    def result(self):
        """
        Access the results of the computation

        :rtype: HClusterParser

        Get results

        >>> plbpy.HCluster(
                universe = universe.code("SPX", "SBWGU")
            ).run_hcluster().result.correlation_matrix()

        .. note:: Accessing this property before running :py:meth:`run_hcluster` will result in an error.

        """
        return self.__loader.result

    @property
    def info(self):
        """
        Gets the raw API input. This property is used to view all the information of the current HCluster object such as time period, return interval, correlation type et cetera.

        .. warning:: User must not change this object explicitly, instead use the HCluster helper functions.

        """
        return self.__loader.info

    # --- HCluster Info Getters ---
    @property
    def _type(self):
        return self.info['correlationType']

    @property
    def _interval(self):
        return self.info['returnInterval']

    @property
    def _start(self) -> date:
        return to_date(self.info['listStartDates'][0])

    @property
    def _end(self) -> date:
        return to_date(self.info['endDate'])

    @property
    def _codes(self) -> List[str]:
        return self.info['listCodes']

    # --- HCluster info Functional Setters ---

    @log_factory(logger, DEBUG)
    def set_start(self, start_date: Union[date, datetime, str]) -> HCluster:
        """
        Sets HCluster start date.

        :param start_date: Date at which computation should begin. If passing str, date should be in YYYY-MM-DD format
        :type start_date: Union[date, datetime, str]

        :return: Current HCluster object with an updated start date
        :rtype: HCluster

        :raise AssertionError: If attempting to set start date after end date

        Start computation from 1st Jan 2015

        >>> plbpy.HCluster(
                universe = universe.code("SPX", "SBWGU")
            ).set_start('2015-01-01')
        """
        self.__loader.set_start(start_date)
        return self

    @log_factory(logger, DEBUG)
    def set_end(self, end_date: Union[date, datetime, str]) -> HCluster:
        """
        Sets HCluster end date.

        :param start_date: Date at which computation should end. If passing str, date should be in YYYY-MM-DD format
        :type start_date: Union[date, datetime, str]

        :return: Current HCluster object with an updated end date
        :rtype: HCluster

        :raise AssertionError: If attempting to set end date after today

        Ending computation on 1st Dec 2010

        >>> plbpy.HCluster(
                universe = universe.code("SPX", "SBWGU")
            ).set_end('2020-12-01')
        """
        self.__loader.set_end(end_date)
        return self

    @log_factory(logger, DEBUG)
    def set_return_interval(self, interval: str) -> HCluster:
        """
        Sets return interval for computation

        :param interval: Return interval
        :type interval: str

        :return: Current HCluster object with an updated return interval
        :rtype: HCluster

        :raise AssertionError: if interval is not in ['Daily', 'Weekly' or 'Monthly'] (case insensitive)

        Set Weekly interval

        >>> plbpy.HCluster(universe = universe.code(['SPX','SBWGU'])).set_return_interval('Weekly)

        """
        self.__loader.set_return_interval(interval)
        return self

    @log_factory(logger, DEBUG)
    def set_type(self, type: str) -> HCluster:
        """
        Sets the correlation calculation method. Allowed values:
        - Pearson
        - Spearman

        :param type: Correlation method
        :type type: str

        :return: Current HCluster object with update correlation type
        :rtype: HCluster

        :raise AssertionError: if type is not in allowed values

        Set Pearson as correlation method:

        >>> plbpy.HCluster(universe = universe.code(['SPX','SBWGU'])).set_type('Pearson')
        """
        self.__loader.set_correlation_type(type)
        return self

    @log_factory(logger, DEBUG)
    def set_correlation_type(self, correl_type: str) -> HCluster:
        """
        Sets the correlation calculation method. Allowed values:
        - Pearson
        - Spearman

        :param correl_type: Correlation method
        :type correl_type: str

        :return: Current HCluster object with update correlation type
        :rtype: HCluster

        :raise AssertionError: if type is not in allowed values

        Set Pearson as correlation method:

        >>> plbpy.HCluster(universe = universe.code(['SPX','SBWGU'])).set_correlation_type('Pearson')
        """
        self.__loader.set_correlation_type(correl_type)
        return self

    @log_factory(logger, DEBUG)
    def copy(self) -> HCluster:
        """
        Makes a copy of the current object

        :return: Copy of the Current HCluster object with updated configuration
        :rtype: HCluster

        .. note::
            User will have to run the analysis again to generate the results

        """
        current_info = self.info
        new_obj = HCluster(universe=self.universe)
        new_obj.__loader.info = current_info

        return new_obj

    @log_factory(logger, DEBUG)
    def reset(self) -> HCluster:
        """
        Resets all configurations of the current hcluster to default values

        :return: Current HCluster object with default configuration
        :rtype: HCluster

        """

        self.__loader.reset()
        return self