"""
Portfolio takes a universe of assets, helps with constructing a backtesting object and provides an interface to access the results of the backtest
"""

from __future__ import annotations
__all__ = ["Portfolio"]

from typing import Union, List, Optional, Iterable
from plbpy.interface.Session import Session
from plbpy.interface.Universe import Universe
from plbpy.utility.date_utils import date, datetime

from plbpy import log_factory, logger, DEBUG  # Log tools
from plbpy import session as _gl_session  # global session for fail case
from plbpy import universe as _gl_universe  # global session for fail case
from plbpy.core.loader.PortfolioLoader import PortfolioLoader


class Portfolio:

    @log_factory(logger, DEBUG)
    def __init__(
        self,
        universe: Union[Universe, Iterable[str]] = None,
        session: Session = _gl_session,
    ):
        """Constructor

        :param universe: An instance of Universe
        :type universe: Universe, optional

            Portfolio construction with universe object

            >>> plbpy.Portfolio(
                    universe = universe.code("SPX", "SBWGU")
                )

            Portfolio construction with list of codes

            >>> plbpy.Portfolio(
                    universe = ["SPX", "SBWGU"]
                )
        """
        self.__loader = PortfolioLoader(universe)
        
        # --- Public Portfolio Properties ---

    @property
    def info(self):
        """
        Gets the raw API input. This property is used to view all the information of the current portfolio object such as allocation model, benchmark, backtest period, input assets, rebalancing dates, leverage, return interval, et cetera.

        .. warning:: User must not change this object explicitly, instead use the :py:obj:`Portfolio` helper functions.
        """
        return self.__loader.info


    @property
    def result(self):
        """
        Access the results of the backtest

        .. tip:: Press <tab> after typing "result." in order to view all results available


        :rtype: PortfolioParser

        Get static metrics

        >>> plbpy.Portfolio(
                universe = universe.code("SPX", "SBWGU")
            ).run_backtest().result.static_metric

        .. note:: Accessing this property before running :py:meth:`run_backtest` will result in an error.

        """
        return self.__loader.result

    @property
    def universe(self):
        """
        Gets the Universe object of current Portfolio.

        :rtype: Universe

        """
        return self.__loader.universe

    @property
    def session(self) -> Session:
        """
        Gets current Session Object

        :rtype: Session

        """
        return self.__loader.session

    @property
    def start(self):
        """
        Gets current start date

        :rtype: Session

        """
        return self.__loader.start

    @property
    def end(self):
        """
        Gets current start date

        :rtype: Session

        """
        return self.__loader.end

    # ---- Methods ----

    @log_factory(logger, DEBUG)
    def set_start(self, start_date: Union[date, datetime, str]) -> Portfolio:
        """
        Sets Portfolio start date.

        :param start_date: Date at which backtesting should begin. If passing str, date should be in YYYY-MM-DD format
        :type start_date: Union[date, datetime, str]

        :return: Current Portfolio object with an updated start date
        :rtype: Portfolio

        :raise AssertionError: If attempting to set start date after end date

        Start backtesting from 1st Jan 2015

        >>> plbpy.Portfolio(
                universe = universe.code("SPX", "SBWGU")
            ).set_start('2015-01-01')
        """
        self.__loader.set_start(start_date)
        return self

    @log_factory(logger, DEBUG)
    def set_end(self, end_date: Union[date, datetime, str]) -> Portfolio:
        """
        Sets Portfolio end date.

        :param end_date: Date at which backtesting should end.  If passing str, date should be in YYYY-MM-DD format
        :type end_date: Union[date, datetime, str]

        :return: Current Portfolio object with an updated end date
        :rtype: Portfolio

        :raise AssertionError: If attempting to set end date after today

        End backtesting at 1st Jan 2020

        >>> plbpy.Portfolio(
                universe = universe.code("SPX", "SBWGU")
            ).set_end('2020-01-01')

        """
        self.__loader.set_end(end_date)
        return self


    @log_factory(logger, DEBUG)
    def set_benchmark(self, benchmark: str, correlation_window: str = "3M") -> Portfolio:
        """
        Sets the Portfolio's benchmark to calculate the correlation of the portfolio against the benchmark.

        :param benchmark: Benchmark ticker
        :type benchmark: str
        :param window: Rolling window
        :type window: str

        :return: Current Portfolio object with updated benchmark and window
        :rtype: Portfolio

        :raise ValueError: If benchmark is not a benchmark ticker or if window is not in ["1M", "3M", "6M", "1Y", "2Y", "3Y", "4Y", "5Y"]

        Setting S&P 500 as the benchmark and calculating 6M rolling correlation

        >>> plbpy.Portfolio(
                universe = universe.code("SPGLOB", "SBWGU")
            ).set_benchmark('SPX', '6M')

        """
        self.__loader.set_benchmark(benchmark,correlation_window)
        return self

    @log_factory(logger, DEBUG)
    def set_return_interval(self, return_interval: str = "Daily") -> Portfolio:
        """
        Sets the Portfolio Return Interval

        :param value: Return interval
        :type value: str

        :return: Current Portfolio object with updated return interval
        :rtype: Portfolio

        :raise ValueError: If input is not 'Weekly', 'Monthly' or 'Daily' (case insensitive)

        Use weekly returns

        >>> plbpy.Portfolio.set_return_interval('Weekly')

        Use monthly returns

        >>> plbpy.Portfolio(
                universe = universe.code("SPX", "SBWGU")
            ).set_return_interval('monthly')

        """
        self.__loader.set_return_interval(return_interval)
        return self

    @log_factory(logger, DEBUG)
    def set_volatility_interval(self, vol_interval: str = "3M") -> Portfolio:
        """
        Sets the Rolling Volatility Interval

        :param vol_interval: Volatility interval
        :type value: str

        :return: Current Portfolio object with updated volatility interval
        :rtype: Portfolio

        :raise ValueError: If volatility interval is not in ["1M", "3M", "6M", "1Y", "2Y", "3Y", "4Y", "5Y"]

        Set 1 Month Volatility Interval

        >>> plbpy.Portfolio(
                universe = universe.code("SPX", "SBWGU")
            ).set_volatility_interval('1M')

        """
        self.__loader.set_volatility_interval(vol_interval)
        return self

    @log_factory(logger, DEBUG)
    def set_sharpe_interval(self, sharpe_interval: str = "3M") -> Portfolio:
        """
        Sets the Rolling Sharpe Ratio Interval. Risk Free rate is US 3M Treasuries

        :param value: Sharpe Ratio interval
        :type value: str

        :return: Current Portfolio object with updated sharpe ratio interval
        :rtype: Portfolio

        :raise ValueError: If sharpe interval is not in ["1M", "3M", "6M", "1Y", "2Y", "3Y", "4Y", "5Y"]

        Use 1M sharpe ratio

        >>> plbpy.Portfolio(
                universe = universe.code("SPX", "SBWGU")
            ).set_set_sharpe_interval('1M')

        Use 1 Year sharpe ratio

        >>> plbpy.Portfolio(
                universe = universe.code("SPX", "SBWGU")
            ).set_sharpe_interval('1Y')

        """
        self.__loader.set_sharpe_interval(sharpe_interval)
        return self

    # def set_rolling_interval(self, interval: str = '3M') -> Portfolio:


    @log_factory(logger, DEBUG)
    def set_rebalance_dates(
        self, rebalance_dates: Optional[Union[List[Union[str, datetime, date]], str]]
    ) -> Portfolio:
        """
        Sets portfolio's allocation models' rebalancing dates.

        :param rebalance_dates: List of dates or frequency interval for rebalancing
        :type rebalance_dates: Optional[Union[List[Union[str, datetime, date]], str]]

        :return: Current Portfolio object with updated rebalancing schedule
        :rtype: Portfolio

        .. tip::

            Accepted inputs for rebalance_dates
                - list[str]: list of 'YYYY-MM-DD'
                - list[date/datetime]: list of DatetimeIndex
                - str: `pandas.date_range.frequency <https://pandas.pydata.org/pandas-docs/stable/user_guide/timeseries.html#timeseries-offset-aliases>`_ keywords

        Quarterly Rebalancing

        >>> plbpy.Portfolio(
                universe = universe.code("SPX", "SBWGU")
            ).set_relabance_dates('Q')

        Rebalancing on specific dates

        >>> plbpy.Portfolio(
                universe = universe.code("SPX", "SBWGU")
            ).set_rebalance_dates(['2020-05-01', '2020-10-01'])

        """
        self.__loader.set_rebalance_dates(rebalance_dates)
        return self

    @log_factory(logger, DEBUG)
    def set_maximum_allocation(self, allocation: List[float]) -> Portfolio:
        """
        Sets maximum weight given to portfolio's constituents

        :param allocation: List of weights threshold for constituents

        :return: Current Portfolio object with maximum weight limit updated
        :rtype: Portfolio

        Set 25% max limit for ALL constituents

        >>> plbpy.Portfolio(universe = universe.code(['SPX','SBWGU','SXXR'])).set_maximum_allocation([0.25])

        Set specific threshold for each asset

        >>> plbpy.Portfolio(universe = universe.code(['SPX','SBWGU','SXXR'])).set_maximum_allocation([0.25, 0.5, 0.3])

        """

        self.__loader.set_maximum_allocation(allocation)
        return self

    @log_factory(logger, DEBUG)
    def set_minimum_allocation(self, allocation: List[float]) -> Portfolio:
        """
        Sets minimum weight given to portfolio's constituents

        :param allocation: List of weights threshold for constituents

        :return: Current Portfolio object with minimum weight limit updated
        :rtype: Portfolio

        Set 5% min limit for ALL constituents

        >>> plbpy.Portfolio(universe = universe.code(['SPX','SBWGU','SXXR'])).set_minimum_allocation([0.05])

        Set specific threshold for each asset

        >>> plbpy.Portfolio(universe = universe.code(['SPX','SBWGU','SXXR'])).set_minimum_allocation([0.05, 0.02, 0.03])

        """
        self.__loader.set_minimum_allocation(allocation)


    @log_factory(logger, DEBUG)
    def set_equal_weight(self, rebalance_dates) -> Portfolio:
        """
        Reconfigures allocation model and assigns equal weight to each strategy. The model will assume daily rebalancing.

        :return: Current portolio object with updated allocation model
        :rtype: Portfolio

        Allocate equal weights (50-50) to each strategy in a 2 asset Portfolio

        >>> plbpy.Portfolio(
                universe = universe.code("SBWGU", "SPX")
            ).set_fixed_weight()

        """
        self.__loader.set_equal_weight(rebalance_dates)

    @log_factory(logger, DEBUG)
    def set_fixed_weight(
        self,
        weights: Union[List[Union[float, int]], dict],
        rebalance_dates: Union[List[Union[str, datetime, date]], str] = None,
        **kwargs,
    ) -> Portfolio:
        """
        Reconfigures allocation model and assigns user defined weights to each asset.
        If rebalancing dates provided, the portfolio rebalances on user defined rebalancing dates
        otherwise it assumes daily rebalancing

        :param weights:
            List of weights for each asset in the portfolio
        :type weights:
            List[Union[float, int]], optional

        :param rebalance_dates:
            List of dates or frequency interval for rebalancing.
            See :py:meth:`set_rebalance_dates` for more details.
        :type rebalance_dates:
            Union[List[Union[str, datetime, date]], str], optional

        :return: Current Portfolio object with updated allocation model
        :rtype: Portfolio

        :raise AssertionError: if dimension of weights specified is not the same as the number of assets in the portfolio

        .. important::
            - Order of the weights must be the same as the order of their corresponding assets in portfolio universe (:py:attr:`universe.codes`).
            - API defaults to equal weights [:py:meth:`set_equal_weight()`] if no weights are specified
            - API defaults to daily rebalancing if no rebalancing dates/intervals are specified

        Make a 60-40 portfolio with quarterly rebalancing for a 2 asset portfolio

        >>> plbpy.Portfolio(
                universe=plbpy.Universe(session).code(["SBWGU","SPX"])
            ).set_fixed_weight(
                weights=[0.6, 0.4],
                rebalance_dates='Q'
            )

        Make a 70-40 portfolio with quarterly rebalancing for a 2 asset portfolio.
        Notice that the first asset is given an additional 10% weightage

        >>> plbpy.Portfolio(
                universe=plbpy.Universe(session).code(["SBWGU","SPX"])
            ).set_fixed_weight(
                weights=[0.7, 0.4],
                rebalance_dates='Q'
            )
        """

        self.__loader.set_fixed_weight(weights, rebalance_dates)
        return self

    @log_factory(logger, DEBUG)
    def set_erc(
        self, erc_interval: str = '1Y', return_interval: str = 'Daily', rebalance_dates: Union[List[Union[str, datetime, date]], str] = 'D'
    ) -> Portfolio:
        """
        Reconfigures allocation model and adjusts weights such that each asset contributes equally to the total risk of the portfolio.
        Rebalances on user defined rebalancing dates.

        :param erc_interval: The look back period at each rebalancing date for volatility calculation
        :type erc_interval: str

        :param return_interval: Return interval used for computing volatility
        :type return_interval: str

        :param rebalance_dates: List of dates or frequency interval for rebalancing. See :py:meth:`set_rebalance_dates` for more details.
        :type rebalance_dates: Union[List[Union[str, datetime, date]], str], optional

        :return: Current Portfolio object with updated allocation model
        :rtype: Portfolio

        .. note::
            API defaults to daily rebalancing if no rebalancing dates/intervals are specified

        Set equal risk contribution portfolio to be rebalanced every 2 months and volatility computed for the past 3 months weekly returns

        >>> plbpy.Portfolio(
                universe=plbpy.Universe(session).code(["SBWGU","SPX"])
            ).set_erc('3M','Weekly','2M')
        """

        self.__loader.set_erc(erc_interval, return_interval, rebalance_dates)
        return self

    @log_factory(logger, DEBUG)
    def set_custom_weight(self, weights: List[List], rebalance_dates: Union = [List[Union[str, datetime, date]], str]) -> Portfolio:
        """
        Reconfigures allocation model to adjust weights at every rebalancing date using the specified weights for each individual rebalancing date. 
        Rebalances on user defined rebalancing dates.
        
        :param weights:
           2-D List of weights for each asset in the portfolio, for every rebalance date. 
        :type weights:
            List[List[Union[float, int]]], optional
        
        :param rebalance_dates: List of dates or frequency interval for rebalancing. See :py:meth:`set_rebalance_dates` for more details.
        :type rebalance_dates: Union[List[Union[str, datetime, date]], str], optional

        :return: Current Portfolio object with updated allocation model
        :rtype: Portfolio

        .. note::
            API defaults to daily rebalancing if no rebalancing dates/intervals are specified

        Set custom weight portfolio for 2 assets and 3 rebalacing dates
        >>> weights = [
               [0.2, 0.8],
               [0.1, 0.9],
               [0.3, 0.7]]    
        >>> plbpy.Portfolio(
                universe=plbpy.Universe(session).code(["SBWGU","SPX"])
            ).set_custom_weight(weights, "1M")

        """
      
        self.__loader.set_custom_weight(weights, rebalance_dates)
        return self

    @log_factory(logger, DEBUG)
    def set_risk_parity(self, parity_interval: str = '1Y', return_interval: str = 'Daily' , rebalance_dates: Union[List[Union[str, datetime, date]], str] = 'D'):
        """
        Reconfigures allocation model and allocates weights inversely proportionally to each individual asset’s volatility. 
        Thus, the model normalizes the allocation across assets using volatility as reference and distributes risk throughout the portfolio.
        Rebalances on user defined rebalancing dates.
        
        :param parity_interval: The look back period at each rebalancing date for volatility calculation
        :type parity_interval: str

        :param return_interval: Return interval used for computing volatility
        :type return_interval: str

        :param rebalance_dates: List of dates or frequency interval for rebalancing. See :py:meth:`set_rebalance_dates` for more details.
        :type rebalance_dates: Union[List[Union[str, datetime, date]], str], optional

        :return: Current Portfolio object with updated allocation model
        :rtype: Portfolio

        .. note::
            API defaults to daily rebalancing if no rebalancing dates/intervals are specified

        Set equal risk contribution portfolio to be rebalanced every 2 months and volatility computed for the past 3 months weekly returns

        >>> plbpy.Portfolio(
                universe=plbpy.Universe(session).code(["SBWGU","SPX"])
            ).set_parity_interval('3M','Weekly','2M')
        
        """
        
        self.__loader.set_risk_parity(parity_interval, return_interval, rebalance_dates)
        return self

    @log_factory(logger, DEBUG)
    def set_leverage_parameters(self, method, target=1, vol_interval=None, min_vol=0, max_vol=10):
        """
        Reconfigures the leverage parameters of portfolio object.
        
        :param method: Scaling type. Can be None, leverage or volatility. Default: None
        :type method: str

        :param target: Leverage level in Fixed Leverage or volatility level in Volatility Target. Default: 1
        :type target: Union[float, int]

        :param vol_interval: Return periods used for volatility calculation used in the Volatility Target Function. 
        :type vol_interval: Union[List[Union[str, datetime, date]], str], optional

        :param min_vol: Lower boundary for Minimum Leverage of Scaling Function
        :type min_vol: Union[float, int]

        :param max_vol: Upper boundary for Minimum Leverage of Scaling Function
        :type max_vol: Union[float, int]

        :return: Current Portfolio object with updated allocation model
        :rtype: Portfolio
        
        
        >>> plbpy.Portfolio(
                universe=plbpy.Universe(session).code(["SBWGU","SPX"])
            ).set_leverage_parameters('leverage', 1, '1M', 1, 10)
        
        """
        self.__loader.set_leverage_parameters(method, target, vol_interval, min_vol, max_vol)
        return self

    @log_factory(logger, DEBUG)
    def run_backtest(self) -> Portfolio:
        """
        Backtests a Portfolio and measures the risk and perfomance metrics of the Portfolio.

        :return: Current Portfolio object with an updated :py:attr:`result` parameter
        :rtype: Portfolio

        Run backtest

        >>> plbpy.Portfolio(
                universe = universe.code("SPX", "SBWGU")
            ).run_backtest()
        """
        self.__loader.run_backtest()
        return self

    @log_factory(logger, DEBUG)
    def efficient_frontier(self):
        """
        Constructs a Portfolio and constructs an efficient frontier using it.

        :return: Current Portfolio object with an updated :py:attr:`result` parameter
        :rtype: Portfolio

        Run efficient frontier

        >>> plbpy.Portfolio(
                universe = universe.code("SPX", "SBWGU")
            ).efficient_frontier()
        """
        self.__loader.efficient_frontier()
        return self

    @log_factory(logger, DEBUG)
    def reset(self) -> Portfolio:
        """
        Resets all configurations of the current portfolio to default values

        :return: Current Portfolio object with default configuration
        :rtype: Portfolio

        """

        self.__loader.reset()
        return self

    @log_factory(logger, DEBUG)
    def copy(self) -> Portfolio:
        """
        Makes a copy of the current object

        :return: Copy of the Current Portfolio object with updated configuration
        :rtype: Portfolio

        .. note::
            User will have to run the backtest again to generate the results

        """
        current_info = self.info
        new_obj = Portfolio(universe=_gl_universe.code(self.universe.codes))
        new_obj.__loader._set_info_object(current_info)

        return new_obj

        


