"""
Dispersion takes a universe of strategies in order to compute a timeseries of a given performance metrics

"""

from __future__ import annotations

__all__ = ["Dispersion"]

import copy
from typing import Union, List, Optional, Iterable, Tuple
from plbpy.interface.Portfolio import Portfolio
from plbpy.interface.Universe import Universe

from plbpy.interface.Session import Session
from plbpy.utility.date_utils import datetime2str, today, to_date, date, datetime
from plbpy import session as _gl_session  # global session for fail case
from plbpy import log_factory, logger, console, DEBUG  # Log tools
from plbpy.core.loader.DispersionLoader import DispersionLoader

class Dispersion:
    @log_factory(logger, DEBUG)
    def __init__(
        self,
        universe: Universe = None,
        portfolio: Portfolio = None,
        codes: Optional[Union[Tuple[str, ...], List[str]]] = None,
        session=_gl_session,
        subset: Union[Universe, List[str]] = None,
    ):
        """Constructor

        :param universe: An instance of Universe
        :type universe: Universe, optional

        :param portfolio: An instance of Portfolio
        :type portfolio: Portfolio, optional

        :param session: The current session object provided
        :type session: Session, optional

        :param codes: List of asset tickers
        :type codes: Iterable[str], optional

        :param subset: A subset of assets
        :type subset: Union[Universe, Portfolio, List[str]], optional

        .. note::

            The assets can be passed strictly via one of the three methods:

            - A Universe object with the required assets
            - A Portfolio of the required assets
            - A list of required asset codes AND Session object

            Also note that the number of assets passed must not exceed 120 using any method. This will result in an exception while executing :py:meth:`run_dispersion`

            Construction with Universe

            >>> plbpy.Dispersion(universe=plbpy.universe.code('SPX','SBWGU'))

            Construction with Porfolio

            >>> plbpy.Dispersion(portfolio=plbpy.Portfolio(codes=['SPX','SBWGU']))

            Construction with list of codes

            >>> plbpy.Dispersion(codes=['SPX','SBWGU'])
        """
        self.__loader = DispersionLoader(universe=universe, portfolio=portfolio, codes=codes, subset=subset)

    # --- Public Dispersion Methods ---

    @log_factory(logger, DEBUG)
    def run_dispersion(self) -> Dispersion:
        """
        Computes the rolling performance metric of the universe and subset assets

        :return: Current Dispersion object with an updated :py:attr:`result` attribute
        :rtype: Dispersion
        :raises Exception: if number of assets in the universe are more than 120

        Compute rolling metrics:

        >>> plbpy.Dispersion(codes=['SPX','SBWGU']).run_dispersion()

        """
        self.__loader.run_dispersion()
        return self

    # --- Public Dispersion Properties ---

    @property
    def session(self) -> Session:
        """
        Gets current Session Object

        :rtype: Session

        """
        return self.__loader.session

    @property
    def universe(self) -> Universe:
        """
        Gets the Universe object of current Portfolio.

        :rtype: Universe

        """
        return self.__loader.universe

    @property
    def result(self):
        """
        Access the results of the computation

        :rtype: DispersionParser

        Get Min, Max, Average and IQR

        >>> plbpy.Dispersion(
                universe = universe.code("SPX", "SBWGU")
            ).run_dispersion().result.universe_dispersion()

        .. note:: Accessing this property before running :py:meth:`run_dispersion` will result in an error.

        """
        return self.__loader.result

    @property
    def info(self) -> api.DispersionCalcDto:
        """
        Gets the raw API input. This property is used to view all the information of the current Dispersion object such as time period, main and subset assets, target volatility, leverage, return interval, et cetera.

        .. warning:: User must not change this object explicitly, instead use the Dispersion helper functions.

        """
        return self.__loader.info

    # --- Private Dispersion Member ---

    @property
    def _raw_response(self):
        return self.result.raw

    # --- Dispersion info Getters ---

    @property
    def _interval(self) -> str:
        return self.info['returnInterval']

    @property
    def _start(self) -> date:
        return to_date(self.info['listStartDates'][0])

    @property
    def _end(self) -> date:
        return to_date(self.info['endDate'])

    @property
    def _codes(self) -> List[str]:
        return self.info['listCodes']

    @property
    def _metric(self) -> str:
        return self.info['metric']

    @property
    def _rolling_window(self) -> float:
        return self.info['rollingWindow']

    @property
    def _subset(self) -> List[str]:
        return self.info['subset']

    # --- Portfolio info Functional Setters ---

    @log_factory(logger, DEBUG)
    def set_start(self, start_date: Union[date, datetime, str]) -> Dispersion:
        """
        Sets Dispersion start date.

        :param start_date: Date at which computation should begin. If passing str, date should be in YYYY-MM-DD format
        :type start_date: Union[date, datetime, str]

        :return: Current Dispersion object with an updated start date
        :rtype: Dispersion

        :raise AssertionError: If attempting to set start date after end date

        Start computation from 1st Jan 2015

        >>> plbpy.Dispersion(
                universe = universe.code("SPX", "SBWGU")
            ).set_start('2015-01-01')
        """
        self.__loader.set_start(start_date)
        return self

    @log_factory(logger, DEBUG)
    def set_end(self, end_date: Union[date, datetime, str]) -> Dispersion:
        """
        Sets Dispersion end date.

        :param start_date: Date at which computation should end. If passing str, date should be in YYYY-MM-DD format
        :type start_date: Union[date, datetime, str]

        :return: Current Dispersion object with an updated end date
        :rtype: Dispersion

        :raise AssertionError: If attempting to set end date after today

        Ending computation at 1st Dec 2010

        >>> plbpy.Dispersion(
                universe = universe.code("SPX", "SBWGU")
            ).set_end('2020-12-01')
        """

        self.__loader.set_end(end_date)
        return self

    @log_factory(logger, DEBUG)
    def set_return_interval(self, interval: str) -> Dispersion:
        """
        Sets return interval for computation

        :param interval: Return interval
        :type interval: str

        :return: Current Dispersion object with an updated return interval
        :rtype: Dispersion

        :raise AssertionError: if interval is not in ['Daily', 'Weekly' or 'Monthly']

        Set Weekly interval

        >>> plbpy.Dispersion(universe = universe.code(['SPX','SBWGU'])).set_return_interval('Weekly)

        """
        self.__loader.set_return_interval(interval)
        return self

    @log_factory(logger, DEBUG)
    def set_rolling_window(self, window: float) -> Dispersion:
        """
        Sets rolling window length

        :param window: Rolling window
        :type window: float

        :return: Current Dispersion class with updated rolling window
        :rtype: Dispersion

        Set rolling window to 52

        >>> plbpy.Dispersion(universe = universe.code(['SPX','SBWGU'])).set_rolling_window(52.0)

        """
        self.__loader.set_rolling_window(window)
        return self

    @log_factory(logger, DEBUG)
    def set_metric(self, metric: str) -> Dispersion:
        """
        Sets the metric to be computed for the universe

        :param metric: Metric of choice
        :type metric: str

         Allowed Values:
        - Return Per Anum
        - Volatility
        - Sharpe Ratio
        - Information Ratio
        - Cumulative Return

        :raises AssertionError: if metric is not in allowed values

        :returns: Current Dispersion object with an updated metric choice
        :rtype: Dispersion

        Setting metric to Information Ratio

        >>> plbpy.Dispersion(universe = universe.code(['SPX','SBWGU'])).set_metric('Information Ratio')

        """
        allowed = [
            "return per annum",
            "volatility",
            "sharpe ratio",
            "information ratio",
            "cumulative return",
        ]
        self.__loader.set_metric(metric)
        return self

    @log_factory(logger, DEBUG)
    def set_subset(self, subset: Union[List[str],Universe]) -> Dispersion:
        """
        .. warning::
            If a subset already exists, this method will replace the exisiting subset universe

        Sets the subset universe of the Dispersion.

        :param subset: A list of asset tickers
        :type subset: List[str]

        :returns: Current Dispersion object with an updated subset
        :rtype: Dispersion

        Add EURUSD and SPGLOB as the subset universe

        >>> plbpy.Dispersion(universe = universe.code(['SPX','SBWGU'])).set_subset(['EURUSD','SPGLOB'])

        """
        self.__loader.set_subset(subset)
        return self

    @log_factory(logger, DEBUG)
    def set_volatility_scale(
        self,
        vol_interval: str,
        vol_target: Union[str, float],
        rebalance_dates: Optional[Union[List[Union[str, datetime, date]], str]] = None,
    ):
        """
        Updates the volatility parameters of the current Dispersion object

        :param vol_interval: The time interval to calculate volatility on before each rebalancing date
        :type vol_interval: str

        :param vol_target: Scaling the volatility of each strategy in universe and subset to either a numeric volatility target or a specific ticker
        :type vol_target: Union[str, float]

        :param rebalance_dates: List of dates or frequency interval for rebalancing, default None
        :type rebalance_dates: Optional[Union[List[Union[str, datetime, date]], str]]

        :return: Current Dispersion object with updated volatility adjustment parameters
        :rtype: Dispersion

        .. tip::

            Accepted inputs for `rebalance_dates`
                - list[str]: list of 'YYYY-MM-DD'
                - list[date/datetime]: list of DatetimeIndex
                - str: `pandas.date_range.frequency <https://pandas.pydata.org/pandas-docs/stable/user_guide/timeseries.html#timeseries-offset-aliases>`_ keywords

            Accepted inputs for `vol_interval`
                - ["1M", "3M", "6M", "1Y", "2Y", "3Y", "4Y", "5Y"]

        Quarterly Rebalancing, 1 Month volatility interval, Scale volatility to 10%

        >>> plbpy.Dispersion(
                universe = us_equity_value_universe
                subset = us_equity_value_factor
            ).set_volatility_scale("Q", "1M", 0.1)

        Rebalance on specific dates, 3 Month volatility interval, Scale volatility to SPX

        >>> plbpy.Dispersion(
                universe = us_equity_value_universe,
                subset = us_equity_value_factor
            ).set_volatility_scale(["2010-01-01", "2020-01-01"], "3M", "SPX")
        """
        self.__loader.set_volatility_scale(vol_interval=vol_interval, vol_target=vol_target, rebalance_dates=rebalance_dates)
        return self

    @log_factory(logger, DEBUG)
    def copy(self) -> Dispersion:
        """
        Makes a copy of the current object

        :return: Copy of the Current HCluster object with updated configuration
        :rtype: HCluster

        .. note::
            User will have to run the analysis again to generate the results

        """
        current_info = self.info
        new_obj = Dispersion(universe=self.universe)
        new_obj.__loader.info = current_info

        return new_obj
