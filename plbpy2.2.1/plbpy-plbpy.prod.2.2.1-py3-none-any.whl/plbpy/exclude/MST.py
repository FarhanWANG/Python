"""
MST takes a universe of assets in order to construct a Minimum Spanning Tree using Prim's algorithm.
"""
from __future__ import annotations

__all__ = ["MST"]

from plbpy import universe as _gl_universe
from typing import Union, List
from plbpy.core.loader.MSTLoader import MSTLoader

from plbpy.utility.date_utils import to_date, date, datetime
from plbpy import session as _gl_session  # global session for fail case
from plbpy import log_factory, logger, DEBUG # Log tools


class MST:
    @log_factory(logger, DEBUG)
    def __init__(self, universe=None, portfolio=None, codes=None, session=_gl_session):
        """Constructor

        :param universe: An instance of Universe
        :type universe: Universe, optional

        :param portfolio: An instance of Portfolio
        :type portfolio: Portfolio, optional

        :param session: The current session object provided
        :type session: Session, optional

        :param codes: List of asset tickers
        :type codes: Iterable[str], optional

        .. note::

            The assets can be passed strictly via one of the three methods:

            - A Universe object with the required assets
            - A Portfolio of the required assets
            - A list of required asset codes AND Session object

            Also note that the number of assets passed must not exceed 400 using any method. This will result in an exception while executing :py:meth:`run_mst`

            Construction with Universe

            >>> plbpy.MST(universe=plbpy.Universe(session).code('SPX','SBWGU'))

            Construction with Porfolio

            >>> plbpy.MST(portfolio=plbpy.Portfolio(session, codes=['SPX','SBWGU']))

            Construction with list of codes

            >>> plbpy.MST(codes=['SPX','SBWGU'])

        """
        self.__loader = MSTLoader(universe=universe, portfolio=portfolio, codes=codes)

    # --- Public MST Methods ---

    @log_factory(logger, DEBUG)
    def run_mst(self) -> MST:
        """
        Runs computations to construct the MST. This includes computing distances and correlation between assets, x & y positions on the tree, parent & children nodes et ceetra.

        :return: Current MST object with an updated :py:attr:`result` attribute
        :rtype: MST

        Compute MST:

        >>> plbpy.MST(codes=['SPX','SBWGU']).run_mst()

        """

        self.__loader.run_mst()

        return self

    @property
    def session(self):
        """
        Gets current Session Object

        :rtype: Session

        """
        return self.__loader.session

    @property
    def universe(self):
        """
        Gets the Universe object of current Portfolio.

        :rtype: Universe

        """
        return self.__loader.universe

    @property
    def result(self):
        """
        Access the results of the computation

        :rtype: MST

        Get results

        >>> plbpy.MST(
                universe = universe.code("SPX", "SBWGU")
            ).run_mst().result.tree()

        .. note:: Accessing this property before running :py:meth:`run_mst` will result in an error.

        """
        return self.__loader.result

    @property
    def info(self):
        """
        Gets the raw API input. This property is used to view all the information of the current MST object such as time period, return interval, correlation type.

        .. warning:: User must not change this object explicitly, instead use the MST helper functions.

        """
        return self.__loader.info

    # --- MST info getters ---
    @property
    def _type(self):
        return self.info['correlationType']

    @property
    def _interval(self):
        return self.info['returnInterval']

    @property
    def _start(self) -> date:
        return to_date(self.info['listStartDates'][0])

    @property
    def _end(self) -> date:
        return to_date(self.info['endDate'])

    @property
    def _codes(self) -> List[str]:
        return self.info['listCodes']

    # --- MST Functional Setters ---

    @log_factory(logger, DEBUG)
    def set_start(self, start_date: Union[date, datetime, str]) -> MST:
        """
        Sets MST start date.

        :param start_date: Date at which computation should begin. If passing str, date should be in YYYY-MM-DD format
        :type start_date: Union[date, datetime, str]

        :return: Current MST object with an updated start date
        :rtype: MST

        :raise AssertionError: If attempting to set start date after end date

        Start computation from 1st Jan 2015

        >>> plbpy.MST(
                universe = universe.code("SPX", "SBWGU")
            ).set_start('2015-01-01')
        """
        self.__loader.set_start(start_date)
        return self

    @log_factory(logger, DEBUG)
    def set_end(self, end_date: Union[date, datetime, str]) -> MST:
        """
        Sets MST end date.

        :param start_date: Date at which computation should end. If passing str, date should be in YYYY-MM-DD format
        :type start_date: Union[date, datetime, str]

        :return: Current MST object with an updated end date
        :rtype: MST

        :raise AssertionError: If attempting to set end date after today

        Ending computation at 1st Dec 2010

        >>> plbpy.MST(
                universe = universe.code("SPX", "SBWGU")
            ).set_end('2020-12-01')
        """
        self.__loader.set_end(end_date)
        return self

    @log_factory(logger, DEBUG)
    def set_return_interval(self, interval) -> MST:
        """
        Sets return interval for computation

        :param interval: Return interval
        :type interval: str

        :return: Current MST object with an updated return interval
        :rtype: MST

        :raise AssertionError: if interval is not in ['Daily', 'Weekly' or 'Monthly']

        Set Weekly interval

        >>> plbpy.MST(universe = universe.code(['SPX','SBWGU'])).set_return_interval('Weekly)

        """
        self.__loader.set_return_interval(interval)
        return self

    @log_factory(logger, DEBUG)
    def set_type(self, type) -> MST:
        """
        Sets the correlation calculation method. Allowed values:
        - Pearson
        - Spearman

        :param type: Correlation method
        :type type: str

        :return: Current MST object with update correlation type
        :rtype: MST

        :raise AssertionError: if type is not in allowed values

        Set Pearson as correlation method:

        >>> plbpy.MST(universe = universe.code(['SPX','SBWGU'])).set_type('Pearson')
        """
        self.__loader.set_correlation_type(type)
        return self

    @log_factory(logger, DEBUG)
    def set_correlation_type(self, correl_type) -> MST:
        """
        Sets the correlation calculation method. Allowed values:
        - Pearson
        - Spearman

        :param type: Correlation method
        :type type: str

        :return: Current MST object with update correlation type
        :rtype: MST

        :raise AssertionError: if type is not in allowed values

        Set Pearson as correlation method:

        >>> plbpy.MST(universe = universe.code(['SPX','SBWGU'])).set_correlation_type('Pearson')
        """
        self.__loader.set_correlation_type(correl_type)
        return self

    @log_factory(logger, DEBUG)
    def copy(self) -> MST:
        """
        Makes a copy of the current object

        :return: Copy of the Current MST object with updated configuration
        :rtype: MST

        .. note::
            User will have to run the analysis again to generate the results

        """
        current_info = self.info
        new_obj = MST(universe=_gl_universe.code(self.universe.codes))
        new_obj.__loader.info = current_info

        return new_obj

    @log_factory(logger, DEBUG)
    def reset(self) -> MST:
        """
        Resets all configurations of the current mst to default values

        :return: Current MST object with default configuration
        :rtype: MST

        """

        self.__loader.reset()
        return self