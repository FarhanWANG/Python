"""
This interface is used to access precomputed Exposures, Sensitivities, Historical Stress Tests, Transitive Stress Tests and Value-at-Risk of the Portfolio
"""

from __future__ import annotations

__all__ = ["Risk"]

from plbpy.core.loader.RiskLoader import RiskLoader
from typing import List, Union, Dict
from plbpy.utility.date_utils import date, datetime
from plbpy import session as _gl_session  # global session for fail case
from plbpy import log_factory, logger, console, DEBUG, INFO  # Log tools


class Risk:
    @log_factory(logger, DEBUG)
    def __init__(self, session=_gl_session):
        """Constructor
        Initializes a Risk object with the seesion object

        :param session: The current session object provided
        :type session: Session

        >>> risk = plbpy.Risk(session)
        >>> risk.portfolios
        ["XYZ", "Portfolio1", "Portfolio2"]
        >>> risk.set_id("XYZ")

        """
        self.id = ""
        self.session = session
        self.__loader = RiskLoader(self.session)

    def set_id(self, id) -> Risk:
        """
        Sets the Portfolio ID of this Risk Data Accessor object

        :param id: The portfolio id
        :type id: str
        """
        self.id = id
        self.__loader.set_id(self.id)
        self.options = self.__loader.options
        self.segments = self.__loader.segments

        return self

    @property
    def portfolios(self):
        """
        View available strategies in portfolio
        """
        return self.__loader.portfolios

    @property
    def strategy_values(self):
        """
        Access the strategy's dollar value on a daily basis
        """
        return self.__loader.strategy_values

    @property
    def static_info(self):
        """
        Access portfolio's strategies' static information
        """
        return self.__loader.static_info

    @property
    def available_dates(self):
        """
        View dates for which metrics are accessible
        """
        return self.__loader.available_dates

    @property
    def available_strategies(self):
        """
        View available strategies in portfolio
        """
        return self.__loader.available_strategies

    @property
    def options(self):
        """
        Property to access all risk metrics options available. This is a convenient way to add inputs into :py:meth:`get_risk_metrics`

        Example

        >>> risk.options.TransitiveStress.Coffee_minus_10pct
            'Coffee -10%'

        .. tip::

            Press `<tab>` after typing :py:attr:`risk.options.` and select any risk category by highlighting hitting enter
            Press `<tab>` again to view all metrics in the chosen category

        """

        return self._options

    @options.setter
    def options(self, value):
        self._options = value

    @property
    def segments(self):
        """
        Property to access all available segment names of a portfolio. This is a convenient way to add inputs into :py:meth:`get_risk_metrics`

        Example

        >>> risk.segments.Segment.Asset_Category
            'Asset Category'

        .. tip::

            Press `<tab>` after typing :py:attr:`risk.segments.Segment.` to view all segment names

        """
        return self._segments

    @segments.setter
    def segments(self, value):
        self._segments = value

    @property
    def id(self):
        return self._id

    @id.setter
    def id(self, value):
        self._id = value

    @log_factory(logger, DEBUG)
    def risk_metrics(
        self,
        metrics: List[str],
        group_by: List[str] = ["Strategy"],
        filter_by: List[Dict[str, List[str]]] = None,
        start: Union[str, date, datetime] = None,
        end: Union[str, date, datetime] = None,
        threads: int = 15,
        **kwargs,
    ):
        """
        Communicates with the APIs to receive raw risk metric datasets and parses the response in a human-readable format

        :param metrics: A list of risk metrics
        :type metric: List[str]

        .. note::
        A convenient way to the list values can be found in :py:attr:`options`

        :param aggregate_by: A list of Portoflio characteristcs
        :type aggregate_by: List[str], optional

        .. note::

            Possible values for aggregate_by are:
                - Strategy
                - Country
                - Currency
                - Instrument
                - Product Type
                - Region
                - Sector
                - Asset Category

            The number and order of the output index will correspond to the length of the **aggregate_by** list

            A convenient way to list available enumerations can be found in :py:attr:`segments`

        .. warning::

            The order of elements in the aggregate_by attribute is extremely important. If you wish to view certain metrics for each strategy
            in each asset class, the list should contain **Asset Category** first i.e. `['Asset_Category', 'Strategy']`. On the other hand, if the user
            wants to see metrics for each asset category in each strategy, the order of the list will be inverted. Even though the elements are the same in the two,
            rearranging the order will result in very different sum values

        :param filter: A list of constraints
        :type filter: List[List[Union[str,List[str]]]], optional

        :param start: Date when risk analysis should start
        :type start: str, Timestamp, datetime.date

        :param end: Date when risk analysis should end
        :type end: str, Timestamp, datetime.date

        If passing str, date should be in YYYY-MM-DD format

        :returns: Risk Metrics
        :rtype: pd.DataFrame


        View Notional Long, Notional Short and all Sensitivity measures aggregated by EUR and US Dollar Commodity strategies

        >>> risk.get_risk_metrics(
                metrics = [
                    risk.options.Exposure.Exposure_Long,
                    risk.options.Exposure.Exposure_Short,
                    risk.options.Sensitivity
                ],
                aggregate_by = [
                    risk.segments.Segment.Country,
                    risk.segments.Segment.Strategy
                ],
                filter_by = {
                    risk.segments.Segment.Currency: ['USD','EUR'],
                    risk.segments.Segment.Asset_Category: ['Commodity']
                }
        )
        """
        version = kwargs.get("version", 2)
        return self.__loader.get_api_metrics(
            metrics=metrics,
            aggregate_by=group_by,
            filter_by=filter_by,
            start=start,
            end=end,
            threads=threads,
            version=version,
        )
