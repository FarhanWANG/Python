from __future__ import annotations
__all__ = ["Regression"]

from typing import Union, List, Optional, Iterable
from plbpy.interface.Session import Session
from plbpy.interface.Portfolio import Portfolio
from plbpy.interface.Universe import Universe
from plbpy.utility.date_utils import (
    date,
    datetime
)
from plbpy import session as _gl_session  # global session for fail case
from plbpy import log_factory, logger, DEBUG  # Log tools
from plbpy.core.loader.RegressionLoader import RegressionLoader


class Regression:

    @log_factory(logger, DEBUG)
    def __init__(self,
        Y: Union[Universe, Portfolio, str, Iterable[str]],
        X: Union[Universe, str, Iterable[str]],
        session: Session = _gl_session,
    ) -> None:
        """Constructor

        :param X: The independent variable / regressor.
        :type X: Universe, str, Iterable[str]
        :param Y: The dependent variable / regressand.
        :type Y: Universe, Portfolio, str, Iterable[str]
        :param session: The current session object provided
        :type session: Session

        .. note::
            The dependent variable (Y) must only contain a single asset if a Universe or Iterable[str] is passed. Multiple assets can only be passed using a Portfolio object.
            Any deviation from this will result in an error during :py:func:`run_regression`

            Regression object construction with list of codes:

            >>> plbpy.Regression(Y="PFEQVAUS",
                                 X=["SPX", "SBWGU"])

            Regression object construction with a Universe object:

            >>> plbpy.Regression(Y=universe.code("PFEQVAUS"),
                                 X=universe.code(["SPX", "SBWGU"])

            Regression object construction with a Universe object and Portfolio objects:

            >>> portfolio = plbpy.Portfolio(universe.code(["SXXR", "ITRROV"]))
            >>> plbpy.Regression(Y=portfolio,
                                 X=universe.code(["SPX", "SBWGU"])

        """
        self.__loader = RegressionLoader(Y, X, session)

    # ----- PUBLIC REGRESSION PROPERTIES -----

    @property
    def info(self):
        """
        Gets the raw API input. This property is used to view all the information of the current Regression object.

        .. warning:: User must not change this object explicitly, instead use the :py:obj:`Regression` helper functions.
        """
        return self.__loader.info


    @property
    def result(self):
        """
        Access the results of the regression

        :rtype: RegressionParser

        .. note:: Accessing this property before running :py:meth:`run_regression` will result in an error.

        Get model summary such as Beta, lower and upper bounds, return and risk proportions etc.

        >>> plbpy.Regression(
                X = universe.code("SPX", "SBWGU"),
                Y = universe.code("SXXR")
            ).run_regression().result.model_summary

        """
        return self.__loader.result
    
    @property
    def x_universe(self) -> Universe:
        """
        Gets Universe object of dependent variables

        """
        return self.__loader.x_universe
    
    @property
    def y_universe(self) -> Universe:
        """
        Gets Universe object of independent variables

        """
        return self.__loader.y_universe
    
    @property
    def session(self) -> Session:
        """
        Gets current Session Object

        :rtype: Session

        """
        return self.__loader.session
    
    @property
    def start(self):
        """
        Gets current start date

        :rtype: Session

        """
        return self.__loader.start

    @property
    def end(self):
        """
        Gets current start date

        :rtype: Session

        """
        return self.__loader.end

    # ----- Public Regression Setter Methods -----
    @log_factory(logger, DEBUG)
    def set_start(self, start_date: Union[date, datetime, str]) -> Regression:
        """
        Sets Regression start date.

        :param start_date: Date at which regression analysis should begin. If passing str, date should be in YYYY-MM-DD format
        :type start_date: Union[date, datetime, str]

        :return: Current Regression object with an updated start date
        :rtype: Regression

        :raise AssertionError: If attempting to set start date after end date

        Start regression analysis from 1st Jan 2015

        >>> plbpy.Regression(
                X = universe.code("SPX", "SBWGU"),
                Y = universe.code("SXXR")
            ).set_start('2015-01-01')
        """
        self.__loader.set_start(start_date)
        return self

    @log_factory(logger, DEBUG)
    def set_end(self, end_date: Union[date, datetime, str]) -> Regression:
        """
        Sets Regression end date.

        :param end_date: Date at which regression analysis should end.  If passing str, date should be in YYYY-MM-DD format
        :type end_date: Union[date, datetime, str]

        :return: Current Regression object with an updated end date
        :rtype: Regression

        :raise AssertionError: If attempting to set end date after today

        End regression analysis on 1st Jan 2020

        >>> plbpy.Regression(
                X = universe.code("SPX", "SBWGU"),
                Y = universe.code("SXXR")
            ).set_end('2020-01-01')

        """
        self.__loader.set_end(end_date)
        return self

    @log_factory(logger, DEBUG)
    def set_y(self, Y: Union[Portfolio, Universe, str, List[str]]) -> Regression:
        """
        .. warning::
            This will reset the configuration of the regression and replace it with a new Regression object

        Updates the regressands

        :param Y: The new regressands
        :type Y: Union[Portfolio, Universe, str, List[str]]

        :return: Regression object with an updated regressand
        :rtype: Regression

        :raise AssertionError: If input is NOT a Portfolio instance AND the number of assets is more than 1

        Replace current regressand with HFRX Global Hedge Fund:

        >>> plbpy.Regression(
                Y = universe.code('SPX'),
                X = universe.code('SXXR')
            ).set_y(universe.code('HFRXGL'))

        """
        self.__loader.set_y(Y)
        return self

    @log_factory(logger, DEBUG)
    def set_x(self, X: Union[Universe, List[str]]) -> Regression:
        """
        .. warning::
            This will reset the configuration of the regression and replace it with a new Regression object

        Updates the regressors

        :param X: The new regressors
        :type X: Union[Universe, List[str]]

        :return: Regression object with an updated regressor
        :rtype: Regression

        Replace current regressor with HFRXGL and SPTR500N:

        >>> plbpy.Regression(
                Y = universe.code('SPX'),
                X = universe.code('SXXR')
            ).set_x(universe.code('HFRXGL','SPTR500N'))
        """
        self.__loader.set_x(X)
        return self

    @log_factory(logger, DEBUG)
    def set_lasso(self, selection: int = 0) -> Regression:
        """
        Sets the LASSO selection number of the Regression Model

        .. note::
            - The regression type defaults to Ordinary Least Square (OLS) at the time of construction
            - Using this method the regression type will change to LASSO, which performs L1 regularization.

        :param selection: Number of variables to be selected
        :type selection: int

        :return: Current Regression object with an updated LASSO parameter and regression type
        :rtype: Regression

        Set regression to consider 2 variables after performing shrinkage

        >>> plbpy.Regression(
                Y = universe.code('SPX','SBWGU'),
                X = universe.code('SXXR', 'SX5E', 'UKX', 'HFRXGL')
            ).set_lasso(2)

        """
        self.__loader.set_lasso(selection)
        return self

    @log_factory(logger, DEBUG)
    def set_return_interval(self, return_interval: str = "Daily") -> Regression:
        """
        Sets the Regression Return Interval

        :param return_interval: Return interval
        :type return_interval: str

        :return: Current Regression object with updated return interval
        :rtype: Regression

        :raise ValueError: If input is not 'Weekly', 'Monthly' or 'Daily' (case insensitive)

        Use weekly returns

        >>> plbpy.Regression.set_return_interval('weekly')

        Use monthly returns

        >>> plbpy.Regression(
                Y = universe.code("SPX", "SBWGU"),
                X = universe.code('SXXR')
            ).set_return_interval('Monthly')

        """
        self.__loader.set_return_interval(return_interval)
        return self

    @log_factory(logger, DEBUG)
    def set_rolling_window(self, window: str = None) -> Regression:
        """
        Sets the Rolling Window to use for Rolling Regression

        :param window: Rolling window
        :type window: str, Optional

        :return: Current regression object with updated rolling window
        :rtype: Regresion

        :raise ValueError: If rolling window is not in "Monthly", "Quaterly" or "Yearly"

        Use monthly rolling window

        >>> plbpy.Regression(
                Y = universe.code("SPX", "SBWGU"),
                X = universe.code('SXXR')
            ).set_rolling_window('Monthly')

        Use yearly rolling window

        >>> plbpy.Regression(
                Y = universe.code("SPX", "SBWGU"),
                X = universe.code('SXXR')
            ).set_rolling_window('yearly')

        """
        self.__loader.set_rolling_window(window)
        return self

    @log_factory(logger, DEBUG)
    def set_model_interval(self, interval: int) -> Regression:
        """
        Sets the Model Interval to use for Rolling Regression

        :param interval: Model Interval
        :type interval: int

        :return: Current Regression object with an updated model interval
        :rtype: Regression
        """
        self.__loader.set_model_interval(interval)
        return self

    @log_factory(logger, DEBUG)
    def set_sign_select(self, sign: bool) -> Regression:
        """
        Sets the regression to perform sign constrained regression

        :param sign: True for enabling constraints
        :type param: bool

        :return: Current Regression object with an updated sign selection constraint
        :rtype: Regression

        """
        self.__loader.set_sign_select(sign)
        return self
    
    @log_factory(logger, DEBUG)
    def run_regression(self) -> Regression:
        """
        Performs regression computations to best predict the regressand using the regressors

        :return: Current Regression object with an updated :py:attr:`result` parameter
        :rtype: Regression

        :raise Exception: if number of regressand assets is more than 1 or is not a Portfolio object

        Run Regression

        >>> plbpy.Regression(X=['SPX','SBWGU'], Y=['SXXR']).run_regression()

        """
        # Validate regression build during init, checks current input structure
        self.__loader.run_regression()
        return self
    
    @log_factory(logger, DEBUG)
    def reset(self) -> Regression:
        """
        Resets all configurations of the current regression object to default values

        :return: Current Regression object with default configuration
        :rtype: Regression

        """
        self.__loader.reset()
        return self

    @log_factory(logger, DEBUG)
    def copy(self) -> Regression:
        """
        Makes a copy of the current object

        :return: Copy of the Current Regression object with updated configuration
        :rtype: Regression

        .. note::
            User will have to run the regression again to generate the results

        """
        current_info = self.info
        new_obj = Regression(X=self.x_universe, Y=self.y_universe, session=self.session)
        new_obj.__loader._set_info_object(current_info)

        return new_obj
