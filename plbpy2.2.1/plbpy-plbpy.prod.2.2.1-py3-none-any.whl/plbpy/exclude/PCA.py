"""
PCA takes a universe of assets, helps with constructing a backtesting object and provides an interface to access the results of the analysis
"""
from __future__ import annotations

__all__ = ["PCA"]

from typing import Union, List, Iterable
from plbpy import session as _gl_session
from plbpy import universe as _gl_universe
from plbpy.interface.Session import Session
from plbpy.core.loader.PCALoader import PCALoader
from plbpy.interface.Universe import Universe
from plbpy.interface.Portfolio import Portfolio
from plbpy.utility.date_utils import to_date, date, datetime

from plbpy import log_factory, logger, console, DEBUG  # Log tools


class PCA:

    @log_factory(logger, DEBUG)
    def __init__(
        self,
        universe: Union[Universe, Portfolio, List] = None,
        portfolio: Portfolio = None,
        session: Session = _gl_session,
        codes: Iterable[str] = None,
    ):
        """Constructor

        :param universe: An instance of Universe, defaults to None
        :type universe: Universe, optional
        :param portfolio: An instance of Portfolio (with or without the backtest result), defaults to None
        :type portfolio: Portfolio, optional
        :param session: The current session object provided, defaults to None
        :type session: Session, optional
        :param codes: List of tickers, defaults to None
        :type codes: Iterable[str], optional

        .. note::
            The input should be either (in order of preference) **a Universe object**,
            **a list of codes and session object** or **a Portfolio object**
            but not a combination of any of these

            PCA construction with universe object

            >>> plbpy.PCA(
                    universe = universe.code("SPX", "SBWGU")
                )

            PCA construction with portfolio object

            >>> universe = plbpy.universe.code("SPX", "SBWGU")
            >>> portfolio = plbpy.Portfolio(universe = universe)
            >>> plbpy.PCA(
                    portfolio = portfolio
                )

            PCA construction with list of codes

            >>> plbpy.PCA(
                    codes = ["SPX", "SBWGU"]
                )
        """
        self.__loader = PCALoader(universe=universe, codes=codes, portfolio=portfolio)

    # --- Public PCA Methods ---

    @log_factory(logger, DEBUG)
    def run_pca(self) -> PCA:
        """
        Builds a Principal Component Analysis using inputs and stores results as structured objects

        :return: Current PCA object with an updated :py:attr:`result` parameter
        :rtype: PCA

        Run PCA

        >>> plbpy.PCA(
                universe = universe.code("SPX", "SBWGU")
            ).run_pca()
        """
        self.__loader.run_pca()
        return self


    @property
    def session(self) -> Session:
        """
        Gets current session object

        :rtype: Session
        """
        return self.__loader.session

    @property
    def universe(self) -> Universe:
        """
        Gets current universe object

        :rtype: Universe
        """
        return self.__loader.universe

    @property
    def info(self):
        """
        Gets the raw API input. This property is used to view all the information of the current pca object such as input assets, return interval, covariance type,  et cetera.

        .. warning:: User must not change this object explicitly, instead use the :py:obj:`PCA` helper functions.
        """
        return self.__loader.info

    @property
    def result(self):
        """
        Access the results of the backtest

        :rtype: PCAParser

        Get static metrics

        >>> plbpy.PCA(
                universe = universe.code("SPX", "SBWGU")
            ).run_pca().result.static_metric

        .. note:: Accessing this property before running :py:meth:`run_pca` will result in an error.

        """

        return self.__loader.result
    # ---- PCA info Getters ----

    @property
    def _start(self) -> date:
        return to_date(self.info['pca']['listStartDates'][0])

    @property
    def _end(self) -> date:
        return to_date(self.info['pca']['endDate'])

    @property
    def _codes(self) -> List[str]:
        return self.info['pca']['listCodes']

    # --- PCA info Functional Setters ---

    @log_factory(logger, DEBUG)
    def set_start(self, start_date: Union[date, datetime, str]) -> PCA:
        """
        Sets PCA start date

        :param start_date: Date at which PCA should begin. If passing str, date should be in YYYY-MM-DD format
        :type start_date: Union[date, datetime, str]
        :return: Current PCA object with an updated start date
        :rtype: PCA
        :raise AssertionError: If attempting to set start date after end date

        Run PCA with data from 1st Jan 2015

        >>> plbpy.PCA(
                universe = universe.code("SPX", "SBWGU")
            ).set_start('2015-01-01')
        """
        self.__loader.set_start(start_date)
        return self

    @log_factory(logger, DEBUG)
    def set_end(self, end_date: Union[date, datetime, str]) -> PCA:
        """
        Sets PCA end date

        :param end_date: Date at which PCA should end. If passing str, date should be in YYYY-MM-DD format
        :type end_date: Union[date, datetime, str]
        :return: Current PCA object with an updated end date
        :rtype: PCA
        :raise AssertionError: If attempting to set end date after today

        Run PCA with data until 1st Jan 2020

        >>> plbpy.PCA(
                universe = universe.code("SPX", "SBWGU")
            ).set_end('2020-01-01')
        """
        self.__loader.set_end(end_date)
        return self

    @log_factory(logger, DEBUG)
    def set_return_interval(self, return_interval: 'str' ='Daily') -> PCA:
        """
        Sets the analysis Return Interval

        :param value: Return interval
        :type value: str

        :return: Current PCA object with updated return interval
        :rtype: PCA

        :raise ValueError: If input is not 'Daily', 'Weekly', 'Monthly', 'Monthly', 'Quarterly', 'Yearly' (case insensitive)

        Use weekly returns

        >>> plbpy.PCA.set_return_interval('Weekly')

        Use monthly returns

        >>> plbpy.PCA(
                universe = universe.code("SPX", "SBWGU")
            ).set_return_interval('monthly')

        """
        self.__loader.set_return_interval(return_interval)
        return self

    @log_factory(logger, DEBUG)
    def set_type(self, cov_type: 'str' = 'Covariance') -> PCA:
        """
        Sets the analysis metric type

        :param value: cov_type
        :type value: str

        :return: Current PCA object with updated return interval
        :rtype: PCA

        :raise ValueError: If input is not 'covariance','correlation' (case insensitive)

        """
        self.__loader.set_type(cov_type)
        return self

    @log_factory(logger, DEBUG)
    def copy(self) -> PCA:
        """
        Makes a copy of the current object

        :return: Copy of the Current PCA object with updated configuration
        :rtype: PCA

        .. note::
            User will have to run the analysis again to generate the results

        """
        current_info = self.info
        new_obj = PCA(universe=_gl_universe.code(self.universe.codes))
        new_obj.__loader.info = current_info

        return new_obj

    @log_factory(logger, DEBUG)
    def reset(self) -> PCA:
        """
        Resets all configurations of the current pca to default values

        :return: Current PCA object with default configuration
        :rtype: PCA

        """

        self.__loader.reset()
        return self