import json
import logging
import requests
from logging import FileHandler, LoggerAdapter, LogRecord, Handler, Formatter
from logging.handlers import HTTPHandler, MemoryHandler
from logging import DEBUG, INFO, ERROR
from typing import *
from functools import wraps


def init_console_logger():
    """
    stdout logger to output INFO level logs
    """
    console = logging.getLogger("plbpy.core")
    console.setLevel(logging.INFO)

    ch = logging.StreamHandler()  # Console Logger
    ch.setLevel(logging.INFO)
    console_format = logging.Formatter("%(message)s")  # Only message
    ch.setFormatter(console_format)

    console.addHandler(ch)
    return console


class CustomHandler(MemoryHandler):
    def __init__(
        self,
        capacity: int = 200,
        flushLevel: int = ERROR,
        target: Optional[Handler] = logging.NullHandler,
        flushOnClose: bool = True,
    ) -> None:
        super().__init__(
            capacity, flushLevel=flushLevel, target=target, flushOnClose=flushOnClose
        )

    def flush(self) -> None:
        self.acquire()
        try:
            if self.target:
                self.target.handle(self.buffer)  # Overwrite and send list of records
                self.buffer = []
        finally:
            self.release()

    def close(self) -> None:
        self.buffer.append(
            LogRecord(
                name=None,
                level=DEBUG,
                pathname=None,
                lineno=None,
                msg=f"End Session",
                args=None,
                exc_info=None,
            )
        )
        return super().close()


class LoggerAdapterCustom(LoggerAdapter):
    def process(
        self, msg: Any, kwargs: MutableMapping[str, Any]
    ) -> Tuple[Any, MutableMapping[str, Any]]:
        return (
            f"{self.extra['user_id']} | {self.extra['plbpy_version']} | {msg}",
            kwargs,
        )


def init_background_logger(params):
    logger = logging.getLogger("plbpy.interface")
    logger.setLevel(logging.DEBUG)
    target_handler = CustomHandler()  # Init MemoryHandler to store logs
    target_handler.setLevel(logging.DEBUG)
    log_format = logging.Formatter(
        "%(asctime)s | %(created)f | %(levelname)-8s | %(message)s"
    )
    target_handler.setFormatter(log_format)
    logger.addHandler(target_handler)
    adapter = LoggerAdapterCustom(logger, params)

    return adapter


class PLBHTTPHandler(HTTPHandler):
    def __init__(
        self,
        host: str,
        url: str,
        method: str,
        secure: bool,
        credentials: Tuple[str, str],
        proxy: Dict[str, str],
        context,
    ) -> None:
        super().__init__(
            host,
            url,
            method=method,
            secure=secure,
            credentials=credentials[1],
            context=context,
        )
        self.plbpy_credentials = credentials
        self.session = requests.Session()
        if proxy is not None:
            self.session.proxies = proxy

    def mapLogRecord(self, record: LogRecord) -> str:
        return super().format(record)

    # Map LogRecords to List[str]
    def mapLogRecords(self, records: List[LogRecord]) -> List[str]:
        return list(map(str, list(map(self.mapLogRecord, records))))

    # Custom emit function
    def emit(self, record: List[LogRecord]) -> None:
        try:
            data = {"logs": self.mapLogRecords(record)}
            self.session.request(
                self.method,
                f"https://{self.host}{self.url}",
                headers={
                    "Content-Type": "application/json",
                    "X-Api-Key": self.plbpy_credentials[0],
                    "Authorization": f"Bearer {self.plbpy_credentials[1]}",
                },
                json=data,
            )
        except Exception as e:
            console = init_console_logger()
            console.info("Problem in emitting logs")
            console.info(e, exc_info=e)

    # Custom Handler
    def handle(self, records: List[LogRecord]) -> None:
        rv = list(map(super().filter, records))
        logs = [records[i] for i, b in enumerate(rv) if b]
        if any(rv):
            self.acquire()
            try:
                self.emit(logs)
            finally:
                self.release()
        return rv


class TestHandler(FileHandler):
    def __init__(
        self, filename, mode: str, encoding: Optional[str], delay: bool
    ) -> None:
        super().__init__(filename, mode=mode, encoding=encoding, delay=delay)


def log_factory(logger_instance: Union[LoggerAdapter], level):
    def track(fn):
        @wraps(fn)
        def func(*a, **kw):
            logger_instance.log(
                level,
                "%s | %s | %s | (%s, %s)",
                fn.__module__,
                fn.__qualname__.split(".")[0],
                fn.__qualname__.split(".")[-1],
                a,
                kw,
            )
            return fn(*a, **kw)

        return func

    return track
