from __future__ import absolute_import

### Get Version ###
from ._version import get_versions

__version__ = get_versions()["version"]

del get_versions

### Console logger ###
from ._logger import init_console_logger  # noqa E402

console = init_console_logger()

del init_console_logger

### Disclaimer ###
cr = "\n"
s = "#####################################################################" + cr
s += f"#  PLBPY [{__version__}]" + cr
s += f"#  This software is distributed by Premialab HK. All rights reserved." + cr
s += f"#  For our Privacy Statement - https://premialab.com/privacy" + cr
s += f"#  For our Terms and Conditions - https://premialab.com/terms" + cr
s += f"#  For bug reports and comments - client-services@premialab.com" + cr
s += f"#####################################################################"

# console.info(s)

del s, cr

### Create Session from environment variables or getpass input ###
import getpass  # noqa E402
import os  # noqa E402
from dotenv import find_dotenv, load_dotenv  # noqa E402,E401

try:
    # raise Exception
    load_dotenv(find_dotenv(filename="plbpy.env", raise_error_if_not_found=True))
    api_key = os.getenv("APIKEY") or getpass.getpass(prompt="API Key\t:")
    api_secret = os.getenv("APISECRET") or getpass.getpass(prompt="Secret\t:")
    proxy_http = os.getenv("HTTP_PROXY")
    proxy_https = os.getenv("HTTPS_PROXY")
    debug = bool(os.getenv("PLBPY_DEBUG", False))
    ssl_verify = bool( int(os.getenv("SSL_VERIFY", True)) )
    if debug:
        console.info(
            {
                "api_key": api_key,
                "api_secret": api_secret,
                "proxy_http": proxy_http,
                "proxy_https": proxy_https,
                "debug": debug,
                "ssl_verify":ssl_verify
            }
        )

except Exception as e:  # noqa F841
    console.info("No plbpy.env file found")
    api_key = getpass.getpass(prompt="API Key\t:")
    api_secret = getpass.getpass(prompt="Secret\t:")
    proxy_http = getpass.getpass(prompt="HTTP Proxy\t:")
    proxy_https = getpass.getpass(prompt="HTTPS Proxy\t:")
    debug = bool(getpass.getpass(prompt="DEBUG\t:"))
    ssl_verify = bool(getpass.getpass(prompt="SSL_VERIFY\t:"))
    if debug:
        console.info(
            {
                "api_key": api_key,
                "api_secret": api_secret,
                "proxy_http": proxy_http,
                "proxy_https": proxy_https,
                "debug": debug,
                "ssl_verify":ssl_verify
            }
        )

del getpass, find_dotenv, load_dotenv

### Use Session inputs to create logger context adapter ###
from ._logger import (
    init_background_logger,
    log_factory,
    DEBUG,
    INFO,
    PLBHTTPHandler,
    Formatter,
)  # noqa E402

logger = init_background_logger({"user_id": api_key, "plbpy_version": __version__})

del init_background_logger

### Attempting to init session ###
from plbpy.interface.Session import Session  # noqa: E402

logger.debug("Starting Session")

if debug:
    console.info("Starting Session")

try:
    session = Session(api_key=api_key,
                      api_secret=api_secret,
                      api_endpoint='https://api.premialab.com/v2/',
                      ssl_verify=ssl_verify)
    session.initialize()

    ### Save Proxy Information for Log API ###
    proxies = None
    if proxy_http:
        os.environ['http_proxy'] = proxy_http
        session.kwargs['http_proxy'] = proxy_http
        proxies = {"http": proxy_http}

    if proxy_https:
        proxies = {"https": proxy_https}
        os.environ['https_proxy'] = proxy_https
        session.kwargs['https_proxy'] = proxy_https

    if proxy_http and proxy_https:
        proxies = {"http": proxy_http, "https": proxy_https}

    ### Setup HTTPHandler ###
    target_handler = PLBHTTPHandler(
        session.kwargs['api_endpoint'][8:-1],
        "/logs/python",
        "POST",
        True,
        (api_key, session.access_token),
        proxies,
        None,
    )
    target_handler.setLevel(DEBUG)
    log_format = Formatter("%(asctime)s | %(created)f | %(levelname)-8s | %(message)s")
    target_handler.setFormatter(log_format)

    ### Add Handler to Adapter ###
    logger.logger.handlers[0].setTarget(target_handler)

    del (
        Formatter,
        PLBHTTPHandler,
        target_handler,
        log_format,
        proxies,
        debug,
        ssl_verify,
        proxy_http,
        proxy_https,
        api_key,
        api_secret,
    )

    ### Get Universe ###
    from plbpy.interface.Universe import Universe  # noqa: E402
    universe = Universe(session=session)._populate_metrics()
    session.kwargs["universe"] = universe

except Exception as e:
    console.info(e, exc_info=e)

### Import Classes in Package ###
try:
    from plbpy.interface.Portfolio import Portfolio  # noqa: E402
    from plbpy.interface.Dispersion import Dispersion  # noqa: E402
    from plbpy.interface.HCluster import HCluster  # noqa: E402
    from plbpy.interface.MST import MST  # noqa: E402
    from plbpy.interface.PCA import PCA  # noqa: E402
    from plbpy.interface.Regression import Regression  # noqa: E402
    from plbpy.interface.Risk import Risk  # noqa: E402
    from plbpy.visualizer.Visualiser import Visualiser  # noqa: E402
    from plbpy.interface.MyLab import MyLab  # noqa: E402
except ModuleNotFoundError as import_error:
    logger.debug(import_error, exc_info=import_error)

except Exception as e:
    raise e
