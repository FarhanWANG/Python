import pandas as pd
import numpy as np
import empyrical
import scipy.stats as stats
import plbpy as plb

def _get_tracks(u, start, end):
    try:
        return u.tracks(start=start, end=end, direct=True)
    except Exception as e:
        pass

def extract_tracks(codes, start,end):
    import plbpy as plb
    from concurrent.futures import ThreadPoolExecutor
    import tqdm

    idx = [i for i in range(0, len(codes), 49)] + [len(codes)]

    with ThreadPoolExecutor(max_workers=1) as executor:
        params = [{
            'u': plb.universe.code(codes[i:idx[cnt + 1]]),
            'start': start,
            'end':end
        } for cnt, i in enumerate(idx[:-1])]

        result = list(tqdm.tqdm(executor.map(lambda x: _get_tracks(**x), params), total=len(idx)-1, desc=f'Extracting tracks for {len(codes)} tickers. Batch #'))

    return pd.concat(result, axis=1)

def quarterly_dates(returns):
    q = returns.resample('Q').asfreq()
    if q.index[-1] > returns.index[-1]:
        q = q.drop(q.index[-1])
    q_start = q.index.to_numpy().copy()
    for cnt,i in enumerate(q_start):
        q_start[cnt] = i + np.timedelta64(1,'D')

    q_end = q.index[1:].to_numpy().copy()
    dates = np.append(q_start.reshape(-1,1)[:-1], q_end.reshape(-1,1), axis=1)

    periods=[]
    for i,d in enumerate(dates):
        dates[i][0] = nearest(returns.index.to_numpy(), d[0])
        dates[i][1] = nearest(returns.index.to_numpy(), d[1])
        start = str(d[0])[:10]
        end = str(d[1])[:10]

        month_start = pd.DatetimeIndex([d[0]])[0].month
        year = pd.DatetimeIndex([d[1]])[0].year
        if month_start in [12,1]:
            name = f'Q1\'{str(year)[-2:]}'
        elif month_start in [3,4]:
            name = f'Q2\'{str(year)[-2:]}'
        elif month_start in [6,7]:
            name = f'Q3\'{str(year)[-2:]}'
        elif month_start in [9,10]:
            year = pd.DatetimeIndex([d[0]])[0].year
            name = f'Q4\'{str(year)[-2:]}'
        periods.append({'name':name,'start_date':start,'end_date':end})
    return np.array(periods), dates


def get_stress_periods(dates):
    periods=[]
    for i,d in enumerate(dates):
        start = str(d[0])[:10]
        end = str(d[1])[:10]
        name = '#{} [{} to {}]'.format(i+1, start,end)
        periods.append({'name':name,'start_date':start,'end_date':end})
        
    return np.array(periods)

def log_return(track: pd.DataFrame, pandas=False):
    result = np.diff(np.log(track), axis=0)
    if pandas:
        assert isinstance(track, pd.DataFrame), "Pandas output requires a pandas input"
        return np.log(track).diff().fillna(0.0)
    else:
        return result

def ratio_return(returns:np.ndarray, pandas=False):
    x = np.copy(returns)
    
    for i, ret in enumerate(x.T):
        x.T[i] = np.cumprod(np.e**ret)
        
    result=np.append([[1]*x.shape[1]], x, axis=0)*100
    if pandas:
        assert isinstance(returns, pd.DataFrame), "Pandas output requires a pandas input"
        return np.cumprod(np.e**returns)*100
    else:
        return result

def calculate_metrics(returns):

    metrics = pd.DataFrame(columns=['Return', 'Return Cumulated', 'Volatility','Skew','Kurtosis', 'Max Drawdown','Sharpe Ratio','Information Ratio','Calmar Ratio','Omega Ratio','Sortino Ratio' , 'VaR'], index=returns.columns.tolist())

    for ticker in metrics.index:
        daily = returns[ticker]

        metrics.at[ticker, 'Return'] = (np.mean(daily)*252)*100
        metrics.at[ticker, 'Volatility'] = (np.std(daily)*np.sqrt(252))*100
        metrics.at[ticker, 'Sharpe Ratio'] = empyrical.sharpe_ratio(daily)
        metrics.at[ticker, 'Information Ratio'] = (np.mean(daily)*252)/(np.std(daily)*np.sqrt(252))
        metrics.at[ticker, 'Max Drawdown'] = empyrical.max_drawdown(daily)
        metrics.at[ticker, 'VaR'] = ((stats.norm.ppf(
1-0.95, daily.mean(), daily.std()))*(-1))*100
        metrics.at[ticker, 'Return Cumulated'] = (daily.cumsum()[-1])*100
        metrics.at[ticker, 'Calmar Ratio'] = (np.mean(daily)*252)/(empyrical.max_drawdown(daily)*(-1))
        metrics.at[ticker, 'Sortino Ratio'] = (np.mean(daily)*252)/empyrical.downside_risk(daily)
        metrics.at[ticker, 'Omega Ratio'] = empyrical.omega_ratio(daily)
        metrics.at[ticker, 'Kurtosis'] = stats.kurtosis(daily)
        metrics.at[ticker, 'Skew'] = stats.skew(daily)

    return metrics


def nearest(items, pivot):
    return min(items, key=lambda x: abs(x - pivot))

def subset_returns(r, stress_dates,dates):
    if isinstance(r, pd.DataFrame):
        stress_returns = pd.DataFrame()
        for period in stress_dates:
            temp = r.reindex(pd.date_range(period[0], period[1], freq='B')).fillna(0)
            stress_returns = pd.concat((stress_returns, temp), axis=0)

    else:
        stress_returns = np.empty(shape=(0,))

        for period in stress_dates: # loop through each stress date
            nearest_start = nearest(dates, np.datetime64(period[0]))
            nearest_end = nearest(dates, np.datetime64(period[1]))

            start = np.where(dates == nearest_start)[0][0] #find index value that corresponds to the start and end dates of each period
            end= np.where(dates == nearest_end)[0][0] 
            stress_returns = np.append(stress_returns,r[start: end+1], axis=0) #subset returns

    return stress_returns


def calculate_benchmarked_info_ratio(benchmark_returns, pf_returns):
    df = pf_returns - benchmark_returns
    tracking_error = np.std(df)*np.sqrt(252)
    premium = (np.mean(pf_returns)*252) - (np.mean(benchmark_returns)*252)
    
    return premium/tracking_error

def mu(returns: pd.DataFrame) -> np.array:
    return (returns.mean() * 252).values

def sigma(returns: pd.DataFrame) -> np.array:
    return returns.cov().values

def p_mu(mu: np.array) -> float:
    return sum(mu)

def ret(w, mu):
    return sum(mu * w)

def vol(w, sigma):
    return np.sqrt(w.dot(sigma).dot(w.T)) * np.sqrt(252)


def calculate_stress_returns(returns:pd.DataFrame,stress_periods:np.ndarray, **kwargs)-> pd.DataFrame:
    stress_returns = pd.DataFrame()    
    for i in stress_periods:
        stress_returns = pd.concat(
            (stress_returns, returns.loc[i['start_date']:i['end_date']]))
        
    return stress_returns 


def efficient_frontier_weights(mu, cov, objective):
    from pypfopt import EfficientFrontier
    ef = EfficientFrontier(mu, cov)
    if objective == 'max sharpe':
        ef.max_sharpe()
    elif objective == 'min vol':
        ef.min_volatility()
        
    return dict(ef.clean_weights())


def rescale(w,target=0.2):
    vals = np.array(list(w.values()))
    return dict(map(lambda x: (x[0],(x[1]/vals.sum())*target) ,w.items()))


def create_portfolio(prices, weights):
    from plbpy.Research import Portfolio,GreedyOptimizer
    weights = [weights[i] for i in prices.columns.tolist()]
    return Portfolio(universe = prices, weights= weights)


def repeat_list(list1, list2):
    return np.array(list1 * len(list2)).reshape(len(list2), len(list1)).tolist()



    






