import plbpy as plb
s=plb.session
plb_universe = plb.universe

import pandas as pd
import numpy as np
from pypfopt import EfficientFrontier
import warnings
warnings.filterwarnings('ignore')
from plbpy.Research.Optimization.src.classes.portfolio import Portfolio
from plbpy.Research.Optimization.src.visualization.visualizer import Visualizer
from plbpy.Research.Optimization.src.classes.black_litterman import BlackLittermanMeucci
from plbpy.Research.Optimization.src.helpers import calculator as calc
from plbpy.Research.Optimization.src.visualization import viz_calculator as viz_calc
import matplotlib.pyplot as plt
import seaborn as sns
import math
from matplotlib.patches import FancyArrowPatch, Patch, Rectangle
from matplotlib.ticker import NullFormatter
from matplotlib.lines import Line2D
import tqdm
from pandas.tseries.offsets import BDay
import scipy.stats as stats
from scipy import optimize
# from adjustText import adjust_text
from dateutil.relativedelta import relativedelta
colors = ['#183C69','#993E5C','#1985A1','#F2893B','#996699','#3D7650',
          '#7C97C2','#967E9E','#F1CECD','#9CC5BF','#71B080','#60ACA7',
          '#8279CE','#DBA0B3','#CFC6DD','#B9AEE1','#4B4B4B','#8B8B8B',
          '#CB4154']

def log_return(track: pd.DataFrame, pandas=False):
    result = np.diff(np.log(track), axis=0)
    if pandas:
        assert isinstance(track, pd.DataFrame), "Pandas output requires a pandas input"
        return pd.DataFrame(data = result.reshape(-1,len(track.columns)), index=track.index[1:], columns = track.columns)
    else:
        return result

def metrics_comparison(er,es,prior_return, prior_covariance, pf):
    pri_ret = (prior_return['Prior'].loc[pf.tickers]*100).values.tolist()
    pos_ret = er.loc[pf.tickers]['Expected Returns'].values.tolist()
    his_ret = pf.constituents_metrics()['Return'].loc[pf.tickers].values.tolist()
    pri_vol = np.sqrt(np.diag(prior_covariance.iloc[0:len(pf.tickers),0:len(pf.tickers)]))*100
    pos_vol = np.sqrt(np.diag(es.iloc[0:len(pf.tickers),0:len(pf.tickers)]))*100
    his_vol = pf.constituents_metrics()['Volatility'].values

    cols = [['Returns']*3 + ['Volatility']*3 + ['Information Ratio']*3,
            ['Prior','Historical','Expected']*3]

    mets = pd.DataFrame(index = pf.tickers, columns = cols)

    mets[('Returns', 'Prior')] = pri_ret
    mets[('Returns', 'Historical')] = his_ret
    mets[('Returns', 'Expected')] = pos_ret

    mets[('Volatility', 'Prior')] = pri_vol
    mets[('Volatility', 'Historical')] = his_vol
    mets[('Volatility', 'Expected')] = pos_vol

    mets[('Information Ratio', 'Prior')] = pri_ret/pri_vol.reshape(-1,1)
    mets[('Information Ratio', 'Historical')] = his_ret/his_vol.reshape(-1,1)
    mets[('Information Ratio', 'Expected')] = pos_ret/pos_vol.reshape(-1,1)

    # return mets
    return round(mets.T.astype(float),2)
    # return mets.T


def return_v_volatility(er,es,prior_return, prior_covariance, pf, **kwargs):
    plt.style.use('default')
    pri_ret = pf.constituents_metrics()[['Return']]/100
    pos_ret = er[0:len(pf.tickers)]/100

    pri_cov = pf.constituents_returns().cov()*252
    pos_cov = es.iloc[0:len(pf.tickers), 0:len(pf.tickers)]

    texts = []
    fig, ax = plt.subplots(figsize= kwargs.pop('figsize',(5,5)))
    for i,strat in enumerate(pf.tickers):
        x1 = pri_ret.loc[strat,'Return']
        y1 = np.sqrt(pri_cov.loc[strat,strat])
        x2 = pos_ret.loc[strat,'Expected Returns']
        y2 = np.sqrt(pos_cov.loc[strat,strat])
        
        if i == 0:
            ax.scatter(x1, y1, color='lightgray', zorder=2.5, label='Historical')
        else:

            ax.scatter(x1, y1, color='lightgray', zorder=2.5)
        ax.scatter(x2, y2, color=colors[i], zorder=2.5,label=strat)
        
        arrow = FancyArrowPatch(posB = (x2,y2),
                                        posA = (x1,y1),
                                        arrowstyle='->', color=colors[i],mutation_scale=20,  alpha=0.6, shrinkB=3)
        
        # texts.append(plt.text(x2,y2, strat,  color=colors[i]))
        ax.add_patch(arrow)
        
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    xticks = ax.get_xticks()
    xticks = [f'{round((x*100),2)}%' for x in xticks]
    ax.set_xticklabels(xticks, fontsize=8)

    yticks = ax.get_yticks()
    yticks = [f'{round(float(x*100),2)}%' for x in yticks]
    ax.set_yticklabels(yticks, fontsize=8)

    ax.axvline(x=0, color='lightgray', linestyle='--', alpha=0.4)
    ax.grid(True, alpha=0.2, color='lightgray')
    ax.set_ylabel('$Volatility$', fontsize=8)
    ax.set_xlabel('$Return$', fontsize=8)
    fig.suptitle('Return vs Volatility: Historical to Expected', weight='bold', fontsize=10)
    adjust_text(texts) 
    plt.legend(loc='center right', bbox_to_anchor=(1.9, 0.5),  frameon=False, ncol=1, fontsize=8)
    plt.show()


def correlation_from_covariance(covariance):
    v = np.sqrt(np.diag(covariance))
    outer_v = np.outer(v, v)
    correlation = covariance / outer_v
    correlation[covariance == 0] = 0
    return correlation


def correlation_matrix(es, prior_covariance):

    mask = np.diag(np.ones(correlation_from_covariance(prior_covariance).shape[1]))
    vmax = 1
    vmin = -1
    fig, ax = plt.subplots(figsize=(12,6), ncols=2, nrows = 1)
    cm = sns.diverging_palette(220,10, n=49, as_cmap=True)

    sns.heatmap(correlation_from_covariance(prior_covariance), 
                xticklabels=prior_covariance.columns, yticklabels=prior_covariance.columns,
                cmap=cm,center=0,ax=ax[0], vmax=vmax, vmin=vmin, annot=True,annot_kws={"fontsize":8,"rotation":45},
            mask = mask)

    ax[0].set_title('Historical',)

    sns.heatmap(correlation_from_covariance(es), 
                xticklabels=es.columns, yticklabels=0,
                cmap=cm,center=0,ax=ax[1], vmax=vmax, vmin=vmin, annot=True,annot_kws={"fontsize":8,"rotation":45},
            mask=mask)

    ax[1].set_title('Expected', )
    fig.suptitle('Correlation Matrix',weight = 'bold')
    fig.show()


def get_EF_weights(pf, er,es, bounds, **kwargs):
    ef = EfficientFrontier(er['Expected Returns'].iloc[0:len(pf.tickers)]/100, es.iloc[0:len(pf.tickers),0:len(pf.tickers)], bounds)
    obj = kwargs.pop('objective','min vol')
    
    if obj=='min vol':
        
        bl_weights = ef.min_volatility()
    else:
        bl_weights = ef.max_sharpe()
    if kwargs.pop('return_obj', False):
        return bl_weights
    else:
        return list(bl_weights.values())

def efficient_frontier(mu, sigma, w, pf, **kwargs):
    rtn = []
    vols = []
    pure_factors = kwargs.pop('pure_factors', False)
    min_bound = 0 if pure_factors else 0.05

    for i in range(1000):
        while True:
            w_star = np.random.rand(len(pf))
            w_star /= sum(w_star)
            if all(lambda x : x >= 0.05 for x in w_star):
                break
        
        rtn.append(ret(w_star, mu))
        vols.append(vol(w_star, sigma))


    bounds = tuple((min_bound, 1) for x in pf)
    r_bound = np.linspace(min(rtn), max(rtn), 100)
    risk = []

    for i in r_bound:
        constraints = [{'type': 'eq', 'fun': lambda x: sum(x) - 1},
                        {'type': 'eq', 'fun': lambda x: ret(x, mu) - i}]
        outcome = optimize.minimize(lambda x: vol(x, sigma),x0=w_star, constraints=constraints, bounds=bounds)  
        risk.append(outcome.fun) 
        
    return rtn, vols, risk, r_bound

def ret(w, mu):
    return np.sum(mu * w)

def vol(w, sigma):
    return np.sqrt(w.dot(sigma).dot(w.T))

# def get_ef_values(pf_pos,er,es,pf_pri, pf, views):

def draw_efficient_frontier(pf_pos,er,es,pf_pri, pf, views, **kwargs):
#     exposed_factors = pf.exposure().index.tolist()+['SXXR','SPX']
#     r = pd.read_pickle('data/raw/bench_track.pickle').join(pd.read_pickle('data/raw/pf_tracks.pickle')).fillna(method='ffill', limit=20).dropna()
#     exposed_factor_track = r[exposed_factors].reindex(pf.returns().index).fillna(method='ffill', limit=20).dropna()
#     factor_pf = Portfolio(universe = exposed_factor_track)


    mu_BL = er['Expected Returns'].iloc[0:len(pf.tickers)]/100
    sigma_BL = es.iloc[0:len(pf.tickers),0:len(pf.tickers)]
    bl_map = kwargs.pop('bl_map', None)
    if bl_map is None:
        w_BL = pf_pos.constituents_data()['weight'].values
    else:
        w_BL = np.array([bl_map[i] for i in pf.tickers])

#     pf_blm = BlackLittermanMeucci(portfolio = factor_pf, views = views)
#     mu_F, sigma_F = pf_blm.compute_expected()
#     mu_F = mu_F['Expected Returns'].iloc[0:len(factor_pf.tickers)]/100
#     sigma_F = sigma_F.iloc[0:len(factor_pf.tickers), 0:len(factor_pf.tickers)]

#     w_F = np.ones(len(factor_pf.tickers))/len(factor_pf.tickers)

    BL_rtn, BL_vols, BL_risk, BL_bound = efficient_frontier(mu_BL, sigma_BL, w_BL, pf.tickers)
    
#     F_rtn, F_vols, F_risk, F_bound = efficient_frontier(mu_F, sigma_F, w_F, factor_pf.tickers.tolist(), pure_factors = True)

    fig, ax = plt.subplots(figsize=(15,5))
    ax.plot(BL_vols, BL_rtn, color='lightgrey',marker='.',  alpha=0.01)
    ax.plot(BL_risk, BL_bound, 'darkred')

#     ax.plot(F_vols, F_rtn, color='lightgrey',marker='.',  alpha=0.01)
#     ax.plot(F_risk, F_bound, 'darkgreen')

    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    ax.set_ylabel('$Expected$ $Returns$')
    ax.set_xlabel('$Expected$ $Volatility$')
    # ax.grid(axis='x', alpha=0.4, color='lightgray')
    # ax.axhline(y=0, linestyle='--', linewidth=0.7, color='gray', alpha=0.6)
    fig.suptitle('Efficient Frontier', weight='bold')


    new_ret = ret(w_BL, mu_BL)
    new_vol = vol(w_BL, sigma_BL)
    ax.scatter(new_vol,new_ret,marker='x', color='orange', s=110, zorder=3.5, label='Optimized Portfolio (BLM)')

    old_ret = pf_pri.metrics()['Return'][0]/100
    old_vol = pf_pri.metrics()['Volatility'][0]/100
    ax.scatter(old_vol,old_ret,marker='x', color='k', s=90, zorder=2.5, alpha=0.8, label='Original Portfolio')

    m = (np.mean(pf.constituents_returns())*252)
    s = pf.constituents_returns().cov()*252
    ef = EfficientFrontier(m, s, (0.05,1))
    mv_weights = np.array(list(ef.min_volatility().values()))
    y,x = ret(mv_weights, m), vol(mv_weights, s)
    ax.scatter(x,y,marker='x', color='blue', s=90, zorder=2.5, alpha=0.8, label='Optimized Portfolio (Mean-Variance)')

#     vols = (np.diag(sigma_F)**0.5).tolist()
#     texts = []

#     for i,f in enumerate(mu_F.index):
#         x=vols[i]
#         y=mu_F.loc[f]
#         ax.scatter(x, y, color='darkgreen', marker='o', s=30, alpha=0.8)
#         texts.append(plt.text(x,y,f, color='darkgreen'))
    #     ax.annotate(f, (x+0.0005,y-0.002), color='darkgreen')
        

    
        
    # rets, vols = BlackLittermanMeucci(pf.constituents_returns(), views)
    # rets = rets['Expected Returns'].iloc[0:len(pf.tickers)]/100
    # vols = vols.iloc[0:len(pf.tickers), 0:len(pf.tickers)]
    vols = (np.diag(sigma_BL)**0.5).tolist()
    texts = []
    for i,f in enumerate(mu_BL.index):
        x=vols[i]
        y=mu_BL.loc[f]
        ax.scatter(x, y, color='darkred', marker='o', s=30, alpha=0.8)
        texts.append(plt.text(x,y,f, color='darkred'))
    #     ax.annotate(f, (x,y+0.003), color='darkred')

    xticks = ax.get_xticks()
    xticks = [f'{round(x*100)}%' for x in xticks]
    ax.set_xticklabels(xticks)

    yticks = ax.get_yticks()
    yticks = [f'{round(float(y*100),3)}%' for y in yticks]
    ax.set_yticklabels(yticks)

    adjust_text(texts)    
    plt.legend(loc='upper right', bbox_to_anchor=(1.25, 0.5), fontsize=10, frameon=False)
    if kwargs.pop('return_fig', False):
        return fig, ax
    # plt.savefig('Efficient Frontier.svg')
    else:    
        plt.show()


def compare_strategy_weights(w):
    fig, ax = plt.subplots(figsize=(10,4))
    ax = w.T.plot(kind='bar', color=colors, ax=ax, zorder=2.5)


    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.set_xlabel('')
    yticks = ax.get_yticks()
    for i in yticks:
        ax.axhline(y=i, color='lightgray', alpha=0.6, linestyle='--', linewidth=0.5)

    yticks = [f'{round(float(y))}%' for y in yticks]
    ax.set_yticklabels(yticks)

    ax.set_xlabel('')

    # xticks = ax.get_xticklabels()
    # ax.set_xticklabels(xticks, rotation=)
        
    fig.suptitle('Asset Allocation', weight='bold', fontsize=10)
    plt.legend(loc='center right', frameon=False, ncol=1, fontsize=8, bbox_to_anchor = (1.15,0.5))
    # ax.set_xlim(0,100)
    plt.show()

def expected_track(pf_pos, pf, er,es, **kwargs):
    weight = pf_pos.strategy_weights.iloc[[-1]].values[0]
    r = er[0:len(pf.tickers)].values.flatten()
    v = es.iloc[0:len(pf.tickers), 0:len(pf.tickers)].values

    mu = ret(weight, r)
    sigma = vol(weight, v)*100


    S_n = pf_pos.track().values[-1]
    N = 252
    dt = 1/N
    CI_68 = []
    CI_95 = []

    out = []
    S_n_i = S_n
    for i in range(N):
        C_68_positive = S_n_i + sigma*((i*dt)**0.5)
        C_68_negative = S_n_i - sigma*((i*dt)**0.5)
        
        C_95_positive = S_n_i + 2*sigma*((i*dt)**0.5)
        C_95_negative = S_n_i - 2*sigma*((i*dt)**0.5)
        
        S_n_i = S_n_i + mu*dt
        out.append(np.hstack([S_n_i, C_68_positive, C_68_negative, C_95_positive, C_95_negative]))

    expected=pd.DataFrame((np.array(out)), columns = ['Mean','+1SD','-1SD', '+2SD','-2SD'], index = [pf_pos.track().index[-1]+BDay(i+1) for i in range(252)])
    df = pf_pos.track().append(expected)
    if kwargs.pop('cut',True):
        df = df.iloc[504:]
    
    
#-----------------------------
    
    fig, ax = plt.subplots(figsize=kwargs.pop('figsize', (16,5)))
    df[['portfolio_track']].plot(ax=ax, color=colors[0], zorder=2.5)
    df[['Mean']].plot(ax=ax, color=colors[0], zorder=2.5)
    df[['+1SD','-1SD']].plot(ax=ax, color=colors[1], zorder=2.5, linestyle='dotted')
    df[['+2SD','-2SD']].plot(ax=ax, color='k', zorder=2.5, linestyle='dotted')

    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.axvline(x = pf_pos.track().index[-1], linestyle='--', color='darkgray', alpha=0.5)
    # ax.grid(False, color='lightgray',alpha=0.3)
    plt.title('Optimized Portfolio Historical and Expected Track', weight='bold')
    maximum = np.max(df['+2SD'])

    last_day = pf.returns().index[-1]
    last_exp_day = df.index[-1]

    last_day_index = np.where(df.index == last_day)[0][0]
    last_exp_day_index = np.where(df.index == last_exp_day)[0][0]

    ax.annotate('$Expected$', (last_day+relativedelta(months=+5),maximum), color='grey', va='bottom')
    ax.annotate('', xy=(last_day, maximum+0.25),xytext=(last_day+relativedelta(months=+5),maximum+0.25),
                arrowprops=dict(arrowstyle="|-|",connectionstyle="arc3", color='dimgrey', alpha=0.5),
                color='dimgrey')
    ax.annotate('', xy=(last_day+relativedelta(days=+(7*31)+12),maximum+0.25),xytext=(last_exp_day,maximum+0.25),
                arrowprops=dict(arrowstyle="|-|",connectionstyle="arc3", color='dimgrey', alpha=0.5),
                color='dimgrey')
    

    ax.annotate(int(df.loc[last_exp_day, 'Mean']), (df.index[-1], df.loc[last_exp_day, 'Mean']), color=colors[0], fontsize=8)
    ax.annotate(int(df.loc[last_exp_day, '+2SD']), (df.index[-1], df.loc[last_exp_day, '+2SD']), color='k', fontsize=8)
    ax.annotate(int(df.loc[last_exp_day, '-2SD']), (df.index[-1], df.loc[last_exp_day, '-2SD']), color='k', fontsize=8)
    ax.annotate(int(df.loc[last_exp_day, '+1SD']), (df.index[-1], df.loc[last_exp_day, '+1SD']), color=colors[1], fontsize=8)
    ax.annotate(int(df.loc[last_exp_day, '-1SD']), (df.index[-1], df.loc[last_exp_day, '-1SD']), color=colors[1], fontsize=8)

    last_price = df.loc[last_day, 'portfolio_track']
    ax.annotate(int(last_price), xy = (last_day, last_price), xytext = (last_day+relativedelta(days=+15), last_price/1.05 ),color=colors[0],
     arrowprops=dict(arrowstyle="-|>",connectionstyle="arc3", color=colors[0], alpha=0.5))

    # ax.set_yticks([])
    

    ax.fill_between(x=df.index[last_day_index:last_exp_day_index], y1=df['+1SD'].dropna().values, y2=df['-1SD'].dropna().values, color=colors[0], alpha=0.3, zorder=2)
    ax.fill_between(x=df.index[last_day_index:last_exp_day_index], y1=df['+2SD'].dropna().values, y2=df['-2SD'].dropna().values, color=colors[0], alpha=0.15, zorder=2)
    plt.legend(['Historical','Expected Mean','+1SD','-1SD','+2SD','-2SD'],loc='upper center', bbox_to_anchor=(0.5, -0.14), ncol=7, frameon=False)
    if kwargs.pop('return_fig', False):
        return fig, ax
    else:
        plt.show()


def backtest_track(pf_pos,pf_pri):
    fig, ax = plt.subplots(figsize=(16,4))
    pf_pri.track().plot(ax=ax, color=colors[1], label='Original', zorder=2.5)
    pf_pos.track().plot(ax=ax, color=colors[0], label='Optimized', zorder=3.5)
    ax.set_title('Optimized Portfolio vs Original Portfolio Track', weight= 'bold')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.grid(True, color='lightgray', alpha=0.3)

    plt.legend(['Original','Optimized'],loc='upper center', bbox_to_anchor=(0.5, -0.14), frameon=False, ncol=4)
    ax.set_yscale('log')
    ax.set_ylabel('Log Scale')
    plt.ion()
    ax.yaxis.set_major_formatter(NullFormatter())
    ax.yaxis.set_minor_formatter(NullFormatter())
   
    plt.show()

