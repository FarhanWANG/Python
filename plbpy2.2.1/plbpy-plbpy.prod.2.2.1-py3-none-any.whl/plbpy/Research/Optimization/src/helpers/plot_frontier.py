import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
from scipy import stats, interpolate, linalg
import matplotlib.pyplot as plt
from math import ceil
import cvxpy as cp
import scipy.interpolate
import plbpy as plb
import plotly.subplots as sp

colors = [
            "#183C69",
            "#993E5C",
            "#1985A1",
            "#F2893B",
            "#996699",
            "#3D7650",
            "#7C97C2",
            "#967E9E",
            "#F1CECD",
            "#9CC5BF",
            "#71B080",
            "#60ACA7",
            "#8279CE",
            "#DBA0B3",
            "#CFC6DD",
            "#B9AEE1",
            "#4B4B4B",
            "#8B8B8B",
            "#CB4154",
        ]


def cov2cor(V):
    """
    Convert a covariance matrix into a correlation matrix:
    """
    x = 1 / np.diag(V)
    x = np.maximum(x, 0)
    x = np.sqrt(x)
    V = ((V * x).T * x ).T
    V = np.clip(V, -1, 1)
    return V



def stackplot(
    x, y = None,
    N      = 11,
    ax     = None,
    legend = False,
    labels = [],
    loc    = 'best',
    colors = plt.get_cmap("tab10").colors,
    plot = True,
    **kwargs
):
    """
    Stacked area plot, allowing for negative values.
    Inputs: x, y: data to plot
            N: Number of interpolation points (we need to add more points to account for sign changes)
            ax: where to put the plot
            legend: boolean, whether to add a legend
            labels: labels for the legend, if they cannot be inferred from the data
            loc: position of the legend, e.g., 'best' or (1.04,0) (give an incorrect string to see the accepted values)
            colors
            ...: passed to ax.stackplot()
    Output: None
    """
    ## To smooth out the sign changes, add intermediate points
    ## (There is only a problem when the sign of one of the time series changes, 
    ## and it can be fixed by adding the point (x-value) where the sign changes, 
    ## i.e., when the value becomes zero. It is easier (and also more scalable, 
    ## if there are hundreds of time series) to add more intermediate points: 
    ## if they are sufficiently dense, everything will look fine.)
    
    if y is None: 
        y = x.values
        if len(labels) == 0:
            labels = x.index
        x = x.columns
    else:
        assert len(x) == y.shape[1], f"Inconsistent shapes: len(x) is {len(x)}, y.shape is {y.shape}"
    
    if isinstance(y, pd.DataFrame): 
        if len(labels) == 0:
            labels = y.index
        y = y.values
    if isinstance(x, pd.Series):
        x = x.values

    assert not isinstance(x[0], str), f"The x-axis should be numeric (dates are fine, as well), got an array of {type(x[0])}: {x}"
    
    date_axis = isinstance(x[0], pd.Timestamp)
    if date_axis:
        x = matplotlib.dates.date2num(x)
        x = 1.0 * x
        
    xs = np.stack( [ x[:-1], x[1:] ] )
    xs = np.apply_along_axis( lambda u: np.linspace(u[0],u[1],N+1)[:N], 0, xs ).T.flatten()
    ys = []
    for i in range(y.shape[0]): 
        ys.append( scipy.interpolate.interp1d(x,y[i,:])(xs) )
    ys = np.array(ys)
    
    ## Plot separately the positive and negative values
    y_pos = np.where( ys >= 0, ys, 0 )
    y_neg = np.where( ys <= 0, ys, 0 )
    
    ## Plot
    if plot:
      ax_was_None = ax is None
      if ax_was_None: 
          fig, ax = plt.subplots()
      ax.stackplot(xs, y_pos, labels = labels, colors = colors, **kwargs)
      ax.stackplot(xs, y_neg, labels = [],     colors = colors, **kwargs)
      ax.set_xlim( min(x), max(x) )
      if date_axis:
          dx = max(x) - min(x)
          if dx > 7000:
              axis_decade(ax)
          elif dx > 3500:
              axis_year(ax, '%y')
          elif dx > 600:
              axis_year(ax)
          else:
              axis_month(ax)
      if legend:
          handles, labels = ax.get_legend_handles_labels()
          ax.legend(handles[::-1], labels[::-1], loc=loc )
      if ax_was_None: 
          plt.show()
    else:
      return xs, y_pos, y_neg, labels

def log_transform(raw, window = 1, dropna=True):
    logged = np.log(raw) - np.log(raw.shift(window))
    
    if dropna:
        logged.dropna(axis=0, how='any', inplace=True)

    return logged


def portfolio_optimal(V, mu, lambda_ = 1, short = False):
    assert lambda_ > 0
    assert isinstance(V, pd.DataFrame) or isinstance(V, np.ndarray)
    assert isinstance(mu, pd.Series) or isinstance(mu, np.ndarray)
    assert len(V.shape) == 2
    assert V.shape[0] == V.shape[1], f"The variance matrix should be square: it is {V.shape}"
    assert V.shape[0] == len(mu), f"The variance matrix has {V.shape[0]} assets, but the returns have {len(mu)}"
    if isinstance(V, pd.DataFrame):
        assert np.all( V.index == V.columns ), "The rows and columns of the variance matrix do not match"
    if isinstance(mu, pd.Series):
        assert np.all( V.index == mu.index ), "The assets in the variance matrix and the expected return vector do not match"
        
    n = V.shape[0]
    w = cp.Variable(n)
    objective = w.T @ mu - .5 * lambda_ * cp.quad_form(w,V) 
    if short: 
        constraints = [ cp.sum(w) == 1 ]
    else:
        constraints = [ cp.sum(w) == 1, w >= 0 ]
    prob = cp.Problem( cp.Maximize(objective), constraints )
    prob.solve()
    w = w.value
    if w is None: 
        raise Exception(f"Optimization failed: {prob.status}")
    if not short: 
        w = np.maximum(w, 0)
    if isinstance(V,pd.DataFrame):
        w = pd.Series(w, index = V.index)
    return w

def FrontierPlot(codes, start_date, end_date, **kwargs):
    """
    
    
    
    
    """
    universe = plb.universe
    universe = universe.code(codes)
    assets = universe.tracks().to_frame().fillna(method = 'ffill').dropna()
    assets = assets.loc[str(start_date):str(end_date)]
    WINDOW = 1
    returns = log_transform(assets, window = WINDOW)
    V = returns.cov() * (252/WINDOW)
    mu = returns.mean() * (252/WINDOW)
    
    short = False
    ws = {}
    lambda_min = .001
    lambda_max = 1000
    epsilon = .01
    
    def f(lambda_):
        return portfolio_optimal(V, mu, lambda_, short = short)
    
    ws[ lambda_min ] = f( lambda_min )
    ws[ lambda_max ] = f( lambda_max )
    
    def fill(ws, l1, l2):
        if np.abs( ws[l1] - ws[l2] ).sum() < epsilon:
            return
        l = ( l1 + l2 ) / 2
        ws[l] = f(l)
        fill(ws,l1,l)
        fill(ws,l,l2)
    
    fill(ws, lambda_min, lambda_max)
    ws = pd.DataFrame(ws).T.sort_index().T
    
    if isinstance(mu, pd.Series):
        ws.index  = mu.index
    
    mus = ws.T @ mu
    sigmas = np.einsum('ik,ij,jk->k', ws, V, ws)
    sigmas = pd.Series( np.sqrt(sigmas), index = ws.columns )

    data = pd.DataFrame(data = [mus.values, sigmas.values])
    data = data.T
    data.columns = ['Returns', 'Volatility']
    
    data.index = mus.index
    data = data.join(ws.T)
    
    xs, y_pos, y_neg, labels = stackplot(sigmas, ws, legend=True, plot = False)
    ws1 = pd.DataFrame(y_pos.T)
    ws1.columns = labels
    stack_data = ws1.melt()
    stack_data.columns = ['ticker', 'weight']
    xs_1 = [xs]*len(codes)
    stack_data['Volatility'] = np.concatenate(xs_1, axis = 0)
    
    ### Creating ERC Portfolio
    # portfolio = plb.Portfolio(universe=universe)
    # portfolio = portfolio.set_return_interval('Weekly').set_start(str(start_date)).set_end(str(end_date))
    # portfolio = portfolio.set_erc('3M', 'Weekly', '1M')
    # portfolio.run_backtest()
    # erc_weights = portfolio.result.weights.iloc[-1, 0:-2]

    erc_weights = kwargs.pop('erc')
    erc_data = mu.to_frame(name='returns').join(erc_weights.to_frame(name='weights'))

    erc_portfolio_ret = (erc_data.returns*erc_data.weights).sum()
    erc_portfolio_var = np.dot(erc_data.weights.T, np.dot(V, erc_data.weights))
    erc_w = erc_weights.to_dict()
    erc_text = "<br>".join([x[0]+": "+str(x[1]) for x in erc_w.items()])
    
    ### Creating RP Portfolio
    # portfolio2 = plb.Portfolio(universe=universe)
    # portfolio2 = portfolio2.set_return_interval('Weekly').set_start(str(start_date)).set_end(str(end_date))
    # portfolio2 = portfolio2.set_risk_parity('3M', 'Daily', '1M')
    # portfolio2.run_backtest()
    # rp_weights = portfolio2.result.weights.iloc[-1, 0:-2]

    rp_weights = kwargs.pop('rp')
    rp_data = mu.to_frame(name='returns').join(rp_weights.to_frame(name='weights'))
    rp_portfolio_ret = (rp_data.returns*rp_data.weights).sum()
    rp_portfolio_var = np.dot(rp_data.weights.T, np.dot(V, rp_data.weights))
    rp_w = rp_weights.to_dict()
    rp_text = "<br>".join([x[0]+": "+str(x[1]) for x in rp_w.items()])

    ### Creating EQ Portfolio
    # portfolio3 = plb.Portfolio(universe=universe)
    # portfolio3 = portfolio3.set_return_interval('Weekly').set_start(str(start_date)).set_end(str(end_date))
    # portfolio3 = portfolio3.set_equal_weight().set_rebalance_dates("1M")
    # portfolio3.run_backtest()
    # # eq_weights = portfolio3.result.weights.iloc[-1, 0:-2]

    eq_weights = kwargs.pop('eq')
    eq_data = mu.to_frame(name='returns').join(eq_weights.to_frame(name='weights'))
    eq_portfolio_ret = (eq_data.returns*eq_data.weights).sum()
    eq_portfolio_var = np.dot(eq_data.weights.T, np.dot(V, eq_data.weights))
    eq_w = eq_weights.to_dict()
    eq_text = "<br>".join([x[0]+": "+str(x[1]) for x in eq_w.items()])
    
    data = data * 100
    data.reset_index(inplace = True, drop = True)
    
    sr = data['Returns']/data['Volatility']
    max_sr_idx = sr.argmax()

    min_var_x = data.Volatility.min() 
    min_var_y = data.Returns[data.Volatility.idxmin()]
    min_w = data.iloc[data.Volatility.idxmin(), 2:].to_dict()
    min_text = "<br>".join([x[0]+": "+str(x[1]) for x in min_w.items()])

    sr_x = data.iloc[max_sr_idx].Volatility
    sr_y = data.iloc[max_sr_idx].Returns
    sr_w = data.iloc[max_sr_idx, 2:].to_dict()
    sr_text = "<br>".join([x[0]+": "+str(x[1]) for x in sr_w.items()])
    


    ##plotting frontier
    
    fig = px.line(data_frame=data, x = 'Volatility', y = 'Returns', hover_data=data.columns)

    fig.add_trace(
      go.Scatter(x = [min_var_x],
                 y = [min_var_y],
                 text = 'Min Variance<br>'+min_text,
                 mode = 'markers',
                 name = "Min Variance",
                 marker_size=15,
                 marker_color=colors[4]
      ))  

    fig.add_trace(
      go.Scatter(x = [sr_x],
                 y = [sr_y],
                 text = 'Tangency Portfolio<br>'+sr_text,
                 mode = 'markers',
                 name = "Max Sharpe (Tangency Portfolio)",
                 marker_size=15,
                 marker_color=colors[3]
      ))  

    # fig.add_trace(
    #   go.Scatter(x = np.sqrt(np.diag(V))*100,
    #              y = mu*100,
    #              text = list(V.columns),
    #              mode = 'markers',
    #              opacity=0.3,
    #              name = "Constituents")
    #   )

    fig.add_trace(
      go.Scatter(x = [np.sqrt(eq_portfolio_var)*100],
                 y = [eq_portfolio_ret*100],
                 text = 'EQ Weight Portfolio<br>'+eq_text,
                 mode = 'markers',
                 name = "Equal Weight",
                   marker_size=15,
                   marker_color=colors[0]
                 #hovertextsrc=eqw
                ))


    fig.add_trace(
      go.Scatter(x = [np.sqrt(erc_portfolio_var)*100],
                 y = [erc_portfolio_ret*100],
                 text = 'ERC Weight Portfolio<br>'+erc_text,
                 mode = 'markers',
                 name = "ERC",
                   marker_size=15,
                   marker_color=colors[1]
                   
                ))

    fig.add_trace(
      go.Scatter(x = [np.sqrt(rp_portfolio_var)*100],
                 y = [rp_portfolio_ret*100],
                 text = 'Risk Parity Portfolio<br>'+rp_text,
                 mode = 'markers',
                 name = "Risk Parity",
                 marker_color=colors[2],
                 marker_size=15
                ))

    fig.update_layout(title = "Efficient Frontier", xaxis_title="Volatility",
        yaxis_title="Returns",showlegend=True)

    fig.data[0].name = "Frontier"
    
    
    
    #plotting stackplot
    stack_data.iloc[:,1:] = stack_data.iloc[:,1:]*100
    fig_stack = px.area(data_frame=stack_data, x = "Volatility",
                        y = "weight", color="ticker", 
                        color_discrete_sequence=colors
                        )
    fig_stack.update_xaxes(range=[stack_data.Volatility.min(),stack_data.Volatility.max()])
    fig_stack.update_yaxes(range=[0, 100])
    
    this_figure = sp.make_subplots(rows=2, cols=1, shared_xaxes=True)
    figure1_traces = []
    figure2_traces = []
    for trace in range(len(fig["data"])):
        figure1_traces.append(fig["data"][trace])
    for trace in range(len(fig_stack["data"])):
        figure2_traces.append(fig_stack["data"][trace])
    for traces in figure1_traces:
        this_figure.append_trace(traces, row=1, col=1)
    for traces in figure2_traces:
        this_figure.append_trace(traces, row=2, col=1)

    this_figure.update_layout(height=800, width=800, title_text="Efficient Frontier",  paper_bgcolor='white', legend=dict(
    orientation="h",
    yanchor="bottom",
    y=0.43,
    xanchor="right",
    x=1
    ))
    this_figure.update_xaxes(title_text="Volatility (in %)", row = 2)
    this_figure.update_yaxes(title_text="Return (in %)", row = 1)
    this_figure.update_yaxes(title_text="Weight (in %)", row = 2)
    this_figure.update_xaxes(range=[stack_data.Volatility.min()-1,stack_data.Volatility.max()])
    this_figure.update_xaxes(showspikes = True)

    return this_figure
    
    