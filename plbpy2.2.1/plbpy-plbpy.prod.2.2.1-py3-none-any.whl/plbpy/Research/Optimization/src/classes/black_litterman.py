from typing import Union, List, Optional

import plbpy as plb
s=plb.session
plb_universe = plb.universe

import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')

from plbpy.Research.Optimization.src.classes.portfolio import Portfolio as Portfolio


class BlackLittermanMeucci:

    def __init__(self,
                portfolio: Union[Portfolio, pd.DataFrame],
                views,
                weights: Union[np.ndarray, list] = None,
                 **kwargs
                ):
        
        if isinstance(portfolio,pd.DataFrame):
            self.historical_returns = portfolio
            self.weights = np.ones(portfolio.shape[1])/portfolio.shape[1]
        else:
            self.historical_returns = portfolio.constituents_returns()
            self.weights = portfolio.strategy_weights.iloc[-1].values

        market_views = {}
        for i,v in enumerate(views):
            market_views[i] = v

        self.views = market_views
        self.prior_returns = None
        self.prior_covariance = None

        self.annualization_factor = kwargs.pop('annualization_factor',252)


    def compute_prior(self):
        # portfolio's returns
        returns = self.historical_returns.copy()
        w = self.weights.copy()

        start = str(returns.index[0])[:-9]
        end = str(returns.index[-1])[:-9]

        extra_columns = 0
        for v in self.views.values():
            if v[0] not in returns.columns.tolist():
                index = returns.index
                start = index[0].strftime('%Y-%m-%d')                                        
                end = index[-1].strftime('%Y-%m-%d')
                try:
                    market_track = plb.universe.code(v[0]).tracks(start=start, end=end, direct=True)
                except Exception as e:
                    from plbpy import console
                    console.info(f'Error tracks for {v[0]}. No access right. Please check input views')
                    raise e

                returns = returns.join(market_track.pct_change().reindex(index).fillna(0.0))
                # returns = returns.join(m[[v[0]]])
                extra_columns+=1
  
            if v[1] is not None and v[1] not in returns.columns.tolist():
                index = returns.index
                start = index[0].strftime('%Y-%m-%d')                                        
                end = index[-1].strftime('%Y-%m-%d')
                returns = returns.join(plb.universe.code(v[0]).tracks(start=start, end=end).to_frame().pct_change().reindex(index).fillna(0.0))
                extra_columns+=1
             
        
        w = np.append(w, [0]*extra_columns)
        sigma = returns.cov()*self.annualization_factor
        scaling_factor = .05/w.dot(sigma).dot(w.T)

        self.prior_returns = pd.DataFrame(scaling_factor*(sigma@w), columns=['Prior'])
        self.prior_covariance = sigma

        return self.prior_returns, self.prior_covariance


    def compute_expected(self):
        if self.prior_returns is None:
            prior_returns, prior_covariance = self.compute_prior()
        
        prior_returns, prior_covariance = self.prior_returns.copy(), self.prior_covariance.copy()

        K, N = len(self.views), len(prior_returns.index)
    
        P = np.array([])
        Q = np.array([])
        confidence = np.array([])
        for v in self.views.values():
            P_ = np.zeros(N)
            if v[1] is None:
                P_[prior_returns.index.get_loc(v[0])] = 1
            else:
                P_[prior_returns.index.get_loc(v[0])] = 0.5
                P_[prior_returns.index.get_loc(v[1])] = -0.5
            P = np.append(P, P_, axis=0)
            Q = np.append(Q, v[2])
            confidence = np.append(confidence, v[3])
        
        
        P = P.reshape(K,N)
        Q = Q.reshape(K, 1)

        confidence.reshape(K,1)
        
        sigma = prior_covariance.values
        pi = prior_returns.values.reshape(N,1)
        omega = np.diag(np.diag(P@sigma@P.T))/confidence
        omega[np.isnan(omega)] = 0
        
        e = pi + sigma@P.T@np.linalg.inv(P@sigma@P.T + omega)@(Q-P@pi)
        s = sigma - sigma@P.T@np.linalg.inv(P@sigma@P.T + omega)@P@sigma
        
        e = pd.DataFrame(e, index = prior_returns.index, columns=['Expected Returns'])
        s = pd.DataFrame(s, index = prior_returns.index, columns=prior_returns.index)

        
        return e*100,s





