"""

Portfolio module for the optimization workflow. Built on top of plbpy's core Portfolio moudule

..note::
This module is not to be confused with plbpy's core Portfolio module (plbpy.interface.Portfolio). While similar, this module is built on top of the core with added functionalities directed towards optimizations
"""

import numpy as np
import pandas as pd


import plbpy.Research.Optimization.src.helpers.calculator as calc
from typing import Union, List


import plbpy as plb
s = plb.session
plb_universe = plb.universe


class Portfolio:
    @staticmethod
    def _calculate_strategy_weights(tracks: pd.DataFrame, w: Union[pd.DataFrame, List[float]] = None) -> pd.DataFrame:
        if w is None:
            w_list = np.ones(len(tracks.columns))/len(tracks.columns)
            return pd.DataFrame(data=np.tile(w_list, (len(tracks.index), 1)), index=tracks.index, columns=tracks.columns)
        elif isinstance(w, pd.DataFrame):
            assert w.shape == tracks.shape, "tracks and weights must be the same dimension"
            return w
        elif isinstance(w, List):
            assert len(w) == len(
                tracks.columns), "number of weights must be equal to number of tracks"
            return pd.DataFrame(data=np.tile(w, (len(tracks.index), 1)), index=tracks.index, columns=tracks.columns)

    @staticmethod
    def _calculate_track(returns: pd.DataFrame):
        df = np.cumprod(1+returns)*100
        df.columns = ['portfolio_track']

        return df

    def __init__(self,
                 universe: Union[pd.DataFrame, List[str], type(plb.universe)] = None,
                 weights: Union[pd.DataFrame, List[float], dict] = None,
                 start=None,
                 end=None,):

        """Constructor

        Initialize a portfolio that will be used in the optimization modules

        :param universe: Input assets to the portfolio
        :type universe: Union[pd.DataFrame, List[str], plb.Universe, plb.Portfolio]
        :raise AssertionError: if start and end dates are not specified when input universe is of type plb.Universe

        :param weights: Portfolio allocation
        :type universe: Union(pd.DataFrame, List[float], dict]
        :raise AssertionError: if assets specified in universe is not present in weights

        :param start: Portfolio start date
        :param end: Portfolio end date

        """

        if isinstance(universe, plb.Universe):
            assert start is not None and end is not None,"Please provide start and end dates with type Universe"
            universe = universe.tracks(start=start,end=end,direct=True)

        if isinstance(universe, plb.Portfolio):
            plb_pf = universe.run_backtest()
            universe = plb_pf.universe.tracks(start=plb_pf.start, end=plb_pf.end, direct=True)

            if weights is None:
                if 'listRebalancingDates' in list(plb_pf.info.keys()):
                    weights = plb_pf.result.weights.loc[plb_pf.info['listRebalancingDates'][-1]].drop(['borrowing', 'lending']).to_dict()
                else:
                    weights = plb_pf.result.weights.iloc[-1].drop(['borrowing', 'lending']).to_dict()

        if isinstance(universe, pd.DataFrame):
            if (universe.index[1] - universe.index[0]).value > 4*24*60*60*1000000000:
                self.return_interval = 'W'
                self.annualization_factor = 52
            else:
                self.return_interval = 'D'
                self.annualization_factor = 252

            if start is not None:
                universe = universe.loc[start:end].fillna(
                    method='ffill', limit=20).dropna()

            self._track_df = np.cumprod(1+universe.pct_change().fillna(0.0))*100

        self._tickers = self._track_df.columns.to_numpy()

        if isinstance(weights, dict):
            diff = np.setdiff1d(self._tickers, list(weights.keys()))
            assert len(diff) == 0, f'Weight not found for {diff}'
            weights= [weights[i] for i in self._tickers]

        self._strategy_weights = self._calculate_strategy_weights(
            self._track_df, weights)

        self._return_df = self._track_df.pct_change().fillna(0.0)

        weighted_returns = np.multiply(
            self._return_df.values, self._strategy_weights.values)

        self._pf_returns = pd.DataFrame(data=np.sum(weighted_returns, axis=1).reshape(
            -1, 1), index=self._return_df.index, columns=['portfolio_return']).fillna(0.0)

        self._pf_track = np.cumprod(1+self._pf_returns)*100
        self._pf_track.columns=['portfolio_track']
        self._metrics = None

        self._benchmark = None
        self._exposure = None
        self._constituents_factors = None
        self._universe = plb_universe.code(self.tickers.tolist())

    @property
    def strategy_weights(self) -> np.ndarray:
        return self._strategy_weights

    @property
    def tickers(self) -> np.ndarray:
        """
        Portfolio Assets
        """
        return self._tickers

    def track(self) -> pd.DataFrame:
        """
        Portfolio timeseries
        """
        return self._pf_track

    def returns(self) -> pd.DataFrame:
        """
        Portfolio returns
        """
        return self._pf_returns

    def metrics(self) -> pd.DataFrame:
        """
        Portfolio metrics
        """
        if self._metrics is None:
            start = str(self.track().index[0])[:-9]
            end = str(self.returns().index[-1])[:-9]
            weights = self.strategy_weights.iloc[:1]
            w = [weights[i].values[0] for i in self._universe.codes]
            rebalance_dates = list(map(lambda x: x.strftime("%Y-%m-%d"), pd.date_range(start, end, freq=self.return_interval).tolist()))
            w = calc.repeat_list(w, rebalance_dates)

            pf = plb.Portfolio(universe=self._universe).set_return_interval('Weekly' if self.return_interval == 'W' else 'Daily').set_start(start).set_end(end).set_custom_weight(w, rebalance_dates)
            pf = pf.run_backtest()
            metrics = pf.result.static_metric.drop('Observations', axis=1)
            metrics = metrics.rename(index={'Portfolio': 'portfolio_metrics'})
            self._metrics = metrics

        return self._metrics

    def constituents_track(self) -> pd.DataFrame:
        """
        Portfolio's assets timeseries
        """
        return self._track_df

    def constituents_returns(self) -> pd.DataFrame:
        """
        Portfolio's assets returns
        """
        return self._return_df

    def constituents_metrics(self) -> pd.DataFrame:
        """
        Portfolio's assets metrics
        """
        metrics = calc.calculate_metrics(self._return_df)
        return metrics

    def constituents_data(self) -> pd.DataFrame:
        """
        Portfolio's assets information
        """
        required_data = self._universe.to_frame().copy()
        
        for index, row in required_data.iterrows():
            try:
                required_data.loc[index,'weight'] = self.strategy_weights.iloc[:1][row['short_name']][0]
            except Exception as e:
                    required_data.loc[index,'weight'] = self.strategy_weights.iloc[:1][index][0]

        return required_data












