"""
The Greedy Search Optimizer. This module helps select a specified number of assets from an input universe based on user's
utility function.

"""
from __future__ import annotations
__all__ = ["GreedyOptimizer"]

import empyrical
from pypfopt import EfficientFrontier
import numpy_indexed as npi
from pprint import pprint
import pandas as pd

import numpy as np

import plbpy.Research.Optimization.src.helpers.calculator as calc
from plbpy.Research.Optimization.src.classes.portfolio import Portfolio
from plbpy.Research.Optimization.src.classes.black_litterman import BlackLittermanMeucci
from plbpy.utility import datetime2str

import plbpy as plb
plb_universe = plb.universe
from plbpy import console

class GreedyOptimizer():

    @staticmethod
    def _set_objective_function(objective, interval):
        annualization = 252 if interval =='D' else 52

            # Set objective function definition based  on input
        if objective.lower() == 'volatility' or objective.lower() == 'vol':
            def func(overlay_returns):
                return np.std(overlay_returns) * np.sqrt(annualization)

        elif objective.lower() == 'info ratio':
            def func(overlay_returns):
                return (np.mean(overlay_returns)*annualization)/(np.std(overlay_returns) * np.sqrt(annualization))

        elif objective.lower() == 'drawdown':
            def func(overlay_returns):
                return empyrical.max_drawdown(overlay_returns)

        elif objective.lower() == 'return' or objective.lower() == 'returns':
            def func(overlay_returns):
                return np.mean(overlay_returns).mean()*annualization

        return func

    @staticmethod
    def _get_tickers_to_remove(returns, selected_strategy, all_tickers, max_correlation):

        index = np.where(all_tickers == selected_strategy)[0][0]
        corr_strat = np.corrcoef(returns.T)[index]

        vals_to_remove = np.array(
            list(filter(lambda x: x > max_correlation, corr_strat)))

        # print(npi.indices(corr_strat, vals_to_remove))
        return npi.indices(corr_strat, vals_to_remove)

    @staticmethod
    def _remove_same_acf(selected_strategy, all_tickers):
        selected_ac = plb_universe.code(selected_strategy).data[0]['assetClass']
        selected_factor = plb_universe.code(selected_strategy).data[0]['factor']

        acf_combination = [ [plb_universe.code(i).data[0]['assetClass'], plb_universe.code(i).data[0]['factor']] for i in all_tickers]
        return [cnt for cnt, i in enumerate(acf_combination) if i[0] == selected_ac and i[1] == selected_factor]
        
    def __init__(
                 self,
                 core: Portfolio,
                 num_select: int = 5,
                 universe_filter:plb.Universe = None,
                 hedge_percent: float = 0.15,
                 leverage: bool = True,
                 max_correlation: float = 0.2,
                 num_factors=5,
                 objective: str = 'info ratio',
                 period=None,
                 view=None,
                 expected=False,
                 diverse=False,
                 frontier='max sharpe',
                 use_cache=False,
                 **kwargs
                 ):

        """
        Constructor

        Configure the optimization module

        .. warning ::

            If the initial universe selected contains more than 500 assets. \
            It will lead to a large number of API calls \
            which may result in exhaustion of API calls monthly quota, \
            a forced API session disconnection and long computation time among other things \
            Use of an initial universe filter (param : universe_filter) is strongly suggested \


        :param core: The portfolio to be optimized
        :type core:  Portfolio

        :param num_select: Number of assets to be selected for the optimized portfolio. Default : 5
        :type core:  int

        :param universe_filter: The initial candidate universe from which new assets should be selected
        :type universe_filter:  plb.Universe

        :param hedge_percent: Allocation of the newly selected assets. Must be in decimal form. Default : 0.15
        :type core:  float
        
        :param leverage: Lever the optimized portfolio. Default : True
        :type core:  bool

        :param max_correlation: Maximum correlation between newly selected assets. Default= 0.2
        :type max_correlation: float

        :param num_factors: Number of Premialab Pure Factors® to select. The pure factors helps with the initial screening of candidate universe. Valid inputs : range(0,47) or 'all'
        :type num_factors: int, str

        :param objective: The utility function upon which the new assets are selected. Default : 'info ratio'
        :type objective: str

        :param period: The periods on which utility function must be applied
        :type list:

        :param view: Views for black litterman meucci model
        :type view: list

        :param expected: If True, this will pick assets based on the expected return and vol as suggested by the Black Litterman model
        :type param: bool
            
        :param diverse: Put a constraint on selected assets to not have the same factor. Default: False
        :type diverse: bool
        
        :param frontier: Decides the allocation based on mean-variance optimization
        :type frontier: str

        :param use_cache: Determines whether to extract tracks via API or use stored tracks in plbpy.session.kwargs dictionary
        :type use_cache: bool

        :raise AssertionError: if frontier not in ['max sharpe', 'min vol']
        :raise AssertionError: if objective is not in ['info ratio','return','volatility','drawdown']
        :raise AssertionError: if use_cache = True but tracks are not found in session

        .. note::

            The confidence interval ranges from 0 (no confidence) to 3 (highest confidence)

        .. note::

            if leverage is set to False, weights of all assets (core portfolio + newly selected) will be scaled down to 1

        .. tip::



        Example for period input. Period is a list of list. Each sublist is of length 2: start date and end date.

        >>> period = [ ['2020-01-01', '2020-04-02'] , ['2022-02-01','2022-02-28'] ]

        The input above will only compute the objective on 2 distinct time periods and select the assets accordingly

        Example views input. View is a list of tuples

        >>> view = [ ('PLFEQMOUS', None, -0.02, 0.5), ('PLFCOMOGL', None, 0.15, 2.5)]

        The above provides two views: 1. PLFEQMOUS to fall -2% with low confidence. 2. PLFCOMOGL to rise 15% with high confidence

        """


        valid_objectives = ['volatility','drawdown','return','info ratio']
        assert objective in valid_objectives, f'Objective must be in {", ".join(valid_objectives)}'

        valid_frontier = ['min vol','max sharpe']
        assert frontier in valid_frontier, f'Objective must be in {", ".join(valid_objectives)}'

        # Parameteres related to Optimization portfolio
        self.core = core
        self.hedge_percent = hedge_percent
        self.leverage = leverage
        self.max_correlation = max_correlation
        self.num_factors = num_factors
        self.strategy_basket = []
        self.num_select = num_select
        self.objective = objective
        self.start_date = core.returns().index[0]
        self.views = view
        self.expected = expected
        self.diverse = diverse
        self.frontier = frontier
        self.kwargs = kwargs
        self.use_cache = use_cache

        self.start = datetime2str(self.core.returns().index[0])
        self.end = datetime2str(self.core.returns().index[-1])

        plb.session.kwargs['bl_views'] = self.views
        # Stress Period
        core_returns = self.core.returns()
        if period is None:
            self.stress_periods = np.array(
                [[np.datetime64(core_returns.index[0]), np.datetime64(core_returns.index[-1])]])
        else:
            period = np.array(period, dtype='datetime64[ns]').reshape(-1, 2)

            core_start = np.datetime64(core_returns.index[0])
            core_end = np.datetime64(core_returns.index[-1])

            for i in period:
                assert i[0] >= core_start, "Start date error: not enough data"
                assert i[1] <= core_end, "End date error: not enough data"

            self.stress_periods = period

        filter = universe_filter
        if filter is None:
            all_types = plb_universe.to_frame()['type'].unique().tolist()
            types = [i for i in all_types if i not in ['Benchmark','Pure Factor']]
            self._candidate_universe = plb.universe.type(types)
        else:
            self._candidate_universe = filter

        self._candidate_universe = self._candidate_universe.before(datetime2str(self.start_date))

        num = len(self._candidate_universe.codes)
        if num > 500:
            warning_message = f"[ WARNING ] : Initial universe selected contains {num} assets \n \n" \
                              f"This will lead to a large number of API calls " \
                              f"which may result in exhaustion of API calls monthly quota," \
                              f"a forced API session disconnection and long computation time among other things.\n \n" \
                              f"Use of an initial universe filter (param : universe_filter) to keep the number less than 500 " \
                              f"is strongly suggested" \


            console.info(warning_message)

        df = self._candidate_universe.to_frame()
        self._asset_class = df['asset_class'].unique().tolist()
        self._factor = df['factor'].unique().tolist()
        self._region = df['region'].unique().tolist()

        self.pure_factors = None

        if use_cache:
            self._pf_tracks = plb.session.kwargs.get('pure_factor_tracks', None)
            assert self._pf_tracks is not None,"Cannot use cache for this run. No key 'pure_factor_tracks' found in plb.session.kwargs object"

        else:
            self._pf_tracks = None
        self._pure_factor_universe = plb.universe.type('Pure Factor').asset_class(self._asset_class).region(self._region).factor(self._factor)
        if self.num_factors == 'all':
            self.num_factors = len(self._pure_factor_universe.codes)
        self.strategy_basket = []
        if use_cache:
            self._basket_tracks = plb.session.kwargs.get('basket_tracks', None)
            assert self._basket_tracks is not None,"Cannot use cache for this run. No key 'basket_tracks' found in plb.session.kwargs object"
        else:
            self._basket_tracks = None

        self.final_overlay = None

    def summary(self):
        """
        Print summary of the optimizer
        """

        print('1. Underlying strategies will be selected from following Pure Factors:')
        if (self.pure_factors is None) or (isinstance(self.pure_factors, list)):
            ('\tPlease run .find_best_pure_factors() function')
        else:
            pprint(self.pure_factors['code'].tolist())
        

        print('\tTotal number of stratgies: {}'.format(len(self.strategy_basket)))
        print('\tNumber of strategies to be selected: {} (user input)'.format(
            self.num_select))

        dates = []
        for i, date in enumerate(self.stress_periods):
            dates.append('{} to {}'.format(
                str(date[0])[:10], str(date[1])[:10]))

        print('\n2. Calibration Period:'.format(len(dates)))
        pprint(dates)

        if self.objective.lower() == 'volatility' or self.objective.lower() == 'vol' or self.objective.lower() == 'drawdown':
            print('\n3. Optimization Criteria:\n\t \033[1m Minimize {} \033[0m of Overlay over calibration periods'.format(
                self.objective.title()))

        else:
            print('\n3. Optimization Criteria:\n\t \033[1m Maximize {} \033[0m of Overlay over calibration periods'.format(
                self.objective.title()))

    def _create_strategy_basket(self, spf, **kwargs):
        correlation = kwargs.pop('corr', self.max_correlation)

        d = self._candidate_universe.to_frame().reset_index()

        if self._pf_tracks is None:
            self._pf_tracks = calc.extract_tracks(self._pure_factor_universe.codes,
                                                      start=self.start, end=self.end)
            plb.session.kwargs['pure_factor_tracks'] = self._pf_tracks

        pf_returns = self._pf_tracks.pct_change().fillna(0.0)
        if self._basket_tracks is None:
            self._basket_tracks = calc.extract_tracks(d['code'].tolist(),
                                                      start=self.start, end=self.end)
            plb.session.kwargs['basket_tracks'] = self._basket_tracks

        all_returns = self._basket_tracks.pct_change().fillna(0.0)
        pf_returns = pf_returns.reindex(all_returns.index).fillna(0.0, limit=20).dropna()

        df = pd.DataFrame()
        for index, row in spf.iterrows():  # selected pure factors
            # temp is the dataframe of all strategies corresponding to a pure factor
            temp = self._candidate_universe.asset_class(row['asset_class']).factor(row['factor']).region(row['region']).to_frame().reset_index()
            p = row['code'] # pure factor ticker
            
            for i, r in temp.iterrows(): 
                s = r['code'] # strategy ticker
                if s not in all_returns.columns.tolist():
                    continue
               
                corr = pd.concat( [pf_returns[[p]], all_returns[[s]]], axis=1).fillna(
                    0.0, limit=20).dropna().corr().iloc[1][0] # correlation of a strategy with ist pure factor
            
                correlation = self.max_correlation if correlation is None else correlation

                if corr >= correlation:
                    df = df.append(d.loc[i])
    
        assert len(df)!=0,'No Strategies found'
        return np.unique(df['code'].to_numpy())
    
    def _create_pure_factor_data(self, selected_pure_factors_tickers):
        start = self.core.returns().index[0].strftime('%Y-%m-%d')
        end = self.core.returns().index[-1].strftime('%Y-%m-%d')
        pure_factors = self._pure_factor_universe.to_frame().reset_index()

        spf = pd.DataFrame()
        for f in selected_pure_factors_tickers:
            temp = pure_factors[pure_factors['code'] == f]
            spf = spf.append(temp)

        spf = spf.reset_index()
        spf = spf.drop('index', axis=1)

        for index, row in spf.iterrows():
            # ------------ Calculate  Returns and  Info Ratio of Pure Factors ----------- #
            temp = plb.Portfolio(universe=plb_universe.code(
                row['code'])).set_start(start).set_end(end)
            temp = temp.run_backtest()

            # dr = x[row['ticker']]

            ret = temp.result.static_metric['Return'][0]
            vol = temp.result.static_metric['Volatility'][0]
            ir = temp.result.static_metric['Information Ratio'][0]

            spf.loc[index, 'Return'] = str(round((ret), 2))
            spf.loc[index, 'Volatility'] = str(round((vol), 2))
            spf.loc[index, 'Information Ratio'] = str(round((ir), 2))
        
        return spf

    def create_initial_basket(self, objective=None, correlation=None, force=False):
        """
        Narrow down the candidate universe based on Premialab Pure Factors®: selected via the greedy search method

        :param objective: The utility function of selecting Pure Factors
        :type objective: str

        :param correlation: The minimum correlation of selected candidates with its pure factor
        :type correlation: float

        :param force: Force re-select appropriate pure factors
        :type force: bool

        .. note::

        This function MUST be run before running the optimizer

        """
        objective = self.objective if objective is None else objective
        valid_objectives = ['volatility','drawdown','return','info ratio']
        assert objective in f'Objective must be in {", ".join(valid_objectives)}'

        if self.pure_factors is None or force:
            if self.num_factors == len(self._pure_factor_universe.codes):
                selected_pure_factors_tickers = self._pure_factor_universe.codes
            else:
                selected_pure_factors_tickers = self._find_best_overlay(
                    pure_factors=True, obj=objective, num_factors=self.num_factors)
        else:
            selected_pure_factors_tickers = self.pure_factors['code'].tolist()

        spf = self._create_pure_factor_data(selected_pure_factors_tickers)
        self.strategy_basket = self._create_strategy_basket(spf, corr=correlation)
        self.pure_factors = spf.copy()

        return self

    def run_optimizer(self):
        """
        Based on the optimizer params and strategy basket, run a greedy search algorithm to select the most appropriate
        assets to create an Optimization portfolio
        """
        overlay = self._find_best_overlay()
        self.final_overlay = overlay

        return overlay

    def _find_best_overlay(self, stress_periods=None, pure_factors=False, obj=None, num_factors=None):
        if not pure_factors:
            assert self.pure_factors is not None, "Please run Optimizer.create_initial_basket() first to find most optimum candidate basket"
        # --------- Setting up the parameters of optimization ---------

        ##### OBJECTIVE #####
        objective = self.objective if obj is None else obj

        if objective.lower() == 'volatility' or objective.lower() == 'vol':
            minimize = True
        else:
            minimize = False
        objective_function = self._set_objective_function(objective, interval = self.core.return_interval)

        #### STRESS PERIODS #####
        stress = self.stress_periods if stress_periods is None else stress_periods

        start = datetime2str(self.core.returns().index[0])
        end = datetime2str(self.core.returns().index[-1])
        #### ALL RETURNS #####
        if not pure_factors:
            # Read pandas dataframe cotaining daily returns of all strategies
            if self._basket_tracks is None:
                self._basket_tracks = calc.extract_tracks(self.strategy_basket,
                                                          start=start, end=end)
                plb.session.kwargs['basket_tracks'] = self._basket_tracks
            plb_returns = self._basket_tracks[self.strategy_basket].pct_change().fillna(0.0)
            basket = self.strategy_basket

        else:

            if self._pf_tracks is None:
                self._pf_tracks = calc.extract_tracks(self._pure_factor_universe.codes,
                                                      start=start, end=end)
                plb.session.kwargs['pure_factor_tracks'] = self._pf_tracks
            plb_returns = self._pf_tracks.pct_change().fillna(0.0)
            basket = plb_returns.columns.to_numpy()

        core_returns = self.core.returns()

        # - reindex core and stategy universe
        temp = core_returns.join(plb_returns).fillna(0.0, limit=20).dropna()
        plb_returns = temp.drop(core_returns.columns.tolist(), axis=1)
        core_returns = temp[core_returns.columns.tolist()]

        # - convert to numpy for faster calculations
        cols = plb_returns.columns.to_numpy()
        values = plb_returns.values
        return_dates = plb_returns.index.to_numpy()

        #### OBJECTS DIRECTLY USED IN THE OPTIMIZER ####
        core_returns = core_returns.values
        basket_returns = values[:, npi.indices(cols, basket)]
        remaining_tickers = basket
        selected_hedge = []
        outer_iterations = self.num_select if num_factors is None else num_factors

        #### WEIGHTS #####
        single_weight = 1 / outer_iterations if pure_factors else (self.hedge_percent/outer_iterations) # hedge percentage for a single hedge strategy
        core_weight = 1 if self.leverage or pure_factors else 1 - self.hedge_percent  # core portfolio's contribution in Optimization
        hedge_weight = 1 if self.leverage or pure_factors else self.hedge_percent
    
        # -------------- Optimizer (Greedy Search Algorithm) ------------

        #### START OUTER LOOP #####

        for cnt in range(outer_iterations):

            temp_strat = []
            temp_obj = []

            if cnt == 0:
                current_pf_returns = core_returns.copy()  # no strategies in Optimization in first iteration
         
            #### START INNER LOOP #####
  
            for i, strategy in enumerate(remaining_tickers):
                
                # print(strategy)

                test_pf_returns = np.append(current_pf_returns, 
                                            basket_returns[:, i].reshape(-1, 1), 
                                            axis=1) # append a strategy to the currently selected portfolio
                
                weights = np.array(
                    [core_weight]+[single_weight*hedge_weight]*(test_pf_returns.shape[1] - 1))  # weight array

                overlay_returns = np.multiply(test_pf_returns, weights).sum(axis=1)

                # subset the returns to only include stress periods
                overlay_stress_returns = calc.subset_returns(overlay_returns, stress, return_dates)

                if self.expected:
                    # optimize based on expected
                    er, cov = BlackLittermanMeucci(
                        portfolio=pd.DataFrame(overlay_returns, index=return_dates, columns=['pf']),
                        views=self.views).compute_expected()

                    mu, sigma = er.loc['pf'][0] / 100, np.sqrt(cov.loc['pf']['pf'])
                    if self.objective.lower() == 'info ratio':
                        obj = (mu / sigma)
                    elif self.objective.lower() in ['return','returns']:
                        obj = mu
                    elif self.objective.lower() in ['vol','volatility']:
                        obj = sigma

                else:
                    obj = objective_function(overlay_stress_returns)

                temp_strat.append(strategy)
                temp_obj.append(obj)

            # END INNER LOOP

            index = np.argmin(np.array(temp_obj)) if minimize else np.argmax(np.array(temp_obj))
            # add subsequent strategy to the current selected hedge and update current returns
            selected_hedge.append(temp_strat[index])
            
            current_pf_returns = np.append(current_pf_returns, basket_returns[:, np.where(
                remaining_tickers == temp_strat[index])[0][0]].reshape(-1, 1), axis=1)

            max_correlation = 0.9 if pure_factors else self.max_correlation

            # upadate basket
            # get indices of strategies to remove
            corr_fail = self._get_tickers_to_remove(
                basket_returns, temp_strat[index], remaining_tickers, max_correlation)

            basket_returns = np.delete(basket_returns, corr_fail, axis=1)
            remaining_tickers = np.delete(remaining_tickers, corr_fail)

            if self.diverse and not pure_factors:
                ac_fail = self._remove_same_acf(temp_strat[index], remaining_tickers)
                basket_returns = np.delete(basket_returns, ac_fail, axis=1)
                remaining_tickers = np.delete(remaining_tickers, ac_fail)
        # END OUTER LOOP
        
        if pure_factors:
            return selected_hedge

        else:
            # ----------- Overlay Portfolio Constructuion with selected strategies ------------

            #### WEIGHTS CALCULATION ####

            if self.views is not None:
                blm = BlackLittermanMeucci(portfolio=plb_returns[selected_hedge], views=self.views, annualization_factor=self.core.annualization_factor)
                er, cov = blm.compute_expected()
            else:
                er = pd.DataFrame(np.mean(plb_returns[selected_hedge])*self.core.annualization_factor, columns=['Expected Returns'])*100
                cov = plb_returns[selected_hedge].cov()*self.core.annualization_factor
            plb.session.kwargs['mu_BL'] = er
            plb.session.kwargs['sigma_BL'] = cov

            er = er['Expected Returns'].iloc[0:len(selected_hedge)]
            cov = cov.iloc[0:len(selected_hedge), 0:len(selected_hedge)]

            ef = EfficientFrontier(er, cov, (0.05, 1))
            if self.frontier == 'max sharpe':
                ef.max_sharpe()
            elif self.frontier == 'min vol':
                ef.min_volatility()

            selected_weights = np.array(list(ef.clean_weights().values()))
            
            selected_weights *= self.hedge_percent
            
            #### TRACK CALCULATION #####
            core_constituents_track = self.core.constituents_track()
            core_constituents_weights = self.core.strategy_weights

            selected_hedge_track = np.cumprod(np.e**plb_returns[selected_hedge].fillna(0.0))*100
            selected_hedge_weight = pd.DataFrame(data=np.tile(selected_weights, (len(core_constituents_weights.index),1)), columns = selected_hedge, index=core_constituents_weights.index)
            
            allocation_weights = pd.concat(((core_constituents_weights*core_weight), selected_hedge_weight), axis=1)
         
            track_df = pd.concat((core_constituents_track, selected_hedge_track), axis=1).fillna(method='ffill')
            track_df = track_df.loc[self.start:self.end].fillna(method='ffill')
            track_df = np.cumprod(1+track_df.pct_change().fillna(0.0))*100
            allocation_weights = allocation_weights.reindex(track_df.index)
            # if self.stress_periods.shape == (1,2):
            #     track_df = np.cumprod(1+track_df.loc[self.stress_periods[0][0]: self.stress_periods[0][1]].fillna(method='ffill').pct_change().fillna(0.0))*100
            #     allocation_weights = allocation_weights.reindex(track_df.index)

            allocation_weights = allocation_weights.iloc[-1].to_dict()
            return Portfolio(universe=track_df, weights=[allocation_weights[i] for i in track_df.columns])