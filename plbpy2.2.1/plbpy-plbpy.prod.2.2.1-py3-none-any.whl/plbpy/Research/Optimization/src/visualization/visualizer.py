import numpy as np
import pandas as pd
from plbpy.Research.Optimization.src.visualization import viz_calculator as viz_calc
from plbpy.Research.Optimization.src.helpers import calculator as calc
from plbpy.Research.Optimization.src.classes.portfolio import Portfolio
import seaborn as sns


import plbpy as plb
s=plb.session
plb_universe = plb.universe


sns.set()


class Visualizer():
    def __init__(self,
                 overlay: Portfolio,
                 benchmark: Portfolio,
                 ):
        self.overlay = overlay
        self.benchmark = benchmark

        hedge_tickers = list(filter(lambda x: x not in benchmark.tickers, overlay.tickers))

        hedge_track_df = overlay.constituents_track()[hedge_tickers]
        hedge_weights_df = overlay.strategy_weights[hedge_tickers]
        scaling_factor = hedge_weights_df.sum(axis=1)[0]
        hedge_weights_df = hedge_weights_df/scaling_factor

        self.hedge = Portfolio(universe=hedge_track_df, weights=hedge_weights_df)
   

    def track_record(self, **kwargs):
        track_overlay = self.overlay.track().loc[:, 'portfolio_track']
        track_benchmark = self.benchmark.track().loc[:, 'portfolio_track']
        track_hedge = self.hedge.track().loc[:, 'portfolio_track']

        return viz_calc.plot_line_overall([track_overlay, track_benchmark, track_hedge],
                                   'Track Record', ['Optimized', 'Core', 'Overlay'])

    def constituents_track_record(self, **kwargs):
        # ret = self.Optimization.constituents_returns()
        # values = pd.DataFrame(calc.ratio_return(ret), index = [ret.index[0]-BDay(1)] + ret.index.tolist(), columns = ret.columns)*(1/self.Optimization.strategy_weights)
        tr = self.overlay.constituents_track()
        values = pd.DataFrame(calc.ratio_return(
            calc.log_return(tr)), index=tr.index, columns=tr.columns)

        return viz_calc.plot_line_constituents(
            values, 'Constituent Track Record', [plb_universe.code(i).data[0]['shortName'] for i in self.overlay.tickers])

    
    def other_overall_lines(self, **kwargs):
        rol = kwargs.get('rolling',self.benchmark.annualization_factor)
        viz_calc.other_overall_lines(self.benchmark, self.overlay, rolling=rol)

    def drawdown(self, **kwargs):

        overlay_dd = viz_calc.calculate_daily_drawdown(
            self.overlay.track())['dd']
        benchmark_dd = viz_calc.calculate_daily_drawdown(
            self.benchmark.track())['dd']

        viz_calc.plot_line_overall(
            [overlay_dd, benchmark_dd], 'Drawdown', ['Overlay',  'Core'])


    def rolling_metrics(self, **kwargs):
        rir_overlay = viz_calc.calculate_rolling_info_ratio(
            self.overlay.returns())
        rir_benchmark = viz_calc.calculate_rolling_info_ratio(
            self.benchmark.returns())
        rv_overlay = viz_calc.calculate_rolling_volatility(
            self.overlay.returns())
        rv_benchmark = viz_calc.calculate_rolling_volatility(
            self.benchmark.returns())
        rr_overlay = viz_calc.calculate_rolling_return(self.overlay.returns())
        rr_benchmark = viz_calc.calculate_rolling_return(
            self.benchmark.returns())

        viz_calc.plot_line_overall(
            [rv_overlay, rv_benchmark], 'Rolling 252D Volatility', ['Overlay', 'Core'])
        viz_calc.plot_line_overall(
            [rir_overlay, rir_benchmark], 'Rolling 252D Info Ratio', ['Overlay', 'Core'], True)
        viz_calc.plot_line_overall([rr_overlay, rr_benchmark], 'Rolling 252D Return', [
                                   'Overlay', 'Core'], True)

    def metric_bar_chart(self, **kwargs):
        overlay_metrics = self.overlay.metrics()
        benchmark_metrics = self.benchmark.metrics()
        # hedge_metrics = self.hedge.metrics()

        # hedge_metrics = hedge_metrics.loc['portfolio_metrics'].tolist()

        viz_calc.generate_overall_bar_chart(
            [overlay_metrics, benchmark_metrics])

    def metrics_parallel_chart(self, **kwargs):
        returns = self.overlay.returns()
        metrics_to_plot = ['return', 'volatility', 'maxDD']
        labels = ['Return p.a', 'Volatility', 'Maximum Drawdown']
        colors = ['#183C69', '#993E5C', '#1985A1']
        viz_calc.parallel_plot(returns, metrics_to_plot, colors, labels, False)

        metrics_to_plot = ['sharpe_ratio', 'info_ratio',
                           'sortino_ratio', 'omega_ratio', 'tail_ratio']
        labels = ['Sharpe', 'Info', 'Sortino', 'Omega', 'Tail']
        colors = ['#183C69', '#993E5C', '#1985A1', '#F2893B', '#996699']
        viz_calc.parallel_plot(returns, metrics_to_plot, colors, labels, True)

    def spider_chart(self, **kwargs):
        return viz_calc.generate_spider_chart(
            self.overlay.metrics(), self.benchmark.metrics(), 111)

    def constituents_metric_chart(self, **kwargs):
        const_met = calc.calculate_metrics(self.hedge.constituents_returns()*self.hedge.strategy_weights)
        viz_calc.generate_cmc_chart(
           const_met, self.overlay.metrics())
    #
    # def stress_charts(self, **kwargs):
    #     vol = self.prepare_stress_values('Volatility')
    #     ret = self.prepare_stress_values('Return')
    #     ir = self.prepare_stress_values('Information Ratio')
    #
    #     for i in vol:
    #         i.reverse()
    #
    #     for i in ret:
    #         i.reverse()
    #
    #     for i in ir:
    #         i.reverse()
    #
    #     viz_calc.prepare_stress_dumbell_plot(vol, ret, ir, np.flip(self.stress_periods))

    def diverging_bar(self, **kwargs):
        # generate diverging bars require returns for each individual strategy
        individual_returns = self.hedge.constituents_returns()/self.hedge.strategy_weights
        viz_calc.generate_diverging_bars(individual_returns)

    # def prepare_stress_values(self, metric, **kwargs):
    #     # print(self.stress_periods)
    #     overlay_y_values = viz_calc.get_stress_values(self.overlay.returns(), metric, self.stress_periods)
    #     benchmark_y_values = viz_calc.get_stress_values(self.benchmark.returns(), metric, self.stress_periods)
    #
    #     return [overlay_y_values, benchmark_y_values]
    #
    # def scatter_plot(self, **kwargs):
    #
    #     hedge_returns = self.hedge.returns()
    #     benchmark_returns = self.benchmark.returns()
    #
    #     # stress_hedge_returns = pd.DataFrame(calc.subset_returns(hedge_returns.values.reshape(-1,),self.stress_dates, hedge_returns.index.to_numpy()))
    #     # stress_benchmark_returns = pd.DataFrame(calc.subset_returns(benchmark_returns.values.reshape(-1,),self.stress_dates, benchmark_returns.index.to_numpy()))
    #     stress_hedge_returns = self.hedge.stress_returns(self.stress_periods)
    #     stress_benchmark_returns = self.benchmark.stress_returns(
    #         self.stress_periods)
    #
    #     viz_calc.generate_scatter_plot(benchmark_returns, hedge_returns, [
    #                                    'Core', 'Hedge'], 'Returns', stress_benchmark_returns, stress_hedge_returns)

    # def stress_comparison(self, **kwargs):
    #     viz_calc.generate_stress_comparison_charts(
    #         self.overlay.track(), self.benchmark.track(), self.stress_periods)
    #
    # def scatter_stress_plots(self, **kwargs):
    #     viz_calc.generate_scatter_stress_plots(
    #         self.hedge.returns(), self.benchmark.returns(), self.stress_periods)


    def correlation_scatter(self, **kwargs):
        ind_returns = self.hedge.constituents_returns()
        core_returns = self.benchmark.returns()
        df = pd.concat((ind_returns, core_returns), axis=1).fillna(method='ffill')
        # df.columns=['x','y']
 
        viz_calc.generate_correlation_scatter(df[core_returns.columns.tolist()],df[ind_returns.columns.tolist()])

    def correlation_matrix(self):
        return viz_calc.correlation_matrix(self.overlay.constituents_returns(), self.benchmark)


    def overall_kde_plot(self, **kwargs):
        df = pd.concat((self.overlay.returns(),self.benchmark.returns()), axis=1)
        df.columns = ['x','y']
        return viz_calc.generate_overall_kde_plot(
            df[['x']], df[['y']])

    # def stress_kde_plots(self, **kwargs):
    #     viz_calc.generate_stress_kde_plots(
    #         self.overlay.returns(), self.benchmark.returns(), self.stress_dates)

    def daily_return_attribution(self, **kwargs):
        return viz_calc.daily_return_attribution(
            self.overlay.constituents_returns()*self.overlay.strategy_weights, self.overlay.returns())

    def constituent_box_plot(self, **kwargs):
        viz_calc.const_bp(self.hedge.constituents_returns())

    def constituent_pairplot(self, **kwargs):
        viz_calc.pairplot(self.overlay.constituents_returns())

    def weight_info(self, **kwargs):
        viz_calc.generate_weight_info_pie(
            self.overlay, self.benchmark, self.hedge)

    def overlay_structure(self, **kwargs):
        viz_calc.generate_overlay_structure(self.overlay, self.benchmark, self.hedge)

    def efficient_frontier(self, **kwargs):
        return viz_calc.draw_bl_efficient_frontier(self.hedge,  self.benchmark, self.overlay)

    def metrics_movement(self):
        return viz_calc.metrics_move(self.benchmark, self.overlay, self.hedge)

    def expected_returns(self):
        return viz_calc.expected_returns(self.benchmark, self.overlay, self.hedge,ann_factor=self.benchmark.annualization_factor)

    def performance(self, **kwargs):
        return self.track_record(),
        self.other_overall_lines(),
        self.overall_kde_plot(),
        self.spider_chart()

    def bl_analysis(self):

        self.efficient_frontier()
        self.expected_returns()


    def constituents_analysis(self, **kwargs):
        self.constituents_track_record()
        self.daily_return_attribution()
        self.correlation_matrix()
