import plbpy.Research.Optimization.src.helpers.calculator as calc
import pandas as pd
import numpy as np
import empyrical
import scipy.stats as stats
import matplotlib.pyplot as plt
import seaborn as sns
from math import pi
from sklearn.preprocessing import MinMaxScaler
import pickle
import math

from plotly.subplots import make_subplots
from matplotlib.patches import FancyArrowPatch, Patch, Rectangle

import plotly.graph_objects as go

import plotly.express as px

from pypfopt import EfficientFrontier
from scipy import optimize
from matplotlib.ticker import NullFormatter

import plbpy as plb
plb_universe = plb.universe


colors = ['#183C69','#993E5C','#1985A1','#F2893B','#996699','#3D7650','#7C97C2','#967E9E','#F1CECD','#9CC5BF','#71B080','#60ACA7','#8279CE','#DBA0B3','#CFC6DD','#B9AEE1','#4B4B4B','#8B8B8B','#CB4154']

from plbpy.Research.Optimization.src.classes.black_litterman import BlackLittermanMeucci

################# VISUALIZATIONS ###################


def get_colors():
    return colors


def calculate_daily_drawdown(track, *kwargs):
    temp = track.copy()
    temp['dd'] = 0.0
    for index,row in temp.iterrows():
        temp.at[index,'dd'] = (temp.loc[index][0]/temp.loc[:index].max()[0])-1
    return temp

def visualize_track(core, **kwargs):
    plt.style.use('seaborn-white')
    fig, ax = plt.subplots(figsize=(18,6))
    
    
    const_tr = core.constituents_track()
    pf_track = core.track()
    
    ratio_ret_track = np.cumprod(np.e**np.log(const_tr).diff().fillna(0.0))*100
 
    
    ax.plot(pf_track, color=colors[0], linewidth=2, zorder=3, label='Portfolio')
    # plt.plot(ratio_ret_track)
    for i,const in enumerate(ratio_ret_track.columns):
        ax.plot(ratio_ret_track[const], color=colors[i+1], linewidth=0.5, alpha=0.4, label=plb_universe.code(const).data[0]['shortName'])

    stress_dates = kwargs.pop('stress_dates',None)
    if stress_dates is not None:
        for i in stress_dates:
            plt.axvspan(pd.to_datetime(i[0]), pd.to_datetime(i[1]), color='red', alpha=0.04)

    ax.set_yscale('log')
    plt.ion()
    ax.yaxis.set_major_formatter(NullFormatter())
    ax.yaxis.set_minor_formatter(NullFormatter())
 

    
    ax.set_ylabel('$Log$ $Scale$')
    ax.spines['right'].set_visible(False)
    ax.spines['top'].set_visible(False)
    ax.spines['bottom'].set_visible(False)
    ax.grid(axis='x', color='lightgray', alpha=0.3)
    ax.axhline(y = 100, color='gray', linestyle='dashed', alpha=0.5)

    plt.legend(loc='upper center', bbox_to_anchor=(0.5, -0.08), frameon=False, ncol=3)
    ax.set_title('Core Portfolio Track', weight='bold')
    plt.tight_layout()
    
    return fig, ax

def plot_line_overall(values, title, labels, line_at_zero = False, **kwargs):
    plt.style.use('seaborn-white')
    fig, ax = plt.subplots(figsize=(18,6))

    for i,value in enumerate(values):
        if i == 0:
            ax.plot(value, color='#183C69', linewidth=2, zorder=2.5)
        elif i == 1:
            ax.plot(value, color='#993E5C', linewidth=1.25)
        elif i == 2:
            ax.plot(value, color='lightgray', linewidth=1.25)

    ax.set_yscale('log')
        
    plt.ion()
    ax.yaxis.set_major_formatter(NullFormatter())
    ax.yaxis.set_minor_formatter(NullFormatter())
    ax.set_ylabel("$Log$ $Scale$")
    
    stress_dates = kwargs.pop('stress_dates',None)
    if stress_dates is not None:
        for i in stress_dates:
            plt.axvspan(pd.to_datetime(i[0]), pd.to_datetime(i[1]), color='red', alpha=0.04)
   
    
    ax.spines['right'].set_visible(False)
    ax.spines['top'].set_visible(False)
    ax.spines['bottom'].set_visible(False)
    ax.grid(axis='x', color='lightgray', alpha=0.3)
    ax.axhline(y=100, color='gray', linestyle='dashed', alpha=0.5)
    
    plt.legend(labels, loc='upper center', bbox_to_anchor=(0.5, -0.07), frameon=False, ncol=5)
    ax.set_title(title, weight='bold')
    plt.tight_layout()
    return fig, ax
    # ax.annotate('100', (0,100))
    # print(list(ax.get_yticklabels()))
    # plt.savefig('Overall Track.svg')
    # plt.show()


    
def other_overall_lines(benchmark, overlay, **kwargs):
    dd_overlay =calculate_daily_drawdown(
            overlay.track())['dd']
    dd_benchmark = calculate_daily_drawdown(
            benchmark.track())['dd']

    rir_overlay = calculate_rolling_info_ratio(
            overlay.returns(), rolling=kwargs.get('rolling',252))
    rir_benchmark = calculate_rolling_info_ratio(
            benchmark.returns(), rolling=kwargs.get('rolling',252))

    rv_overlay = calculate_rolling_volatility(
            overlay.returns(), rolling=kwargs.get('rolling',252))
    rv_benchmark = calculate_rolling_volatility(
            benchmark.returns(), rolling=kwargs.get('rolling',252))

    rr_overlay = calculate_rolling_return(
            overlay.returns(), rolling=kwargs.get('rolling',252))
    rr_benchmark = calculate_rolling_return(
            benchmark.returns(), rolling=kwargs.get('rolling',252))
            
    plt.style.use('seaborn-white')
    fig, ax = plt.subplots(figsize=(18,12), nrows=2, ncols=2)
    ax[0][0].plot(dd_overlay, color=colors[0], linewidth=1, zorder=2.5)
    ax[0][0].plot(dd_benchmark, color=colors[1], zorder=2.5)
    ax[0][0].set_title('Drawdown', weight='bold')

    ax[0][1].plot(rir_overlay, color=colors[0], linewidth=1, zorder=2.5)
    ax[0][1].plot(rir_benchmark, color=colors[1], zorder=2.5)
    ax[0][1].set_title('Rolling {}D Info Ratio'.format(kwargs.get('rolling',252)), weight='bold')


    ax[1][0].plot(rr_overlay, color=colors[0], linewidth=1, zorder=2.5)
    ax[1][0].plot(rr_benchmark, color=colors[1], zorder=2.5)
    ax[1][0].set_title('Rolling {}D Return'.format(kwargs.get('rolling',252)), weight='bold')



    ax[1][1].plot(rv_overlay, color=colors[0], linewidth=1, zorder=2.5)
    ax[1][1].plot(rv_benchmark, color=colors[1], zorder=2.5)
    ax[1][1].set_title('Rolling {}D Volatility'.format(kwargs.get('rolling',252)), weight='bold')



    for i,a in enumerate(ax.reshape(-1)):
        a.spines['top'].set_visible(False)
        a.spines['right'].set_visible(False)
        a.grid(axis='y', color='lightgray', alpha=0.3)
        a.axhline(y=0, linestyle='--', alpha=0.5, color='gray')
        # a.locator_params(axis='x', nbins=5)
       
        xticks = a.get_xticks()
        for x in xticks:
            a.axvline(x=x, color='lightgray', alpha=0.3, linewidth = 0.5)
        if i == 1:
            a.spines['bottom'].set_visible(False)
            a.set_xticks([])
        else:
            yticks = a.get_yticks()
            yticks = [f'{str(round(z*100, 2))}%' for z in yticks]
            a.set_yticklabels(yticks)
    # plt.legend(['Overlay', 'Core'], lo    c='upper center', bbox_to_anchor=(0, -0.05), frameon=False, ncol=5)
    plt.tight_layout()
    return fig, ax 


def plot_line_constituents(values, title, labels, **kwargs):
    plt.style.use('seaborn-white')
    fig, ax = plt.subplots(figsize=(18,6))
    

    for i,col in enumerate(values.columns.tolist()):
        ax.plot(values.loc[:,col], linewidth=1.5, color=colors[i], zorder=2.5)    
     
    # stress = calc.get_stress_periods()
    # for i in stress:
    #     ax.axvspan(pd.to_datetime(i['start_date']), pd.to_datetime(i['end_date']), color='red', alpha=0.04)
        
    ax.set_yscale('log')
    plt.ion()
    ax.yaxis.set_major_formatter(NullFormatter())
    ax.yaxis.set_minor_formatter(NullFormatter())
    
    ax.set_ylabel('$Log$ $Scale$')
    ax.spines['right'].set_visible(False)
    ax.spines['top'].set_visible(False)
    ax.spines['bottom'].set_visible(False)
    ax.axhline(color='gray', linestyle='dashed', y=100, alpha=0.5)
    
    plt.grid(axis='x', color='lightgray', alpha=0.7)
    plt.legend(labels, loc='upper center', bbox_to_anchor=(0.5, -0.05), frameon=False, ncol=3)
    ax.set_title(title, weight='bold')
    stress_dates = kwargs.pop('stress_dates',None)
    if stress_dates is not None:
        for i in stress_dates:
            plt.axvspan(pd.to_datetime(i[0]), pd.to_datetime(i[1]), color='red', alpha=0.04)
    plt.tight_layout()
    return fig, ax


def calculate_rolling_info_ratio(returns, **kwargs):
    
    return returns.rolling(kwargs.get('rolling',252)).apply(
        lambda x: empyrical.annual_return(x) / empyrical.annual_volatility(x))
    
def calculate_rolling_volatility(returns, **kwargs):
    return returns.rolling(kwargs.get('rolling',252)).apply(
        lambda x: empyrical.annual_volatility(x))

def calculate_rolling_return(returns, **kwargs):
    return returns.rolling(kwargs.get('rolling',252)).apply(
        lambda x: empyrical.annual_return(x))

def generate_bar_chart(ax, values, labels, title, single=False, **kwargs):
    x = np.arange(len(labels))
    width = 0.3
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    if single == False:
        rect1 = ax.bar(x-width/2, values[0], width, label='Optimized', alpha=0.8, color='#183C69', zorder=2.5)
        rect2 = ax.bar(x+width/2, values[1], width, label='Core', alpha=0.8, color='#993E5C',  zorder=2.5)
    else:
        rect1 = ax.bar(x-width/2, values[0], width=0.2, label='Optimized', alpha=0.8, color='#183C69', zorder=2.5)
        rect2 = ax.bar(x+width/2+0.05, values[1], width=0.2, label='Core', alpha=0.8, color='#993E5C',  zorder=2.5)
        ax.set_xticklabels([])
        

    ax.set_title('${}$'.format(title))
    ax.grid(axis='y', alpha=0.3)
    
    
def _spider_data(metrics, categories):
    metrics = metrics[categories].loc['portfolio_metrics'].tolist()
    
    n = len(categories)
    
    angles = [N / float(n)*2*pi for N in range(n)]
    angles += angles[:1]
    
    return {'angles':angles, 'metrics': metrics}


def _scale(data, ran):
   
    ranges = []
    for i,d in zip(ran,data):
        ranges.append(np.array([i[0], d, i[1]]))
   
    scaler=MinMaxScaler()
    scaled_values = []
    
    for i,r in enumerate(ranges):
        r = r.reshape(r.shape[0],1)
        scaler.fit(r)
        r = scaler.transform(r)
        scaled_values.append(r[1])
    
    scaled_values += scaled_values[:1]
  
    return scaled_values


def _adjust_values(ov,c,range):
    new_ov =[]
    new_c = []
    for i, (d_ov, d_c) in enumerate(zip(ov,c)):
        if d_ov > range[i][1] or d_c > range[i][1]:
            range[i][1] = max(d_c, d_ov)+abs(d_c-d_ov)*2
        if d_ov < range[i][0] or d_c < range[i][0]:
            range[i][1] = min(d_c, d_ov) - abs(d_c-d_ov)*2
        # if d_ov<d_c:
        #     d_ov*=(-1)
        #     d_c*=(-1)
        #     range[i][0]*=(-1)
        #     range[i][1]*=(-1)
            # temp = range[i][0]
            # range[i][0] = range[i][1]
            # range[i][1] = temp



        new_ov.append(d_ov)
        new_c.append(d_c)

    return new_ov, new_c, range

        
    
def generate_spider_chart(overlay_metrics, benchmark_metrics, row_col_num):
    plt.style.use('seaborn-white')
    fig = plt.figure(figsize=(5,5))    
    
    categories = ['Return' , 'Volatility','Max Drawdown', 'Information Ratio','Sortino Ratio']
    
    data_ov = _spider_data(overlay_metrics.copy(), categories)
    data_b = _spider_data(benchmark_metrics.copy(), categories)


    ranges = [
              np.array([-5,10]), 
              np.array([0,10]), 
              np.array([0,-25]), 
              np.array([-2,2]),
              np.array([-5,5]) ]

    new_ov, new_c, ranges = _adjust_values(data_ov['metrics'], data_b['metrics'], ranges)

    scaled_metrics_ov = _scale(new_ov, ranges)
    scaled_metrics_b = _scale(new_c, ranges)


    ax = plt.subplot(row_col_num, polar='True')

    plt.sca(ax)
    plt.polar(data_ov['angles'], scaled_metrics_ov, marker='.', color='#183C69', zorder=2.5)
    plt.fill(data_ov['angles'], scaled_metrics_ov, alpha=0.1, color='#183C69', zorder=2.5)
    
    plt.polar(data_b['angles'], scaled_metrics_b, marker='.', color='#993E5C')
    plt.fill(data_b['angles'], scaled_metrics_b, alpha=0.1, color='#993E5C')
    
   
    plt.ylim(0,1)
    plt.yticks(np.linspace(0,1,4), color='gray',size=0)


    r =[]
    for i,c in enumerate(categories):
       
        if new_ov[i] == data_ov['metrics'][i]:
            r.append([round(ranges[i][0], 1),round(ranges[i][1], 1)])

        else:
  
            if i != 2:
                r.append([abs(round(ranges[i][1], 1)),abs(round(ranges[i][0], 1))])
            else:
                r.append([round(ranges[i][1], 1),round(ranges[i][0], 1)])


    
    plt.xticks(data_b['angles'][:-1], [f'Return(%)[{round(r[0][0], 1)} to {round(r[0][1], 1)}]',
                                       f'Volatility(%)[{round(r[1][0], 1)} to {round(r[1][1], 1)}]', 
                                       f'Max DD(%)[{round(r[2][0], 1)} to {round(r[2][1], 1)}]', 
                                       f'Info Ratio [{round(r[3][0], 1)} to {round(r[3][1], 1)}]',
                                       f'Sortino Ratio [{round(r[4][0], 1)} to {round(r[4][1], 1)}]'], size=6)

   

    plt.legend(['Optimized','Original',], loc='upper center', bbox_to_anchor=(0.5, -0.1), frameon=False, ncol=2, prop={'size': 6})

    
    ax.set_title('Metrics Spider Chart',weight='bold', fontsize=9)
    plt.tight_layout()

    return fig, ax




    ## Constituents metrics contribution
def generate_cmc_chart(c,m):


    fig = make_subplots(rows=1, cols=3,
                    specs=[[{'type':'waterfall'},{'type':'waterfall'},{'type':'waterfall'}]],
                    horizontal_spacing=0.05,
                    subplot_titles = ['Return Attribution','Volatility Contribution','VaR Contribution'])

    fig.add_trace(go.Waterfall(
                name='Returns', orientation='v',
                measure = ['relative']*len(c),
                x = c.index.tolist()+['Overlay'],
                y = c['Return'].tolist() ,
                base= 0.01
    ), row=1, col=1)


    fig.add_trace(go.Waterfall(
                name='Volatility', orientation='v',
                measure = ['relative']*len(c),
                x = c.index.tolist()+['Overlay'],
                y = c['Volatility'].tolist() ,
                base= 0.002
    ),row=1, col=2)

    fig.add_trace(go.Waterfall(
                name='VaR', orientation='v',
                measure = ['relative']*len(c),
                x = c.index.tolist()+['Overlay'],
                y = c['VaR'].tolist() ,
                base= 0.002
    ),row=1, col=3)
    for i in fig['layout']['annotations']:
        i['font'] = dict(size=9)

    fig.update_layout({'plot_bgcolor':'white'},
                    {"showgrid": True},
                    height=400,
                    showlegend=False, 
                    title_text='<b>Constituents Metrics Contribution</b>',title_x=0.5,  font=dict(size=9),
                    yaxis=dict(showgrid=True))

    fig.update_xaxes(tickangle=60, showline=True, linecolor='gray', mirror=True)
    fig.update_yaxes(showline=True, linecolor='gray', mirror=True, showgrid=True, gridcolor='lightgray',showticklabels=True)

    fig.update_traces(
        decreasing = {"marker":{"color":'#993E5C'}},
        increasing = {"marker":{"color":'#183C69'}},
        totals = {"marker":{"color":"#183C69"}},
        connector = {"mode":"between", "line":{"width":1, "color":"rgb(0, 0, 0)"}},
    opacity=0.9
    )
    fig.update_layout()


    fig.show()

def prepare_diverging_bar_data(x):
    x = x.reset_index(inplace=False)
    x['color_ir'] = colors[0]
    x['color_r'] = colors[0]

    for index, row in x.iterrows():
        if row['info_ratio'] < 0:
            x.at[index, 'color_ir'] =  colors[1]
        if row['return'] < 0:
            x.at[index, 'color_r'] =  colors[1]


    return x


def draw_bars(ax, row, col, returns, cnt, stress):
    stress_track_return = returns.loc[stress[cnt]['start_date']:stress[cnt]['end_date']]
    metrics = calc.calculate_metrics(stress_track_return)
    x=metrics.loc[:,['return','info_ratio']]
    
    x=prepare_diverging_bar_data(x)
    
    ax[row][col].hlines(y=x.index, xmin=0, xmax=x['return'], color=x['color_r'], alpha=0.8, linewidth=5)
    plt.sca(ax[row][col])
    plt.grid(axis='y', alpha=0.4)
    plt.axvline(x=0, color='gray', linestyle='-', alpha=0.5)
    plt.gca().update(dict(title= '{}'.format(stress[cnt]['name'])))
    plt.yticks(x.index, x['index'], fontsize=12)
    

        

def generate_diverging_bars(returns):

    stress = calc.get_stress_periods()
    
    plt.style.use('default')
    
    
    num_cols = 3
    num_rows = math.ceil(len(stress)/num_cols)
    
    fig, ax = plt.subplots(nrows = num_rows, ncols=num_cols, figsize=(16,4),sharey=True)
    

    for i, period in enumerate(stress):

        if i>=0 and i<=2:
            row = 0
            col = i-(num_cols*row)
            draw_bars(ax,row,col,returns,i,stress)
        elif i>2 and i<=5:
            row=1
            col = i-(num_cols*row)
            draw_bars(ax,row,col,returns,i,stress)
        elif i>5 and i<=8:
            row=2
            col = i-(num_cols*row)
            draw_bars(ax,row,col,returns,i,stress)
        elif i>8 and i<=11:
            row=3
            col = i-(num_cols*row)
            draw_bars(ax,row,col,returns,i,stress)
        elif i>11 and i<=14:
            row=4
            col = i-(num_cols*row)
            draw_bars(ax,row,col,returns,i,stress)
        elif i>14 and i<=17:
            row=5
            col = i-(num_cols*row)
            draw_bars(ax,row,col,returns,i,stress)
        elif i>17 and i<=20:
            row=6
            col = i-(num_cols*row)
            draw_bars(ax,row,col,returns,i,stress)
        elif i>20 and i<=23:
            row=7
            col = i-(num_cols*row)
            draw_bars(ax,row,col,returns,i,stress)
        elif i>23 and i<=26:
            row=8
            col = i-(num_cols*row)
            draw_bars(ax,row,col,returns,i,stress)                
    
    fig.suptitle('Constituents Returns in Stress Periods', weight='bold')
    diff = (num_rows*num_cols) - len(stress)
    for j in range(diff):
        fig.delaxes(ax[num_rows-1][(num_cols-1)-j])
    
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])    
    plt.show()
    


def generate_metrics_move(x_ir,x_r ,y, title):
    plt.style.use('seaborn-white')
    
    fig, ax = plt.subplots(nrows=1, ncols=2, sharey=True, figsize=(16,6))
    
    ax[0].plot(x_ir, [i for i in range(0,len(y))], 'o-.',markersize=12, alpha=0.8, markerfacecolor= 'k', color='gray',markeredgecolor='#123B69', linewidth=0.5)
    ax[1].plot(x_r, [i for i in range(0,len(y))], 's-.',markersize=12, alpha=0.8, markerfacecolor='#4E849F', markeredgecolor='#123B69', color='gray', linewidth=0.5)
    
    plt.sca(ax[0])
    plt.gca().set(xlabel='$Info Ratio$')
    plt.grid(True, alpha=0.2)
    
    plt.sca(ax[1])
    plt.gca().set(xlabel='$Returns$')
    plt.grid(True, alpha=0.2)
    
    plt.yticks([i for i in range(0,len(y))], y, fontsize=12)
    
 
    fig.suptitle(title)
    
    plt.tight_layout()    
    
    return fig, ax
    
    
    
def sub_plot(ax, overlay_track, benchmark_track, row, col, cnt, stress):
    
    ov = overlay_track.loc[stress[cnt]['start_date']:stress[cnt]['end_date']]
    b = benchmark_track.loc[stress[cnt]['start_date']:stress[cnt]['end_date']]
    
    ov = calc.ratio_return(calc.log_return(ov))
    b = calc.ratio_return(calc.log_return(b))
    
    ax[row][col].plot(ov, color='#183C69', linewidth=1.5)
    ax[row][col].plot(b, color='#993E5C', linewidth=1.5)
    
    ax[row][col].spines['top'].set_visible(False)
    ax[row][col].spines['right'].set_visible(False)
    ax[row][col].spines['bottom'].set_visible(False)

    
    plt.sca(ax[row][col])
    plt.gca().update(dict(title= '{}'.format(stress[cnt]['name'])))
    plt.xticks([])
    plt.yticks([])
    plt.axhline(y=100, color='gray', linestyle='dashed', alpha=0.5)
    plt.grid(False)

    
    
def generate_stress_comparison_charts(overlay_track, benchmark_track, stress):
    
    plt.style.use('seaborn-white')

    num_rows = math.ceil(len(stress)/4)
    num_cols = 4
    fig, ax = plt.subplots(nrows = num_rows, ncols=num_cols, figsize=(16,8), sharex=False, sharey=False)
    

    for i, period in enumerate(stress):

        if i>=0 and i<=3:
            row = 0
            col = i-(4*row)
            sub_plot(ax, overlay_track, benchmark_track, row, col, i, stress)
        elif i>3 and i<=7:
            row=1
            col = i-(4*row)
            sub_plot(ax, overlay_track, benchmark_track, row, col, i, stress)
        elif i>7 and i<=11:
            row=2
            col = i-(4*row)
            sub_plot(ax, overlay_track, benchmark_track, row, col, i, stress)
        elif i>11 and i<=15:
            row=3
            col = i-(4*row)
            sub_plot(ax, overlay_track, benchmark_track, row, col, i, stress)
        elif i>16 and i<=19:
            row=4
            col = i-(4*row)
            sub_plot(ax, overlay_track, benchmark_track, row, col, i, stress)
        elif i>19 and i<=23:
            row=5
            col = i-(4*row)
            sub_plot(ax, overlay_track, benchmark_track, row, col, i, stress)
        elif i>23 and i<=27:
            row=6
            col = i-(4*row)
            sub_plot(ax, overlay_track, benchmark_track, row, col, i, stress) 
            
        elif i>27 and i<=31:
            row=7
            col = i-(4*row)
            sub_plot(ax, overlay_track, benchmark_track, row, col, i, stress) 
            
        elif i>31 and i<=35:
            row=8
            col = i-(4*row)
            sub_plot(ax, overlay_track, benchmark_track, row, col, i, stress) 


    
    
    fig.suptitle('Overlay vs Benchmark in Stress Periods', weight='bold')
    fig.legend(['Overlay','Core'], ncol=2, loc='lower center',bbox_to_anchor=(0.4,-0.01))
    diff = (num_rows*num_cols) - len(stress)
    for j in range(diff):
        fig.delaxes(ax[num_rows-1][(num_cols-1)-j])
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])    
    

    
    plt.show()
    
def scatter(ax, hedge, benchmark, row,  col, cnt, stress):
    h_ret = hedge.loc[stress[cnt]['start_date']:stress[cnt]['end_date']]
    b_ret = benchmark.loc[stress[cnt]['start_date']:stress[cnt]['end_date']]
    
    ax[row][col].plot(b_ret, h_ret, 'o',   c='#183C69', alpha=0.4, zorder=2.5)
    m,b=np.polyfit(b_ret,h_ret,1)
    ax[row][col].plot(b_ret, m*b_ret + b,color='k', linewidth=0.7)
    
    ax[row][col].spines['top'].set_visible(False)
    ax[row][col].spines['right'].set_visible(False)
    
    plt.sca(ax[row][col])
    plt.gca().update(dict(title=stress[cnt]['name']))
    plt.xticks([])
    plt.yticks([])
    plt.axhline(y=0, color='gray', linestyle='dashed', alpha=0.5)
    plt.axvline(x=0, color='gray', linestyle='dashed', alpha=0.5)


def generate_scatter_stress_plots(x,y, stress):
    plt.style.use('seaborn-white')
    
    df = pd.concat((x,y), axis=1).fillna(method='ffill')
    df.columns = ['x','y']
   
    num_rows = math.ceil(len(stress)/4)
    num_cols = 4
    fig, ax = plt.subplots(nrows = num_rows, ncols=num_cols, figsize=(16,8), sharex=False, sharey=False)
    

    for i, period in enumerate(stress):

        if i>=0 and i<=3:
            row = 0
            col = i-(4*row)
            scatter(ax, df['x'], df['y'], row, col, i, stress)
        elif i>3 and i<=7:
            row=1
            col = i-(4*row)
            scatter(ax, df['x'], df['y'], row, col, i, stress)
        elif i>7 and i<=11:
            row=2
            col = i-(4*row)
            scatter(ax, df['x'], df['y'], row, col, i, stress)
        elif i>11 and i<=15:
            row=3
            col = i-(4*row)
            scatter(ax, df['x'], df['y'], row, col, i, stress)
        elif i>16 and i<=19:
            row=4
            col = i-(4*row)
            scatter(ax, df['x'], df['y'], row, col, i, stress)
        elif i>19 and i<=23:
            row=5
            col = i-(4*row)
            scatter(ax, df['x'], df['y'], row, col, i, stress)
        elif i>23 and i<=27:
            row=6
            col = i-(4*row)
            scatter(ax, df['x'], df['y'], row, col, i, stress) 

    
    fig.suptitle('Returns in Stress Periods', weight='bold')
    
    
    diff = (num_rows*num_cols) - len(stress)
    for j in range(diff):
        fig.delaxes(ax[num_rows-1][(num_cols-1)-j])
    # fig.delaxes(x[2][2])
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])    
    plt.show()

    
    
def generate_scatter_plot(x, y, labels, title, x_stress=None, y_stress=None):
    plt.style.use('seaborn-white')

    df = pd.concat((x,y), axis=1).fillna(method='ffill')
    df.columns = ['x','y']

    df2 = pd.concat((x_stress,y_stress), axis=1).fillna(method='ffill')
    df2.columns = ['x2','y2']


    df = df.drop(df2.index, axis=0) ## removing stress rows
    
    stress_ir = calc.calculate_benchmarked_info_ratio(df2['x2'].to_numpy().reshape(-1,1), df2['y2'].to_numpy().reshape(-1,1))
    nonstress_ir = calc.calculate_benchmarked_info_ratio(df['x'].to_numpy().reshape(-1,1), df['y'].to_numpy().reshape(-1,1))
    
    fig, ax = plt.subplots(figsize=(15,6), nrows=1, ncols=2, sharey=True, sharex=True)
    fig.suptitle('Optimized Returns vs Core', weight='bold')

    
    ax[1].plot(df['x'],df['y'], 'o', c='#993E5C', label='Normal Periods', alpha=0.4, zorder=2.5)
    m,b = np.polyfit(df['x'],df['y'], 1)
    ax[1].plot(df['x'], m*df['x'] + b,color='k', zorder=3.5)
   

    ax[0].plot(df2['x2'], df2['y2'], 'o', c='#183C69', label='Stress Periods', alpha=0.4, zorder=2.5)
    m,b = np.polyfit(df2['x2'],df2['y2'], 1)
    ax[0].plot(df2['x2'], m*df2['x2'] + b, color='k', zorder=3.5)

    

    plt.sca(ax[0])
    plt.gca().update(dict(title='Stress Periods', xlabel='$'+labels[0]+'$', ylabel='$'+labels[1]+'$'))
    plt.axhline(y=0, color='gray', linestyle='dashed', alpha=0.5)
    plt.axvline(x=0, color='gray', linestyle='dashed', alpha=0.5)
    plt.legend()

    plt.sca(ax[1])
    plt.gca().update(dict(title='Normal Periods', xlabel='$'+labels[0]+'$'))
    plt.axhline(y=0, color='gray', linestyle='dashed', alpha=0.5)
    plt.axvline(x=0, color='gray', linestyle='dashed', alpha=0.5)
    
    plt.legend()
    
    for a in ax.reshape(-1):
        a.spines['top'].set_visible(False)
        a.spines['right'].set_visible(False)
       
    
    plt.tight_layout(rect=[0, 0.03, 1, 0.95]) 

    plt.show()


    # print('\t\t\t\t\t\t \033[1m Hedge Info Ratio \033[0m')
    # print('\t\t\t\033[1m Stress Periods \033[0m \t {}'.format(stress_ir))
    # print('\t\t\t\033[1m Normal Periods \033[0m \t {}'.format(nonstress_ir))


    
    print('\t\t\t\t\t \033[1m     Stress \033[0m \t\t\t \033[1m     Normal \033[0m')
    print('\t\t\033[1m Overlay Info Ratio\033[0m \t {} \t\t {}'.format(stress_ir, nonstress_ir))

    
    
    

def get_stress_values(returns, metric, stress_periods):
    vals = []
    for i in stress_periods:
        ret = returns.loc[i['start_date'] : i['end_date']]
        metrics = calc.calculate_metrics(ret)[metric][0]
        vals.append(metrics)
    
    return vals




def prepare_stress_dumbell_plot(vol, ret, ir, stress):
      
    plt.style.use('seaborn-white')
    fig, ax = plt.subplots(ncols=3,nrows=1,figsize=(16,6), sharey=True)
    
    
    
    dumbell_sub_plot(ax, 0, ret, 'Return', stress)
    dumbell_sub_plot(ax, 1, vol, 'Volatility', stress)
    dumbell_sub_plot(ax, 2, ir, 'Info Ratio', stress)
       
    # plt.title('Out of Sample Stress Period Comparison', weight='bold')
    fig.suptitle('Stress Period Metrics Comparison', weight='bold')
    
    for a in ax.reshape(-1):
        a.spines['top'].set_visible(False)
        a.spines['right'].set_visible(False)
        a.spines['left'].set_visible(False)
    
    
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.show()
    
        
def dumbell_sub_plot(ax, col,result, metric, stress_periods):
    # stress_periods = np.flip(calc.get_stress_periods())
    # y = np.arange([1, len(stress_periods)])
    
    for i,period in enumerate(stress_periods):
      
        benchmark = result[1][i]
        overlay = result[0][i]
        
        if metric == 'Volatility':
            if overlay < benchmark:
                color='#006400'
            else:
                color='darkred'
       
                
        else:
            if overlay < benchmark:
                color='darkred'
           
            else:
                color='#006400'

        
        # print('Metric: {}'.format(metric))
        # print('\t Dist: {}'.format(benchmark-Optimization))
        # l = mlines.Line2D([benchmark, Optimization],[i], color=color, alpha=0.6, linewidth=3.5)
        # ax[col].add_line(l)
        arrow = FancyArrowPatch(posB = (overlay, i),
                                posA = (benchmark, i),
                                arrowstyle='->', color=color,mutation_scale=20, lw=2, alpha=0.6, shrinkB=5)
        ax[col].add_patch(arrow)
        # ax[col].arrow(x=benchmark, y=i,dx=dx,dy=0, color=color, width = 0.05, length_includes_head=False,head_width=1, overhang=-0.1)
            
        # else:
        #     ax[col].arrow(x=benchmark, y=i,dx=(Optimization-benchmark),dy=0)
        if i == 0 and metric=='Volatility':
            ax[col].scatter(y=i, x=benchmark, color='#993E5C', s=210, label='Core', zorder=2.5)
            ax[col].scatter(y=i, x=overlay, color='#183C69', s=210, label='Optimized', zorder=2.5)
            
            ax[col].legend(ncol=2,loc='upper center', bbox_to_anchor=(0.5, -0.1), frameon=False)
        else:
            ax[col].scatter(y=i, x=benchmark, color='#993E5C', s=210,zorder=2.5)
            ax[col].scatter(y=i, x=overlay, color='#183C69', s=210, zorder=2.5)
            
            
    ax[col].axvline(x=0, alpha=0.6, color='lightgray', linestyle='dashed')
    ax[col].set_title(metric)
    ax[col].set_yticks(range(len(stress_periods)))
    ax[col].set_yticklabels([period['name'] for period in stress_periods])
    ax[col].grid(axis='y', alpha=0.3)





def generate_data_pie(data):
    s = data['style'].value_counts().reset_index()
    r = data['region'].value_counts().reset_index()
    f = data['factor'].value_counts().reset_index()
    ac = data['assetclass'].value_counts().reset_index()
    pr = data['provider'].value_counts().reset_index()
    rt = data['returntype'].value_counts().reset_index()


    fig = make_subplots(rows=2,cols=3, 
                        specs=[[{'type':'pie'},{'type':'pie'},{'type':'pie'}],
                            [{'type':'pie'},{'type':'pie'},{'type':'pie'}]],
                        subplot_titles = ['Style','Region','Factor','Asset Class', 'Provider', 'Return Type'],
                        
                    )

    fig.add_trace(go.Pie(labels=s['index'].tolist(), values=s['style'].tolist()), 1, 1)
    fig.add_trace(go.Pie(labels=r['index'].tolist(), values=r['region'].tolist()), 1, 2)
    fig.add_trace(go.Pie(labels=f['index'].tolist(), values=f['factor'].tolist()), 1, 3)
    fig.add_trace(go.Pie(labels=ac['index'].tolist(), values=ac['assetclass'].tolist()), 2, 1)
    fig.add_trace(go.Pie(labels=pr['index'].tolist(), values=pr['provider'].tolist()), 2, 2)
    fig.add_trace(go.Pie(labels=rt['index'].tolist(), values=rt['returntype'].tolist()), 2, 3)



    fig.update_layout(showlegend=False,title_text='<b>Constituents Information</b>',title_x=0.5,  font=dict(size=9),margin = dict(l=0, r=0, b=0))
    fig.update_traces(hole=0.2,textposition='inside', textinfo='value+label', marker=dict(colors=colors), opacity=0.9)

    for i in fig['layout']['annotations']:
        i['font'] = dict(size=9)
        
    fig.show()    
    
    
def generate_correlation_scatter(core_returns, ind_returns):
    cols = 3
    rows = math.ceil(len(ind_returns.columns)/cols)

    fig, ax = plt.subplots(figsize=(16,8), ncols=cols, nrows=rows, sharex=True)

    row_indices = []
    for i in range(rows):
        row_indices += ([i]*cols)

    for j,strat in enumerate(ind_returns.columns):
        row = row_indices[j]
        col = j-(cols*row)
        
        y = ind_returns.iloc[:,j].tolist()
        x = core_returns['portfolio_return'].tolist()
        if rows == 1:

            ax[col].scatter(x, y, zorder=2.5,c=colors[0], edgecolors='#F0F1F3')
        #   m,b = np.polyfit(x, y, 1)
        #   ax[row][col].plot(x, (m*y) +1, colr='k', linestyle='-')
            plt.sca(ax[col])
        else:
            ax[row][col].scatter(x, y, zorder=2.5,c=colors[0], edgecolors='#F0F1F3')
            plt.sca(ax[row][col])
        plt.gca().update(dict(title='${}$'.format(strat)))
        plt.xticks([])
        plt.yticks([])
        plt.ylabel('Overlay')
        plt.xlabel('Core')
        plt.axhline(y=0, color='gray', linestyle='dashed', alpha=0.5)
        plt.axvline(x=0, color='gray', linestyle='dashed', alpha=0.5)
    
    fig.suptitle('Correlation - Overlay Constitutents vs Core Portfolio', weight='bold')
        
        
    diff = (cols*rows) - len(ind_returns.columns)
    for j in range(diff):
        fig.delaxes(ax[row_indices[-1]][(cols-1)-j])

    # plt.tight_layout(rect=[0, 0.03, 1, 0.95])    
        
    plt.show()

def correlation_matrix(ind_returns, core):
    plt.style.use('seaborn-white')
    f, ax = plt.subplots(figsize=(8, 8))
    cm = sns.diverging_palette(220,10, n=49, as_cmap=True)
    cols = [plb_universe.code(i).data[0]['shortName'] for i in ind_returns.corr().columns]
    sns.heatmap(ind_returns.resample('W-FRI').sum().corr(), xticklabels=cols, yticklabels=cols,cmap=cm,center=0,ax=ax, annot=True, annot_kws={"fontsize":8,"rotation":45})
    x = 0
    y = 0
    ax.add_patch(Rectangle((x,y), len(core.tickers), len(core.tickers), fill=False, edgecolor=colors[1], lw=2))

    x=len(core.tickers)
    y=len(core.tickers)
    ax.add_patch(Rectangle((x,y), len(ind_returns.columns) - len(core.tickers), len(ind_returns.columns) - len(core.tickers), fill=False, edgecolor=colors[0], lw=2))

    names = [plb_universe.code(i).data[0]['shortName'] for i in core.tickers.tolist()]

    for l in ax.xaxis.get_ticklabels():
   
        if l.get_text() in names:
            l.set_color(colors[1])
        else:
            l.set_color(colors[0])
    for l in ax.yaxis.get_ticklabels():
   
        if l.get_text() in names:
            l.set_color(colors[1])
        else:
            l.set_color(colors[0])

    plt.title('Optimized Portfolio Constituents Correlation Matrix', weight='bold', fontsize=10)
    plt.sca(ax)
    plt.xticks(rotation=90, fontsize=7)
    plt.yticks(rotation=0, fontsize=7)
    plt.tight_layout()
    
    return f, ax
    


def generate_overall_kde_plot(ov,c):
    plt.style.use('seaborn-white')
    fig,ax=plt.subplots(figsize=(16,6), nrows=1, ncols=2, gridspec_kw={'width_ratios': [3, 1]})


    ax[0] = sns.distplot(ov, hist=False,kde_kws={"color": '#183C69', "lw": 1.5, "label": "Optimized","zorder":3.5, 'shade':True}, ax=ax[0])
    ax[0] = sns.distplot(c, hist=False,kde_kws={"color": '#993E5C', "lw": 1, "label": "Core","zorder":3, 'shade':True}, ax=ax[0])
   


    ax[0].grid(axis='x', alpha=0.2)

    ax[0].set_yticklabels([])
    ax[0].set_yticks([])

    ax[0].spines['right'].set_visible(False)
    ax[0].spines['top'].set_visible(False)
    ax[0].spines['left'].set_visible(False)
    
    ax[0].set_title('KDE Plot', weight='bold', fontsize=9)
    ax[0].legend(loc='upper center', bbox_to_anchor=(0.5, -0.05), frameon=False, ncol=2, fontsize=9)
    ax[0].axvline(x=np.std(c.values),linestyle='-.',color='#993E5C',linewidth=0.8, alpha=0.4, zorder=2)
    ax[0].axvline(x=np.std(ov.values),linestyle='-.',color='#183C69',linewidth=0.8, alpha=0.4,zorder=2)

    ax[0].axvline(x=-np.std(c.values),linestyle='-.',color='#993E5C',linewidth=0.8, alpha=0.4,zorder=2)
    ax[0].axvline(x=-np.std(ov.values),linestyle='-.',color='#183C69',linewidth=0.8, alpha=0.4,zorder=2)


    # data=ov.resample('M').mean()
    # data2 = c.resample('M').mean()
    bp = ax[1].boxplot(np.append(ov.values[1:], c.values[1:], axis=1),
                    widths=0.6, 
                    labels=['Optimized','Core'],  
                    vert=True,showfliers= 0.05, 
                    showmeans=True,
                    patch_artist=True)

    for patch,color in zip(bp['boxes'],colors):
        patch.set_facecolor(color)

    
    
    for median in bp['medians']: 
        median.set(color ='#F0F1F3', 
                linewidth = 1.5) 

        
    for whisker in bp['whiskers']: 
        whisker.set(color ='#5A5A5A', 
                    linewidth = 1, 
                    linestyle ="-") 
        
    for cap in bp['caps']: 
        cap.set(color ='#5A5A5A', 
                linewidth = 1) 
        
        
    ax[1].grid(False)
    ax[1].spines['right'].set_visible(False)
    ax[1].spines['top'].set_visible(False)
    ax[1].spines['bottom'].set_visible(False)
    ax[1].axhline(y=0, color='gray', linestyle='dashed', alpha=0.5)


    ax[1].set_title('Returns Box Plot', weight='bold', fontsize=9)
    plt.tight_layout()
    return fig, ax



def generate_stress_kde_plots(ov,c, sd):
    stress_dates = sd

    plt.style.use('seaborn-white')

    s_ov = calc.subset_returns(ov.values.reshape(-1,), stress_dates, ov.index.to_numpy())
    s_c = calc.subset_returns(c.values.reshape(-1,), stress_dates, c.index.to_numpy())
                            
    n_ov = np.setdiff1d(ov.values.reshape(-1,),s_ov)
    n_c = np.setdiff1d(c.values.reshape(-1,),s_c)
                            
    fig,ax=plt.subplots(figsize=(12,5), nrows=1, ncols=2,sharex=True)


    ax[0] = sns.distplot(s_ov, hist=False,kde_kws={"color": '#183C69','label':'Optimized', "lw": 1.5,"zorder":3.5, 'shade':True},ax = ax[0])
    ax[0] = sns.distplot(s_c, hist=False,kde_kws={"color": '#993E5C', "lw": 1,'label':'Core', "zorder":3,'shade':True}, ax = ax[0])


    ax[0].set_yticklabels([])
    ax[0].set_yticks([])

    ax[0].grid(axis='x', alpha=0.1)
    # ax[0].get_legend().remove()

    ax[0].set_title('Stress Periods', fontsize=9)
    plt.sca(ax[0])
    plt.axvline(x=np.std(s_c),linestyle='-.',color='#993E5C',linewidth=0.8, alpha=0.4, zorder=2)
    plt.axvline(x=np.std(s_ov),linestyle='-.',color='#183C69',linewidth=0.8, alpha=0.4,zorder=2)
    plt.axvline(x=-np.std(s_c),linestyle='-.',color='#993E5C',linewidth=0.8, alpha=0.4, zorder=2)
    plt.axvline(x=-np.std(s_ov),linestyle='-.',color='#183C69',linewidth=0.8, alpha=0.4,zorder=2)




    ax[1] = sns.distplot(n_ov, hist=False,kde_kws={"color": '#183C69', "lw": 1.5,"zorder":3.5, 'shade':True},ax = ax[1])
    ax[1] = sns.distplot(n_c, hist=False,kde_kws={"color": '#993E5C', "lw": 1,"zorder":3,'shade':True}, ax = ax[1])


    ax[1].set_yticklabels([])
    ax[1].set_yticks([])

    ax[1].grid(axis='x', alpha=0.1)

    ax[1].set_title('Normal Periods', fontsize=9)
    plt.sca(ax[1])
    plt.axvline(x=np.std(n_c),linestyle='-.',color='#993E5C',linewidth=0.8, alpha=0.4, zorder=2)
    plt.axvline(x=np.std(n_ov),linestyle='-.',color='#183C69',linewidth=0.8, alpha=0.4,zorder=2)
    plt.axvline(x=-np.std(n_c),linestyle='-.',color='#993E5C',linewidth=0.8, alpha=0.4, zorder=2)
    plt.axvline(x=-np.std(n_ov),linestyle='-.',color='#183C69',linewidth=0.8, alpha=0.4,zorder=2)

    fig.suptitle('KDE Plots', weight='bold', fontsize=10)
    
    for a in ax.reshape(-1):
        a.spines['top'].set_visible(False)
        a.spines['right'].set_visible(False)
        a.spines['left'].set_visible(False)
    fig.legend(loc='lower center',bbox_to_anchor=(0.5,-0.01), frameon=False, ncol=2, fontsize=9)


    plt.tight_layout(rect=[0, 0.03, 1, 0.95])

    plt.show()   

def daily_return_attribution(c_r, ov, **kwargs):
    plt.style.use('default')
    plt.style.use('seaborn-white')

    daily_returns = np.log((np.e**c_r.cumsum()).resample("M").last()).diff().fillna(method='ffill').fillna(0.0)
    ov_daily = np.log((np.e**ov.cumsum()).resample("M").last()).diff().fillna(method='ffill').fillna(0.0)

    daily_returns.index= pd.to_datetime(daily_returns.index).strftime('%Y-%m')
    ov_daily.index= pd.to_datetime(ov_daily.index).strftime('%Y-%m')

    daily_returns.columns = [plb_universe.code(i).data[0]['shortName'] for i in daily_returns.columns]
    fig, ax = plt.subplots(figsize=(18,12), nrows=2, ncols=1)


    ax[0] = daily_returns.plot(kind='bar', stacked=True,width = 0.9,  color=colors, ax=ax[0], zorder=2.5)
    ax[0].get_legend().remove()
    ax[0].spines['right'].set_visible(False)
    ax[0].spines['top'].set_visible(False)
    ax[0].spines['bottom'].set_visible(False)
    # ax[0].legend(loc='upper center', bbox_to_anchor=(0.5, -0.05), frameon=False, ncol=len(c_r.columns))
    ax[0].grid(axis='y', alpha=0.3)
    ax[0].set_title('Monthly')
    ax[0].set_xticks([])
    ax[0].set_xticklabels([])

    # ov.cumsum().plot(color='k',linewidth=2.5, label='Overlay', zorder=2.5, ax=ax[1])
    
    daily_returns.cumsum().plot(kind='bar', stacked=True,width = 0.9,  color=colors, ax=ax[1], zorder=2.5)
   
    ax[1].legend(loc='upper center', bbox_to_anchor=(0.5, -0.22), frameon=False, ncol=3)
    ax[1].grid(axis='y', alpha=0.3)
    ax[1].set_title('Cumulated')
    # ax[1].locator_params('x', nbins=20)
    ax[1].set_xticklabels(daily_returns.index, rotation = 90)
    ax[1].spines['right'].set_visible(False)
    ax[1].spines['top'].set_visible(False)

    for a in ax.reshape(-1):
        yticks = a.get_yticks()
        yticks = list(map(lambda x: str(int(x*100))+'%', yticks))
        a.set_yticklabels(yticks)

    fig.suptitle('Return Attribution',weight='bold')
    plt.tight_layout()
    
    return fig, ax
    

def const_bp(c_r):
    plt.style.use('default')
    fig, ax = plt.subplots(figsize=(12,4))

    bp = ax.boxplot(c_r.values,
                    widths=0.6, 
                    labels=c_r.columns,  
                    vert=True,showfliers=False, 
                    showmeans=True,
                    patch_artist=True)

    for patch,color in zip(bp['boxes'],colors):
        patch.set_facecolor(color)

    
    
    for median in bp['medians']: 
        median.set(color ='#F0F1F3', 
                linewidth = 1.5) 

        
    for whisker in bp['whiskers']: 
        whisker.set(color ='#5A5A5A', 
                    linewidth = 1, 
                    linestyle ="-") 
        
    for cap in bp['caps']: 
        cap.set(color ='#5A5A5A', 
                linewidth = 1) 
        
        
    ax.grid(axis='y', alpha=0.3, color='lightgray')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    fig.suptitle('Returns Box Plot', weight='bold', fontsize=9)
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.show()


def pairplot(cr, diag_kind='kde'):
  
    
    g = sns.pairplot(cr,diag_kind=diag_kind, 
        kind='reg', 
        markers = '+',
        plot_kws= dict(color='#183C69'),
        diag_kws = dict(color='#183C69'))
    g.fig.suptitle('Correlation Pairplot', weight='bold', y=1.1)
    plt.tight_layout()
    # plt.title('Correlation Pair Plot', weight='bold')
    plt.show()


def generate_weight_info_pie(o,c,h):
    labels = o.tickers
    fig = make_subplots(rows=1, cols=3, 
    specs=[[{'type':'domain'}, {'type':'domain'}, {'type':'domain'}]],
    subplot_titles = ['Core (Scaled)','Hedge (Scaled)','Overlay'])
    
    fig.add_trace(go.Pie(labels=labels[0:len(c.tickers)], values = c.strategy_weights.head(1).values,textinfo='label+percent', hoverinfo='label+value'), 1,1)
    fig.add_trace(go.Pie(labels=labels[len(c.tickers):], values = h.strategy_weights.head(1).values,textinfo='label+percent', hoverinfo='label+value'), 1,2)
    fig.add_trace(go.Pie(labels=labels, values = o.strategy_weights.head(1).values, textinfo='label', hoverinfo='label+value'), 1,3)

    fig.update_traces(marker=dict(colors=colors),opacity=0.9,textposition='inside')
    
    fig.update_layout(  showlegend=False,
                        title_text='<b>Portfolio Composition</b>',title_x=0.5,  font=dict(size=9))
    for i in fig['layout']['annotations']:
        i['font'] = dict(size=9)
    # plt.title('Correlation Pairplot', weight='bold')
    fig.show()

def generate_overlay_structure(overlay, benchmark, hedge):
    df = pd.DataFrame({'center': ['Overlay']*len(overlay.tickers),
                           'mid': ['Core']*len(benchmark.tickers) + ['Hedge']*len(hedge.tickers),
                           'out': benchmark.tickers.tolist() + hedge.tickers.tolist()})


    df['values'] = (benchmark.strategy_weights.iloc[1].values.tolist()+hedge.strategy_weights.iloc[1].values.tolist())



    fig = px.sunburst(df, path=['center', 'mid', 'out'], values='values')


        # fig.data[0].marker.colors = ['#9CC5BF','#F1CECD','#967E9E','#7C97C2','#3D7650','#996699','#F2893B','#1985A1','#993E5C','#183C69']
    fig.update_layout(title_text='<b>Overlay Portfolio Structure</b>',
                        title_x=0.5,  font=dict(size=9))
    fig.update_traces(hoverinfo='label+percent root')


    fig.data[0].marker.colors = np.flip(
            np.array(colors[:len(overlay.tickers)+3]))
        # fig.update_layout(margin = dict(t=0, l=0, r=0, b=0))

    fig.show()

def mu(returns: pd.DataFrame) -> np.array:
    return (returns.mean() * 252).values

def sigma(returns: pd.DataFrame) -> np.array:
    return returns.cov().values

def ret(w, mu):
    return sum(mu * w)

def vol(w, sigma):
    return np.sqrt(w.dot(sigma).dot(w.T))

def draw_bl_efficient_frontier(hedge, core, overlay):

    plt.style.use('seaborn-white')
    assets = hedge.tickers
    ann_factor = core.annualization_factor


    mu_BL = plb.session.kwargs.get('mu_BL',None)['Expected Returns'].iloc[0:len(assets)]/100
    sigma_BL= plb.session.kwargs.get('sigma_BL',None).iloc[0:len(assets), 0:len(assets)]

    rtn = []
    vols = []

    for i in range(55000):
        # while True:
        w_star = np.random.rand(len(assets))
        w_star /= sum(w_star)

        rtn.append(ret(w_star, mu_BL))
        vols.append(vol(w_star, sigma_BL))
  

    bounds = tuple((0,1) for x in assets)
    r_bound = np.linspace(min(rtn), max(rtn), 200)
    risk = []

    for i in r_bound:
        constraints = [{'type': 'eq', 'fun': lambda x: sum(x) - 1},
                    {'type': 'eq', 'fun': lambda x: ret(x, mu_BL) - i}]
        outcome = optimize.minimize(lambda x: vol(x, sigma_BL), x0=np.ones(len(hedge.tickers))/len(hedge.tickers), constraints=constraints, bounds=bounds)  
        risk.append(outcome.fun)

    fig, ax = plt.subplots(figsize=(18,6))

    # Random Portfolios
    ax.plot(vols, rtn, 'b.',  alpha=0.01)

    # Frontier Line
    ax.plot(risk, r_bound, 'dimgrey', alpha=0.9)

    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    # ax.spines['bottom'].set_visible(False)
    

    ax.set_ylabel('$Expected$ $Returns$')
    ax.set_xlabel('$Expected$ $Volatility$')
    ax.grid(axis='x', alpha=0.4, color='lightgray')
    fig.suptitle('Efficient Frontier', weight='bold')


    # y,x = _get_expected_values(hedge)
    ef = EfficientFrontier(mu_BL, sigma_BL, (0,1))
    ef.min_volatility()
    weights = np.array(list(ef.clean_weights().values()))
    x,y = vol(weights, sigma_BL), ret(weights, mu_BL)
    ax.scatter(x, y, marker = 'x', color=colors[0], s=200, zorder=2.5, label="Overlay")

    y_core, x_core = _get_expected_values(core, ann_factor)
    ax.scatter(x_core,y_core, marker='x', s=200, zorder=2.5, color=colors[1], label='Core')


    y_overlay, x_overlay = _get_expected_values(overlay, ann_factor)
    ax.scatter(x_overlay,y_overlay, marker='x', s=200, zorder=2.5, color=colors[2], label='Optimized')

    vols = np.sqrt(np.diag(sigma_BL)).tolist()

    
    for i, strat in enumerate(mu_BL.index):
        x=vols[i]
        y=mu_BL.loc[strat]
        if i==0:
            ax.scatter(x=x, y =y, s=60, color='orange', label='Overlay Strategy')
        else:
            ax.scatter(x=x, y =y, s=60, color='orange', alpha=0.8)
        ax.annotate(strat, (x,y), color='darkorange')

    # rets = hedge.constituents_metrics()['Return']/100
    # vols = hedge.constituents_metrics()['Volatility']/100



    plt.legend(loc='upper center', bbox_to_anchor=(0.5, -0.14), frameon=False, ncol=4, fontsize=7)
    plt.tight_layout()
    return fig, ax

def metrics_move(c, o , h):

   
    # single_weight = (1-o.strategy_weights.sum(axis=1)[0])/len(h.tickers)\


    y_ir = []
    y_r = []
    y_vol = []

    b_ir = [float(c.metrics()['Information Ratio'][0])]
    b_vol = [float((c.metrics()['Volatility'][0]))]
    b_r = [float((c.metrics()['Return'][0]))]
    
    x = h.tickers
    core_ret = c.returns()
    constituents = h.constituents_returns()

    start = str(core_ret.index[0])[:-9]
    end = str(core_ret.index[-1])[:-9]
 

    for cnt, t in enumerate(x):
        # hedge_returns = constituents.iloc[:, 0:cnt+1]
        # port_ret = pd.concat((core_ret, hedge_returns), axis=1).fillna(0.0, limit=20).dropna()
        weights = {}
        for ticks in x[0:cnt+1]:
            weights[ticks] = float(o.constituents_data().loc[ticks, 'weight'])

        for ticks in c.constituents_data().index.tolist():
            weights[ticks] = float(c.constituents_data().loc[ticks, 'weight'])
 

        current_pf_universe = plb_universe.code(c.constituents_data().index.tolist()).union(plb_universe.code(x[0:cnt+1]))
        w = [weights[fund_ticker] for fund_ticker in current_pf_universe.codes]
     
        curr_pf = plb.Portfolio(universe = current_pf_universe).set_start(start).set_end(end).set_fixed_weight(w, 'D').set_return_interval('Daily')
        curr_pf = curr_pf.run_backtest()

        ret = curr_pf.result.static_metric['Return']
        vol = curr_pf.result.static_metric['Volatility']
        info_ratio = curr_pf.result.static_metric['Information Ratio']
        
    
        # weights = np.array([1]+[1/len(x)]*len(hedge_returns.columns.tolist()))
 
        # port_ret = np.multiply(port_ret, weights).sum(axis=1).values

        # ret = (np.mean(port_ret)*252)
        # vol = (np.std(port_ret)*np.sqrt(252))
        # info_ratio = ret/vol

        y_ir.append(info_ratio[0])
        y_r.append(ret[0])
        y_vol.append(vol[0])


    plt.style.use('seaborn-white')
    fig, ax = plt.subplots(figsize=(16,6), nrows=1, ncols=3)
    ax[0].scatter(y = (['benchmark']+h.tickers.tolist())[::-1], x=(b_ir+y_ir)[::-1], s=120, zorder=2.5, c=[colors[0]]*len(h.tickers) + [colors[1]])
    ax[0].set_title('$Info$ $Ratio$')

    ax[0].set_yticklabels((['Core Portfolio'] + ['Add '+i for i in h.tickers])[::-1])
    ax[0].set_ylabel('$Greedy$ $Search$ $Iteration$')


    ax[1].scatter(y = (['benchmark']+h.tickers.tolist())[::-1], x=(b_vol+y_vol)[::-1], s=120,zorder=2.5, c=[colors[0]]*len(h.tickers) + [colors[1]])
    ax[1].set_xticklabels([round(i,4) for i in ax[1].get_xticks()])
    ax[1].set_title('$Volatility$')
    ax[1].set_yticklabels([])

    ax[2].scatter(y = (['benchmark']+h.tickers.tolist())[::-1], x=(b_r+y_r)[::-1], s=120, zorder=2.5, c=[colors[0]]*len(h.tickers) + [colors[1]])
    ax[2].set_title('$Return$')
    ax[2].set_yticklabels([])


    for cnt,a in enumerate(ax.reshape(-1)):
        
        if cnt == 0:
            a.grid(axis='y', alpha=0.4, color='lightgray')
      
          
            
            arr = b_ir+y_ir
            y = np.linspace(0 ,len(arr)-1, len(arr))[::-1]

            y_pos = len(h.tickers) - np.argmax(arr)

            a.axhline(y = y_pos, color='orange', linestyle='--')
            a.annotate('Max Info Ratio',(arr[0],y_pos+0.1), color='orange')

            for x, (i,val) in enumerate(zip(y, arr)):
                if x==0:
                    continue
                arrow = FancyArrowPatch(posB = (val, i),
                                posA = (arr[x-1], y[x-1]),
                                arrowstyle='-|>', color='darkgreen' if arr[x-1] < val else 'darkred',mutation_scale=20,  alpha=0.6, shrinkB=5)
                a.add_patch(arrow)


        elif cnt == 1:
            a.set_yticks([])
            a.spines['left'].set_visible(False)
            arr = b_vol+y_vol
            y = np.linspace(0 ,len(arr)-1, len(arr))[::-1]

            y_pos = len(h.tickers) - np.argmin(arr)
            
            a.axhline(y = y_pos, color='orange', linestyle='--')

            a.annotate('Min Vol',(arr[0],y_pos+0.1), color='orange')

            for x, (i,val) in enumerate(zip(y, arr)):
                a.axhline(y=i, color='lightgray', alpha=0.3)
                if x==0:
                    continue
                arrow = FancyArrowPatch(posB = (val, i),
                                posA = (arr[x-1], y[x-1]),
                                arrowstyle='-|>', color='darkgreen' if arr[x-1] > val else 'darkred',mutation_scale=20, alpha=0.6, shrinkB=5)
                a.add_patch(arrow)


        elif cnt == 2:
            a.set_yticks([])
            a.spines['left'].set_visible(False)
            arr = b_r+y_r
            y = np.linspace(0 ,len(arr)-1, len(arr))[::-1]
            y_pos = len(h.tickers) - np.argmax(arr)

            a.axhline(y = y_pos, color='orange', linestyle='--')
            a.annotate('Max Return',(arr[0],y_pos+0.1), color='orange')

            for x, (i,val) in enumerate(zip(y, arr)):
                a.axhline(y=i, color='lightgray', alpha=0.3)
                if x==0:
                    continue
                arrow = FancyArrowPatch(posB = (val, i),
                                posA = (arr[x-1], y[x-1]),
                                arrowstyle='-|>', color='darkgreen' if arr[x-1] < val else 'darkred',mutation_scale=20,  alpha=0.6, shrinkB=5)
                a.add_patch(arrow)

        a.spines['right'].set_visible(False)
        a.spines['top'].set_visible(False)
        a.spines['left'].set_visible(False)
        if cnt in [1,2]:
            # xticks = a.get_xticks()
            # xticks = list(map(lambda x: str(round(float(x),2))+'%', xticks))
            # a.set_xticklabels(xticks)
            fig.suptitle('Metrics Movement', weight='bold')
                
    fig.suptitle('Metrics Movement', weight='bold')
    # legend = [Line2D([0],[0], color=colors[1], marker='o',label='Core'), 
    #           Line2D([0],[0], color=colors[0], marker='o',label='Overlay')]

    # fig.legend(handles=legend,loc='upper center', bbox_to_anchor=(0.5, 0.04),  frameon=False, ncol=2 )
    # plt.tight_layout()
    return fig, ax



# def _get_expected_values(pf):
#     f= open('data/processed/views.pickle', 'rb')
#     views = pickle.load(f)
#     f.close()
#
#     blm = BlackLittermanMeucci(portfolio = pf, views = views)
#     c_r, c_cov = blm.compute_expected()
#
#     weights = pf.strategy_weights.iloc[-1].values
#     c_r = c_r['Expected Returns'].iloc[0:len(pf.tickers)]/100
#     c_cov = c_cov.iloc[0:len(pf.tickers), 0:len(pf.tickers)]
#
#     return ret(weights, c_r), vol(weights, c_cov)

def _get_expected_values(pf, ann_factor=252):
    views = plb.session.kwargs.get('bl_views',None)
    if views is not None:
        blm = BlackLittermanMeucci(portfolio = pf, views = views, annualization_factor=ann_factor)
        c_r, c_cov = blm.compute_expected()
    else:
        c_r = pd.DataFrame(np.mean(pf.constituents_returns()) * ann_factor,
                          columns=['Expected Returns']) * 100
        c_cov = pf.constituents_returns().cov() * ann_factor
    
    weights = pf.strategy_weights.iloc[-1].values
    c_r = c_r['Expected Returns'].iloc[0:len(pf.tickers)]/100
    c_cov = c_cov.iloc[0:len(pf.tickers), 0:len(pf.tickers)]
    
    return ret(weights, c_r), vol(weights, c_cov)


def expected_returns(c,o,h, ann_factor=252):
    mu, voll = _get_expected_values(h, ann_factor)
    cer, cev  = _get_expected_values(c, ann_factor)
    over, ovev = _get_expected_values(o, ann_factor)

    plt.style.use('seaborn-white')
    fig, ax = plt.subplots(figsize=(7,5))


    x = np.linspace(cer - 3*cev, cer + 3*cev, 500)
    s = stats.norm.pdf(x, cer, cev)
    ax.plot(x, s, color='#993E5C', label='Core')
    
    
    x = np.linspace(mu - 3*voll, mu + 3*voll, 500)
    s = stats.norm.pdf(x, mu, voll)
    ax.plot(x, s, color='#183C69', label='Overlay')

    x = np.linspace(over - 3*ovev, over + 3*ovev, 500)
    s = stats.norm.pdf(x, over, ovev)
    ax.plot(x, s, color='#1985A1', label='Optimized')



    ax.annotate(f'Overlay\nSD:{round(voll*100,2)}%\nMean: {round(mu*100,2)}%', xytext=(0.2, 3.75), xy=(mu+voll+0.01,4),
            color='#183C69', fontsize=8)

    ax.annotate(f'Core\nSD:{round(cev*100,2)}%\nMean: {round(cer*100,2)}%', xytext=(0.2, 5.75), xy=(cer+cev-0.01,6),
           
            color='#993E5C', fontsize=8)

    ax.annotate(f'Optimized\nSD:{round(ovev*100,2)}%\nMean: {round(over*100,2)}%', xytext=(0.2, 1.75), xy=(over+ovev+0.03,2),
           
            color='#1985A1', fontsize=8)

    ax.set_title('Expected Returns', weight='bold', fontsize=10) 
    # ax.set_ylim(-0.5,9.5)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['left'].set_visible(False)
    ax.axvline(x=0, color='gray', alpha=0.5, linestyle='--')
    # ax.grid(color='lightgray', alpha=0.3)
    ax.set_yticks([])
    # xticks = ax.get_xticks()
    
    # xticks = [f'{str(round(x*100,2))}%' for x in xticks]
    # ax.set_xticklabels(xticks, fontsize=6)
    ax.set_xlabel('$Expected Return$', fontsize = 6)


    plt.legend(loc='center right', bbox_to_anchor=(1.5, 0.5), frameon=False, fontsize=6)
    plt.tight_layout()
    return fig, ax
    

def metrics_move_pure_factors(pure_factors, core):
    
    pf_ret = pd.read_pickle('data/raw/pf_returns.pickle')
    selected_returns = pd.DataFrame()
    for f in pure_factors['code'].tolist():
        selected_returns = pd.concat((selected_returns,pf_ret[f]), axis=1)
    core_metrics = core.metrics()
    b_ir = [float(core_metrics['Information Ratio'][0])]
    b_vol = [float((core_metrics['Volatility'][0]))]
    b_r = [float((core_metrics['Return'][0]))]

    y_ir = []
    y_r = []
    y_vol = []

    core_ret = core.returns()
    pfs = selected_returns.columns.tolist()
    start = str(core_ret.index[0])[:-9]
    end = str(core_ret.index[-1])[:-9]
    for cnt, t in enumerate(pfs):    
        # hedge_returns = selected_returns.iloc[:,0:cnt+1]

       
        # port_ret = pd.concat((core_ret, hedge_returns), axis=1).fillna(0.0,limit=20).dropna()
        hw = [1/len(pfs)]*len(pfs[0:cnt+1])

        cw = []
        for ticks in core.constituents_data().index.tolist():
            cw.append(float(core.constituents_data().loc[ticks, 'weight']))
        
        weights = np.append(cw, hw)
           
        current_pf_universe = plb_universe.code(core.constituents_data().index.tolist()).union(plb_universe.code(pfs[0:cnt+1]))

        curr_pf = plb.Portfolio(universe = current_pf_universe).set_start(start).set_end(end).set_fixed_weight(weights, 'D')
        curr_pf = curr_pf.run_backtest()

        ret = curr_pf.result.static_metric['Return']
        vol = curr_pf.result.static_metric['Volatility']
        info_ratio = curr_pf.result.static_metric['Information Ratio']

        y_ir.append(info_ratio[0])
        y_r.append(ret[0])
        y_vol.append(vol[0])
        
    plt.style.use('seaborn-white')
    fig, ax = plt.subplots(figsize=(16,6), nrows=1, ncols=3)
    ax[0].scatter(y = (['benchmark']+pfs)[::-1], x=(b_ir+y_ir)[::-1], s=120, zorder=2.5, c=[colors[0]]*len(pfs) + [colors[1]])
    ax[0].set_title('$Info$ $Ratio$')
    ax[0].set_yticklabels((['Core Portfolio'] + ['Add '+i for i in pfs])[::-1])
    ax[0].set_ylabel('$Greedy$ $Search$ $Iteration$')


    ax[1].scatter(y = (['benchmark']+pfs)[::-1], x=(b_vol+y_vol)[::-1], s=120,zorder=2.5, c=[colors[0]]*len(pfs) + [colors[1]])
    ax[1].set_xticklabels([round(i,4) for i in ax[1].get_xticks()])
    ax[1].set_title('$Volatility$')
    ax[1].set_yticklabels([])

    ax[2].scatter(y = (['benchmark']+pfs)[::-1], x=(b_r+y_r)[::-1], s=120, zorder=2.5, c=[colors[0]]*len(pfs) + [colors[1]])
    ax[2].set_title('$Return$')
    ax[2].set_yticklabels([])



    for cnt,a in enumerate(ax.reshape(-1)):
            
        if cnt == 0:
            a.grid(axis='y', alpha=0.4, color='lightgray')

                
            arr = b_ir+y_ir
            y = np.linspace(0 ,len(arr)-1, len(arr))[::-1]

            y_pos = len(pfs) - np.argmax(arr)

            a.axhline(y = y_pos, color='orange', linestyle='--')
            a.annotate('Max Info Ratio',(arr[0],y_pos+0.1), color='orange')

            for x, (i,val) in enumerate(zip(y, arr)):
                if x==0:
                    continue
                arrow = FancyArrowPatch(posB = (val, i),
                                    posA = (arr[x-1], y[x-1]),
                                    arrowstyle='-|>', color='darkgreen' if arr[x-1] < val else 'darkred',mutation_scale=20,  alpha=0.6, shrinkB=5)
                a.add_patch(arrow)


        elif cnt == 1:
            a.set_yticks([])
            a.spines['left'].set_visible(False)
            arr = b_vol+y_vol
            y = np.linspace(0 ,len(arr)-1, len(arr))[::-1]

            y_pos = len(pfs) - np.argmin(arr)
                
            a.axhline(y = y_pos, color='orange', linestyle='--')

            a.annotate('Min Vol',(arr[0],y_pos+0.1), color='orange')

            for x, (i,val) in enumerate(zip(y, arr)):
                a.axhline(y=i, color='lightgray', alpha=0.3)
                if x==0:
                    continue
                arrow = FancyArrowPatch(posB = (val, i),
                                    posA = (arr[x-1], y[x-1]),
                                    arrowstyle='-|>', color='darkgreen' if arr[x-1] > val else 'darkred',mutation_scale=20, alpha=0.6, shrinkB=5)
                a.add_patch(arrow)


        elif cnt == 2:
            a.set_yticks([])
            a.spines['left'].set_visible(False)
            arr = b_r+y_r
            y = np.linspace(0 ,len(arr)-1, len(arr))[::-1]
            y_pos = len(pfs) - np.argmax(arr)

            a.axhline(y = y_pos, color='orange', linestyle='--')
            a.annotate('Max Return',(arr[0],y_pos+0.1), color='orange')

            for x, (i,val) in enumerate(zip(y, arr)):
                a.axhline(y=i, color='lightgray', alpha=0.3)
                if x==0:
                    continue
                arrow = FancyArrowPatch(posB = (val, i),
                                    posA = (arr[x-1], y[x-1]),
                                    arrowstyle='-|>', color='darkgreen' if arr[x-1] < val else 'darkred',mutation_scale=20,  alpha=0.6, shrinkB=5)
                a.add_patch(arrow)
        
        a.spines['right'].set_visible(False)
        a.spines['top'].set_visible(False)
        a.spines['left'].set_visible(False)
        if cnt in [1,2]:
            xticks = a.get_xticks()
            xticks = list(map(lambda x: str(round(float(x),2))+'%', xticks))
            a.set_xticklabels(xticks)
            fig.suptitle('Metrics Movement', weight='bold')
    # plt.tight_layout()
    
    return fig, ax


def MST(optimizer, hedge,core, **kwargs):
    overlay_universe = plb_universe.code(core.constituents_data().index.tolist()+hedge.tickers.tolist())

    pure_factor_universe = plb_universe.type('Pure Factor')
    start = kwargs.pop('start',str(core.returns().index[-1])[:-9])
    mst = plb.MST(universe = overlay_universe.union(pure_factor_universe)).set_start(start).set_return_interval('weekly')
    mst = mst.run_mst()
    positions = mst.result.tree(kind='dataframe')


    for index, row in positions.iterrows():
        info = plb_universe.code(row['Ticker']).data[0]
        positions.loc[index, "factor"] = info['factor']
        positions.loc[index, "asset_class"] = info['assetClass']
        positions.loc[index, "region"] = info['region']
        positions.loc[index, "short_name"] = info['shortName']
        
        if info['provider'] != 'PremiaLab':
            if info['shortName'] in list(core.constituents_data()['short_name'].values.tolist()):
                positions.loc[index, 'color'] = 'Core Portfolio'
            else:
                positions.loc[index, 'color'] = 'Selected Overlay Strategies'
        else:
            if row['Ticker'] in optimizer.pure_factors['code'].tolist():
                positions.loc[index,'color'] = 'Selected Pure Factors'
            else:
                positions.loc[index, 'color'] = 'Unselected Pure Factors'


    hover_data = {
        "x": False,
        "y": False,
        "short_name": True,
        "Ticker": True,
        "factor": True,
        "asset_class": True,
        "region": True,
        "color": False,
    }

    fig = px.scatter(positions, x="x", y="y", color="color", hover_data=hover_data, color_discrete_map ={
        'Core Portfolio' : 'red', 'Selected Overlay Strategies': 'orange', 'Selected Pure Factors':'#173D4D', 'Unselected Pure Factors': 'lightgray'
    })

    for i, row in positions.iterrows():
        x1, y1 = row["x"], row["y"]

        if row["Parent"] != row["Ticker"]:
            x2 = (positions[positions["Ticker"] == row["Parent"]].loc[:, "x"].values[0])
            y2 = (positions[positions["Ticker"] == row["Parent"]].loc[:, "y"].values[0])

            fig.add_trace(go.Scatter(x=[x1, x2],y=[y1, y2],mode="lines",line=dict(color="lightgray"),opacity=0.4, showlegend=False))

    fig.update_layout({"plot_bgcolor": "white"},title_text='Minimum Spanning Tree', height=700)
    fig.update_traces( marker=dict(size=7, line=dict(width=1, color="#F0F1F3")))
    fig.update_xaxes(showticklabels=False, title="")
    fig.update_yaxes(showticklabels=False, title="")
    return fig


def expected_track(df, pf):
    plt.style.use('seaborn-white')
    fig, ax = plt.subplots(figsize=(18,6))
    df[['portfolio_track']].plot(ax=ax, color=colors[0], zorder=2.5)
    df[['Mean']].plot(ax=ax, color=colors[0], zorder=2.5)
    df[['+1SD','-1SD']].plot(ax=ax, color=colors[1], zorder=2.5, linestyle='dotted')
    df[['+2SD','-2SD']].plot(ax=ax, color='k', zorder=2.5, linestyle='dotted')

    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.axvline(x = pf_pos.track().index[-1], linestyle='--', color='darkgray', alpha=0.5)
        # ax.grid(False, color='lightgray',alpha=0.3)
    plt.title('Optimized Portfolio Historical and Expected Track', weight='bold')
    maximum = np.max(df['+2SD'])

    last_day = pf.returns().index[-1]

    last_day_index = np.where(df.index == last_day)[0][0]
    last_exp_day_index = np.where(df.index == last_exp_day)[0][0]

    ax.annotate('$Expected$', (last_day+relativedelta(months=+5),maximum), color='grey')
    ax.annotate('', xy=(last_day, maximum+0.25),xytext=(last_day+relativedelta(months=+5),maximum+0.25),
                    arrowprops=dict(arrowstyle="|-|",connectionstyle="arc3", color='dimgrey', alpha=0.5),
                    color='dimgrey')
    ax.annotate('', xy=(last_day+relativedelta(days=+(7*31)+12),maximum+0.25),xytext=(last_exp_day,maximum+0.25),
                    arrowprops=dict(arrowstyle="|-|",connectionstyle="arc3", color='dimgrey', alpha=0.5),
                    color='dimgrey')
        

    ax.annotate(int(df.loc[last_exp_day, 'Mean']), (df.index[-1], df.loc[last_exp_day, 'Mean']), color=colors[0], fontsize=8)
    ax.annotate(int(df.loc[last_exp_day, '+2SD']), (df.index[-1], df.loc[last_exp_day, '+2SD']), color='k', fontsize=8)
    ax.annotate(int(df.loc[last_exp_day, '-2SD']), (df.index[-1], df.loc[last_exp_day, '-2SD']), color='k', fontsize=8)
    ax.annotate(int(df.loc[last_exp_day, '+1SD']), (df.index[-1], df.loc[last_exp_day, '+1SD']), color=colors[1], fontsize=8)
    ax.annotate(int(df.loc[last_exp_day, '-1SD']), (df.index[-1], df.loc[last_exp_day, '-1SD']), color=colors[1], fontsize=8)

    last_price = df.loc[last_day, 'portfolio_track']
    ax.annotate(int(last_price), xy = (last_day, last_price), xytext = (last_day+relativedelta(days=+15), last_price/1.05 ),color=colors[0],arrowprops=dict(arrowstyle="-|>",connectionstyle="arc3", color=colors[0], alpha=0.5))

    ax.set_yticks([])
        

    ax.fill_between(x=df.index[last_day_index:last_exp_day_index], y1=df['+1SD'].dropna().values, y2=df['-1SD'].dropna().values, color=colors[0], alpha=0.3, zorder=2)
    ax.fill_between(x=df.index[last_day_index:last_exp_day_index], y1=df['+2SD'].dropna().values, y2=df['-2SD'].dropna().values, color=colors[0], alpha=0.15, zorder=2)
    plt.legend(['Historical','Expected Mean','+1SD','-1SD','+2SD','-2SD'],loc='upper center', bbox_to_anchor=(0.5, -0.14), ncol=7, frameon=False)
    
    return fig, ax


def weight_plot(w):
    fig, ax = plt.subplots(figsize=(10,6))
    w.T.plot(kind='barh',stacked=True, width=0.7, color=colors, ax=ax)
    ax.legend(loc='center right', bbox_to_anchor=(1.6,0.5))
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['bottom'].set_visible(False)
    ax.grid(color='lightgray',linestyle='--', alpha=0.6,axis='x')
    ax.set_title('Overlay Portfolio Weights',weight='bold')
    ax.set_xlabel('Weight (%)')
    plt.show()
