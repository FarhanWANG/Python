"""
Get access to some standard visualization functions such as bar charts, area charts, heatmap for a plug and play functionality.

.. note::

    This is a beta version and is still under development


"""


from __future__ import annotations
__all__ = ["Visualiser"]

from plbpy import log_factory, logger, console, DEBUG, INFO 
from plbpy.utility.date_utils import  today, to_date, datetime2str
from dateutil.relativedelta import relativedelta
from plbpy import universe
from plbpy.exceptions.class_exceptions import VisualiserError
import datetime as dt
import pandas as pd
import numpy as np
import seaborn as sns
from matplotlib.patches import Patch
import matplotlib.pyplot as plt

class Visualiser:
    
    @log_factory(logger, DEBUG)
    def __init__(self):
        pass

    @staticmethod
    def _get_plb_colors():
        return [
            "#183C69",
            "#993E5C",
            "#1985A1",
            "#F2893B",
            "#996699",
            "#3D7650",
            "#7C97C2",
            "#967E9E",
            "#F1CECD",
            "#9CC5BF",
            "#71B080",
            "#60ACA7",
            "#8279CE",
            "#DBA0B3",
            "#CFC6DD",
            "#B9AEE1",
            "#4B4B4B",
            "#8B8B8B",
            "#CB4154",
        ]
    @staticmethod
    def _get_extra_colors():
        import matplotlib.cm as cm
        import matplotlib.colors 
        cmap = cm.get_cmap('RdBu_r')
        hexes = []
        for i in range(cmap.N):
            rgb = cmap(i)[:3] 
            hexes.append(matplotlib.colors.rgb2hex(rgb))
        return hexes
    
    
    @log_factory(logger, DEBUG)
    def __init__(self):
        pass

    @staticmethod
    def _stacked_area(df):
        import scipy
        np.random.seed(1)
        n = len(df)
        x = np.arange(n)
        y = df.values.T
        m = n+1
        xs = np.stack( [ x[:-1], x[1:] ] )
        xs = np.apply_along_axis( lambda u: np.linspace(u[0],u[1],m+1)[:m], 0, xs ).T.flatten()
        ys = []
        for i in range(y.shape[0]):
            ys.append(scipy.interpolate.interp1d(x,y[i,:])(xs) )
        ys = np.array(ys)
        y_pos = np.where( ys >= 0, ys, 0 )
        y_neg = np.where( ys <= 0, ys, 0 )
        return xs, y_pos, y_neg

    @staticmethod
    def _scale_values(df, rowwise = True):
        from sklearn.preprocessing import MinMaxScaler
        n = df.copy()
        p = df.copy()

        negative_vals = n.iloc[:,:].values
        negative_vals[negative_vals > 0] = np.nan
        
        positive_vals = p.iloc[:,:].values
        positive_vals[positive_vals < 0] = np.nan
        
        if not rowwise:
            negative_vals = negative_vals.flatten()
            negative_vals = negative_vals.reshape(-1,1)
            positive_vals = positive_vals.flatten()
            positive_vals = positive_vals.reshape(-1,1)
        
        n_scaler = MinMaxScaler(feature_range=(-1,0))
        n_scaler.fit(negative_vals)
        negative_vals = n_scaler.transform(negative_vals)

        p_scaler = MinMaxScaler(feature_range=(0,1))
        p_scaler.fit(positive_vals)
        positive_vals = p_scaler.transform(positive_vals)

        if not rowwise:
            negative_vals = negative_vals.reshape(n.shape[0], n.shape[1])
            positive_vals = positive_vals.reshape(p.shape[0], p.shape[1])

        return pd.DataFrame((np.nan_to_num(negative_vals)  + np.nan_to_num(positive_vals)),index=df.index, columns=df.columns)


    @staticmethod
    def _stacked_area(df):
        import scipy
        np.random.seed(1)
        n = len(df)
        x = np.arange(n)
        y = df.values.T
        m = n+1
        xs = np.stack( [ x[:-1], x[1:] ] )
        xs = np.apply_along_axis( lambda u: np.linspace(u[0],u[1],m+1)[:m], 0, xs ).T.flatten()
        ys = []
        for i in range(y.shape[0]):
            ys.append( scipy.interpolate.interp1d(x,y[i,:])(xs) )
        ys = np.array(ys)
        y_pos = np.where( ys >= 0, ys, 0 )
        y_neg = np.where( ys <= 0, ys, 0 )
        return xs, y_pos, y_neg

    @staticmethod
    def _scale_values(df, rowwise = True):
        from sklearn.preprocessing import MinMaxScaler
        n = df.copy()
        p = df.copy()

        negative_vals = n.iloc[:,:].values
        negative_vals[negative_vals > 0] = np.nan
        
        positive_vals = p.iloc[:,:].values
        positive_vals[positive_vals < 0] = np.nan
        
        if not rowwise:
            negative_vals = negative_vals.flatten()
            negative_vals = negative_vals.reshape(-1,1)
            positive_vals = positive_vals.flatten()
            positive_vals = positive_vals.reshape(-1,1)
        
        n_scaler = MinMaxScaler(feature_range=(-1,0))
        n_scaler.fit(negative_vals)
        negative_vals = n_scaler.transform(negative_vals)

        p_scaler = MinMaxScaler(feature_range=(0,1))
        p_scaler.fit(positive_vals)
        positive_vals = p_scaler.transform(positive_vals)

        if not rowwise:
            negative_vals = negative_vals.reshape(n.shape[0], n.shape[1])
            positive_vals = positive_vals.reshape(p.shape[0], p.shape[1])

        return pd.DataFrame((np.nan_to_num(negative_vals)  + np.nan_to_num(positive_vals)),index=df.index, columns=df.columns)



    @log_factory(logger, DEBUG)
    def pure_factor_dashboard(self, assetclass = 'Equity', region = 'Global', benchmark = 'SPGLOB', end_date = to_date(today()) + relativedelta(days=-2), rolling_window = 52, save_file = None):
        """
        Pure Factor Dashboard: a tearhseet of the long and short term performance of Premialab Pure Factors

        :param assetclass: Asset class to filter Pure Factors. Default: 'Equity'.
        :type assetclass: str

        :param region: Region to filter Pure Factors. Default: 'Global'.
        :type region: str

        :param benchmark: Benchmark for rolling correlation. Default: 'SPGLOB'
        :type benchmark: str

        :param end_date: Last Day of the period to create Dashboard for. Default: 2 days prior to today.
        :type end_date: str or datetime.date

        :param rolling_window: Window size for rolling correlation. Default: 52
        :type rolling_window: int        
        
        :param save_file: Path to save plot, include file name and extension. Default = None
        :type save_file: str
        
        Example:
        
        >>> plbpy.Visualiser().pure_factor_dashboard("Credit", "US", "SPX", "2020-06-01")
        
        """
        from plbpy.visualizer._dashboard import _dashboard
        if isinstance(end_date, str):

            end_date = to_date(end_date)
        ########## ERROR CHECKING #############
        if (end_date > to_date(today())):
            raise VisualiserError("Date cannot be in the future")
        
        assetclass_list = universe.to_frame().asset_class.unique().tolist()
        if (assetclass not in assetclass_list):
            raise VisualiserError("Asset class does not exist")

        region_list = universe.to_frame().region.unique().tolist()
        if ( region not in region_list):
            raise VisualiserError("Region does not exist")

        
        ############ DASHBOARD GENERATION ######
        fig = _dashboard(assetclass, region, benchmark, end_date)
        fig.generate_sharpe_ratio_arrow_graph(t11=end_date, 
                                          t10=end_date + relativedelta(months=-3),
                                          t01=end_date+ relativedelta(months=-3),
                                          t00=end_date + relativedelta(months=-6))
        fig.generate_sharpe_ratio_arrow_graph(t11=end_date, 
                                                t10=end_date + relativedelta(months=-12),
                                                t01=end_date + relativedelta(months=-12),
                                                t00=end_date + relativedelta(months=-24),
                                                type="Yearly")
        fig.generate_rolling_correlation(t1=end_date, t0=end_date + relativedelta(months=-12), window=rolling_window)
        fig.generate_historical_cumulative_returns(t1=end_date, t0=end_date + relativedelta(months=-12))
        fig.generate_rolling_volatility(t1=end_date, t0=end_date + relativedelta(months=-12), window=rolling_window)
        fig.generate_correlation_matrix(t11=end_date, 
                                        t10=end_date + relativedelta(months=-10*12),
                                        t01=end_date,
                                        t00=end_date + relativedelta(months=-12))
        fig.generate_performance_bar_charts(t1=end_date,
                                            t0=None)
        if save_file != None:
            fig.SaveFile(save_file)


    @log_factory(logger, DEBUG)
    def scorecard(self, df, title, color_by = 'asset_class', show_x = True, x_labels = 'hcl', scale_rowwise = True, save_file = None, cbar = False):
        """
        Scorecard Plot. Returns a matplotlib figure and axes object.
        :param df: a dataframe which is used to generate a scorecard
        :type df: pandas dataframe

        :param title: title of the plot
        :type title: str

        :param color_by: criteria to color and group y-axis by. Options include ['asset_class', 'factor', 'region']. Default = 'asset_class'.
        :type color_by: str

        :param show_x: Show X axis labels. Default = True
        :type show_x: Boolean

        :param x_labels: X labels for figure. Can be a list of the labels or 'hcl' to use Hierarchical Clustering to determine them. Default = 'hcl'.
        :type x_labels: str or list[str]
        
        :param scale_rowwise: Scaling of inputted dataframe to be done row-wise or using all data. Default = True.
        :type scale_rowwise: Boolean

        :param save_file: Path to save plot, include file name and extension. Default = None
        :type save_file: str

        :param cbar: Include the color bar legend. Default = False.
        :type cbar: Boolean

        :return: Matplotlib fig and ax that can be edited by user
        :rtype: Matplotlib fig and ax
        
        .. note::
            To display and edit inline please import matplotlib.pyplot as plt

        Example:

        >>> fig, ax = plbpy.Visualiser().scorecard(df, "Factor Scorecard", "asset_class")
        >>> plt.show()
        """
        from scipy.cluster.hierarchy import leaves_list, ward
        from scipy.spatial.distance import pdist, squareform

        ### INPUT VALIDATION ###
        if (not isinstance(df, pd.DataFrame)):
            raise VisualiserError("Input /'significant/' is not a dataframe")

        colorbylist = ['asset_class', 'factor', 'region']
        if color_by not in colorbylist:
            raise VisualiserError("Invalid sort option")

        if x_labels != 'hcl':
            if (not isinstance(x_labels, list)):
                raise VisualiserError("'xlabels' has to be 'hcl' or a list")
            else:
                if (len(x_labels) != len(df.columns.list())):
                    raise VisualiserError("Length of x labels is incorrect")
        #########################

        names = df.columns.tolist()
        colors = self._get_plb_colors()
        if color_by == None:
            sort_arr =  ['type']
        else:
            sort_arr = [color_by, 'type']
        y_axis = pd.DataFrame({'names': names,
        color_by: [universe.find(i).data[0].__dict__["_"+color_by] for i in names],
        'type': [universe.find(i).data[0].type for i in names]}).sort_values(by=sort_arr)['names'].tolist()
        if x_labels == 'hcl':
            order = leaves_list(ward(squareform(pdist(df.fillna(0.0))))).tolist()
            scaled = self._scale_values(df, scale_rowwise).iloc[order][y_axis]
            xlabs = [scaled.index[i] for i in order]
        elif isinstance(x_labels, list):
            xlabs = x_labels
        fig, ax = plt.subplots(figsize=(18,14))
        
        if show_x:
            label_x = xlabs
        else:
            label_x = []
        sns.heatmap(scaled.T,
                    cmap = 'RdBu',
                    vmin=-1,vmax=1,center=0,
                    ax=ax,
                    cbar=cbar,
                    yticklabels = y_axis,
                    xticklabels = label_x
                )

        ax.set_title(title, weight='bold')
        curr_ac = ''
        u_ac = universe.to_frame()[color_by].unique().tolist()
        for cnt,i in enumerate(ax.get_yticklabels()):
            ass_class = universe.short_name(i.get_text()).data[0].__dict__["_"+color_by]
            if cnt!=len(df.columns):
                if ass_class!=curr_ac:
                    ax.axhline(y = cnt, color='k', linestyle='--', linewidth=0.9, alpha=0.8)
                curr_ac = ass_class
            i.set_color(colors[u_ac.index(ass_class)])

        plt.tight_layout()
        if save_file != None:
            fig.savefig(save_file)
        return fig, ax


    @log_factory(logger, DEBUG)
    def stacked_area_plot(self, df, kind = 'area', **kwargs):
        """
        Stacked Area Plot using a dataframe. Returns a matplotlib figure and axes object.
        
        :param df: pandas dataframe used to generate stackplot
        :type df: pandas dataframe
        
        :param kind: Option to plot stacked area or bar plot
        :type kind: str

        :return: Matplotlib fig and ax that can be edited by user
        :rtype: Matplotlib fig and ax
        
        .. note::
            To display and edit inline please import matplotlib.pyplot as plt
        
        Example:
        >>> fig, ax = plbpy.Visualiser().stacked_area_plot(df, title = "Pure Factor 3M Log Returns")
        >>> plt.show()
        """
        if not isinstance(df, pd.DataFrame):
            raise VisualiserError("Input should be pandas dataframe")
        kindList = ['bar' , 'area']
        if kind not in kindList:
            raise VisualiserError("Parameter kind should be one of the following: " + kindList)
        
        if 'figsize' in kwargs.keys():
            figsize = kwargs.pop('figsize')
        else:
            figsize = (18,6)

        fig, ax=plt.subplots(figsize=figsize )
        xs, y_pos, y_neg = self._stacked_area(df)
        colors = self._get_plb_colors()
        
        if kind == 'area':
            ax.stackplot(xs, y_neg, colors=colors, zorder=2.5)
            ax.stackplot(xs, y_pos, colors=colors, zorder=2.5)

        legend = []
        legend_labels = list(df.columns)
        for i, j in enumerate(legend_labels):
            patch = Patch(facecolor = colors[i], label = j)
            legend.append(patch)
        
        if kind == 'bar':
            df.plot(kind = 'bar', stacked = True, ax = ax, color = colors, width = 0.8)

        ax.set_xticks([i for i in range(0,len(df.index))])
        if isinstance(df.index, pd.DatetimeIndex):
            idx = df.index.strftime("%Y-%m-%d")
        else:
            idx = df.index
        ax.set_xticklabels(idx, rotation=90)
        ax.axhline(y=0, color='lightgray', linewidth = 0.5)
        ax.grid(True, color='lightgray',alpha=0.3)
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.set_xlabel(kwargs.pop('xlabel', ''))
        ax.set_ylabel(kwargs.pop('ylabel',''))
        ax.set_title(kwargs.pop('title',''))
        ax.legend(handles = legend, frameon=False, fontsize=12)
        plt.tight_layout()
        return fig, ax

    @log_factory(logger, DEBUG)
    def frontier_plot(self, df, kind = 'xygraph'):
        """
        Frontier Plot function - generates an efficient fronter xygraph and stacked area chart for weights. 
        The 2 plots can be obtained separately, together or as a single plot.

        :param df: Pandas dataframe containing columns 'Return' , 'Volatility' and a column each for weights of portfolio constituents.
        :type df: Pandas dataframe

        :param kind: Options for output. 'xygraph' returns the efficient frontier plot, 
        'weights' returns a stacked area plot for Volatility vs weights of constituents,
        'combined' returns a single plot containing both xygraph and area plot,
        'both' returns the plots as separate objects.
        :type kind: str

        :return: Plotly Figure object(s) that can be displayed and edited by the user.
        :rtype: Plotly Figure
        
        .. note::
        
            To display this inline import plotly.graph_objects first.
        
        Example:
        
        >>> fig1, fig2 = plb.Visualiser().frontier_plot(df, kind='both')
        >>> fig1.show()
        >>> fig3 = plb.Visualiser().frontier_plot(df, kind='combined')
        >>> fig3.show()
        
        """
        import plotly.graph_objects as go
        import plotly.express as px
        
        if not isinstance(df , pd.DataFrame):
            raise VisualiserError("Input is not a dataframe")

        kindList = ['xygraph', 'weights', 'combined', 'both']
        if kind not in kindList:
            raise VisualiserError("Parameter kind should be one of the following" + kindList)
        
        # if ['Return', 'Volatilty'] not in df.columns:
        #     raise VisualiserError("Dataframe does not contain Return and Volatility columns")

        # if len(df.columns) <= 2:
        #     raise VisualiserError("DataFrame length <= 2, does not contain weights")


        def _frontier_line(df):
            text_data = df.copy()
            text_data = round(text_data, 2).astype(str)
            text_data = text_data.applymap(lambda x: x+"%")
            text_data = text_data.to_dict(orient = 'records')
            frontier_text = []
            
            for x in text_data:
                text = "<br>".join([y[0] + ": " + y[1] for y in x.items()])
                frontier_text.append(text)
            
            min_var_x = df.Volatility.min() 
            min_var_y = df.Return[df.Volatility.idxmin()]
            min_w = df.iloc[df.Volatility.idxmin(), 2:].to_dict()
            min_text = "<br>".join([x[0]+": "+str(round(x[1],2))+"%" for x in min_w.items()])

            fig = go.Figure()
            
            fig.add_trace(go.Scatter(
                 x = df['Volatility'],
                 y = df['Return'],
                 hovertemplate = '<b>Frontier</b><br>'+'%{text}',
                 text = frontier_text,
                 mode = 'lines',
                 name = "Frontier",
                ))  
            y_text = round(min_var_y,2)
            x_text = round(min_var_x,2)
            min_header = '<b>Min Variance</b>' + f'<br>Return: {y_text}%' + f'<br>Volatility: {x_text}%<br>'
            fig.add_trace(go.Scatter(
                 x = [min_var_x],
                 y = [min_var_y],
                 hovertemplate = min_header + min_text,
                 mode = 'markers',
                 name = "Min Variance",
                 marker_size=15,
                 marker_color=self._get_plb_colors()[4]
                ))

            fig.update_xaxes(title_text="Volatility (in %)")
            fig.update_yaxes(title_text="Return (in %)")
            fig.update_xaxes(showspikes = True)
            fig.update_xaxes(showticklabels=True, visible=True, showline=True, ticks='outside')
            fig.update_yaxes(zeroline=True, zerolinecolor='gray', gridwidth=0.02, zerolinewidth=1, showgrid=True, gridcolor='lightgray', showticklabels=True, visible=True, showline=True, linecolor='black')
            fig.update_layout(height = 600, width=1000, title_text="Efficient Frontier",  plot_bgcolor='white')
            return fig
        
        def _frontier_area(df):
            idx = df.Volatility.argmin()
            df = df.iloc[0:idx+1, : ]
            stack_data = df.iloc[:,2:]
            vol = df['Volatility'].to_list()
            stack_data = stack_data.melt()
            stack_data.columns = ['ticker', 'weight']
            len_const = len(df.iloc[:,2:].columns)
            vol_arr = [vol] * len_const
            stack_data['Volatility'] = np.concatenate(vol_arr)
            fig_stack = px.area(data_frame=round(stack_data,2), x = "Volatility",
                        y = "weight", color="ticker", 
                        color_discrete_sequence=self._get_plb_colors()
                        )
            fig_stack.update_xaxes(range=[stack_data.Volatility.min(),stack_data.Volatility.max()], title_text="Volatility (in %)")
            fig_stack.update_yaxes(range=[0, 100], title_text="Weights (in %)")
            fig_stack.update_xaxes(showspikes = True)
            fig_stack.update_xaxes(showticklabels=True, visible=True, showline=True, ticks='outside')
            fig_stack.update_yaxes(zeroline=True, zerolinecolor='gray', gridwidth=0.02, zerolinewidth=1, showgrid=True, gridcolor='lightgray', showticklabels=True, visible=True, showline=True, linecolor='black')
            fig_stack.update_layout(height = 600, width=1000, title_text="Weights - Volatility Stacked Area",  plot_bgcolor='white')
            return fig_stack

        if kind == 'xygraph':
            return _frontier_line(df)
        elif kind == 'weights':
            return _frontier_area(df)
        elif kind == 'both':
            return _frontier_line(df) , _frontier_area(df)
        elif kind == 'combined':
            import plotly.subplots as sp
            this_figure = sp.make_subplots(rows=2, cols=1)
            figure1_traces = []
            figure2_traces = []
            fig = _frontier_line(df)
            fig_stack = _frontier_area(df)
            for trace in range(len(fig["data"])):
                figure1_traces.append(fig["data"][trace])
            for trace in range(len(fig_stack["data"])):
                figure2_traces.append(fig_stack["data"][trace])
            for traces in figure1_traces:
                this_figure.append_trace(traces, row=1, col=1)
            for traces in figure2_traces:
                this_figure.append_trace(traces, row=2, col=1)
            
            this_figure.update_layout(height = 800, width=1000, title_text="Efficient Frontier",  plot_bgcolor='white', legend=dict(
                                    orientation="h",
                                    yanchor="bottom",
                                    y=0.43,
                                    xanchor="right",
                                    x=1
                                    ))
            this_figure.update_xaxes(title_text="Volatility (in %)", row = 2)
            this_figure.update_yaxes(title_text="Return (in %)", row = 1)
            this_figure.update_yaxes(title_text="Weight (in %)", row = 2)
            this_figure.update_xaxes(range=[df.Volatility.min()-1,df.Volatility.max()])
            this_figure.update_xaxes(showspikes = True)
            this_figure.update_xaxes(showticklabels=True, visible=True, showline=True, ticks='outside')
            this_figure.update_yaxes(zeroline=True, zerolinecolor='gray', gridwidth=0.02, zerolinewidth=1, showgrid=True, gridcolor='lightgray', showticklabels=True, visible=True, showline=True, linecolor='black')
            return this_figure
