from __future__ import annotations


class MSTVisualiser:
    @staticmethod
    def get_plb_colors():
        return [
            "#183C69",
            "#993E5C",
            "#1985A1",
            "#F2893B",
            "#996699",
            "#3D7650",
            "#7C97C2",
            "#967E9E",
            "#F1CECD",
            "#9CC5BF",
            "#71B080",
            "#60ACA7",
            "#8279CE",
            "#DBA0B3",
            "#CFC6DD",
            "#B9AEE1",
            "#4B4B4B",
            "#8B8B8B",
            "#CB4154",
        ]

    def __init__(self, parsed_response=None):
        self._mst_universe = parsed_response.universe
        self._response = parsed_response

    def draw_plotly_tree(self, **kwargs):
        import plotly.graph_objects as go
        import plotly.express as px

        colors = self.get_plb_colors()
        positions = self._response.tree(kind="dataframe")
        universe_df = self._mst_universe.to_frame()

        positions["color"] = colors[0]
        by = kwargs.pop("color_by", None)

        if by is not None:
            allowed_values = [
                "currency",
                "type",
                "style",
                "factor",
                "asset_class",
                "region",
                "return_type",
            ]
            assert (
                by in allowed_values
            ), f"Invalid argument {by}. Must be one of {allowed_values}"

            anchors = universe_df[by].unique().tolist()
            group_color = colors[0 : len(anchors)]
        color_discrete_map = {}
        for i, row in positions.iterrows():
            if by is not None:
                a = universe_df.loc[row["Ticker"]][by]
                positions.loc[i, "color"] = a
                color_discrete_map[a] = group_color[anchors.index(a)]

            info = universe_df.loc[row["Ticker"]]
            positions.loc[i, "factor"] = info["factor"]
            positions.loc[i, "asset_class"] = info["asset_class"]
            positions.loc[i, "region"] = info["region"]
            positions.loc[i, "short_name"] = info["short_name"]

        hover_data = {
            "x": False,
            "y": False,
            "short_name": True,
            "Ticker": True,
            "factor": True,
            "asset_class": True,
            "region": True,
            "color": False,
        }

        fig = px.scatter(
            positions,
            x="x",
            y="y",
            color="color",
            hover_data=hover_data,
            color_discrete_map=color_discrete_map,
        )

        for i, row in positions.iterrows():
            x1, y1 = row["x"], row["y"]

            if row["Parent"] != row["Ticker"]:
                x2 = (
                    positions[positions["Ticker"] == row["Parent"]]
                    .loc[:, "x"]
                    .values[0]
                )
                y2 = (
                    positions[positions["Ticker"] == row["Parent"]]
                    .loc[:, "y"]
                    .values[0]
                )

                fig.add_trace(
                    go.Scatter(
                        x=[x1, x2],
                        y=[y1, y2],
                        mode="lines",
                        line=dict(color="lightgray"),
                        opacity=0.4,
                        showlegend=False,
                    )
                )

        fig.update_layout(
            {"plot_bgcolor": "white"}, title_text="Minimum Spanning Tree", height=700
        )
        fig.update_traces(
            marker=dict(
                size=7,
                line=dict(width=1, color="#F0F1F3"),
            ),
        )
        fig.update_xaxes(showticklabels=False, title="")
        fig.update_yaxes(showticklabels=False, title="")

        return fig

    def draw_seaborn_tree(self, **kwargs):
        import seaborn as sns
        import matplotlib.pyplot as plt

        colors = self.get_plb_colors()
        positions = self._response.tree(kind="dataframe").copy()

        universe_df = self._mst_universe.to_frame()

        by = kwargs.pop("color_by", None)

        if by is not None:
            positions[by] = colors[0]
            allowed_values = [
                "currency",
                "type",
                "style",
                "factor",
                "asset_class",
                "region",
                "return_type",
            ]
            assert (
                by in allowed_values
            ), f"Invalid argument {by}. Must be one of {allowed_values}"
            anchors = universe_df[by].unique().tolist()
            group_color = colors[0 : len(anchors)]
            for i, row in positions.iterrows():

                a = universe_df.loc[row["Ticker"]][by]
                positions.loc[i, by] = a

        fig, ax = plt.subplots(figsize=(16, 8))
        if by is not None:
            ax = sns.scatterplot(
                data=positions, x="x", y="y", hue=f"{by}", palette=group_color
            )
        else:
            ax = sns.scatterplot(data=positions, x="x", y="y")

        for i, row in positions.iterrows():
            x1, y1 = row["x"], row["y"]

            if row["Parent"] != row["Ticker"]:
                x2 = (
                    positions[positions["Ticker"] == row["Parent"]]
                    .loc[:, "x"]
                    .values[0]
                )
                y2 = (
                    positions[positions["Ticker"] == row["Parent"]]
                    .loc[:, "y"]
                    .values[0]
                )

                ax.plot([x1, x2], [y1, y2], zorder=-1, color="lightgray", alpha=0.5)
        ax.set_title("Minimum Spanning Tree")
        plt.axis("off")

        if by is not None:
            plt.legend()

        return fig, ax
