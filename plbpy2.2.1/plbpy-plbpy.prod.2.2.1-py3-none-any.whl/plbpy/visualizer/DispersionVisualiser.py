from __future__ import annotations

from plbpy import universe as _gl_universe

class DispersionVisualiser:
    @staticmethod
    def get_plb_colors():
        return [
            "#183C69",
            "#993E5C",
            "#1985A1",
            "#F2893B",
            "#996699",
            "#3D7650",
            "#7C97C2",
            "#967E9E",
            "#F1CECD",
            "#9CC5BF",
            "#71B080",
            "#60ACA7",
            "#8279CE",
            "#DBA0B3",
            "#CFC6DD",
            "#B9AEE1",
            "#4B4B4B",
            "#8B8B8B",
            "#CB4154",
        ]


    def __init__(self, parsed_response):
        self._response = parsed_response

    def draw_dispersion_chart(self, **kwargs):
        """
        Draw dispersion chart. Input takes PLBPY Dispersion object
        """
        import pandas as pd
        import matplotlib.pyplot as plt
        import seaborn as sns
        import matplotlib.patches as mpatches
        plt.style.use('seaborn-white')

        show_subset = True
        colors = self.get_plb_colors()
        labels = kwargs.get('labels', 'name')

        df = self._response.universe_dispersion(kind="dataframe")
        df2 = self._response.subset_dispersion(kind="dataframe")

        fig = plt.figure(figsize=kwargs.pop('figsize', (16, 5)))
        grid = plt.GridSpec(1, 4, wspace=0.15)

        lineplot_ax = fig.add_subplot(grid[0, :3])
        kdeplot_ax = fig.add_subplot(grid[0, 3], xticklabels=[], sharey=lineplot_ax)

        # ---------- LINE PLOT -----------
        if kwargs.pop('show_average', True):
            lineplot_ax = df[["Average"]].plot(
                ax=lineplot_ax, color="k", zorder=2.5
            )
        lineplot_ax = df2.plot(ax=lineplot_ax, linewidth=1.5, zorder=3.5, color=colors[1:])

        lineplot_ax.fill_between(
            x=df.index,
            y1=df[["Max"]].values.flatten(),
            y2=df[["Min"]].values.flatten(),
            facecolor=colors[0],
            alpha=0.25,
        )
        lineplot_ax.fill_between(
            x=df.index,
            y1=df[["75%"]].values.flatten(),
            y2=df[["25%"]].values.flatten(),
            facecolor=colors[0],
            alpha=0.4,
        )
        lineplot_ax.axhline(y=0.0, color="grey", linestyle="--", alpha=0.7)
        lineplot_ax.set_xlim(df.index[0], df.index[-1])
        lineplot_ax.set_xlabel("")
        lineplot_ax.get_legend().remove()
        lineplot_ax.spines["top"].set_visible(False)
        lineplot_ax.spines["right"].set_visible(False)
        lineplot_ax.spines["bottom"].set_visible(False)
        lineplot_ax.tick_params(bottom=False)

        # ---------- KDE PLOT -----------
        kdeplot_ax = sns.kdeplot(
            y=abs(df["Max"]) - abs(df["Min"]),
            ax=kdeplot_ax,
            shade=True,
            facecolor=(171 / 255, 183 / 255, 199 / 255),
        )
        kdeplot_ax = sns.kdeplot(
            y=abs(df["75%"]) - abs(df["25%"]),
            ax=kdeplot_ax,
            shade=True,
            facecolor=(93 / 255, 115 / 255, 145 / 255),
        )
        kdeplot_ax = sns.kdeplot(
            data=df,
            y="Average",
            alpha=0.7,
            ax=kdeplot_ax,
            shade=True,
            facecolor="k",
        )

        sub_patches = []
        for cnt, c in enumerate(df2.columns):
            kdeplot_ax = sns.kdeplot(
                data=df2,
                y=df2.columns[cnt],
                alpha=0.7,
                ax=kdeplot_ax,
                shade=True,
                facecolor=colors[cnt + 1],
            )
            sub_patches.append(mpatches.Patch(color=colors[cnt + 1], label=_gl_universe.code(c).short_names[0] if labels == 'name' else c))

        second_color_patch = mpatches.Patch(
            color=(171 / 255, 183 / 255, 199 / 255), label="Max Min"
        )
        third_color_patch = mpatches.Patch(
            color=(93 / 255, 115 / 255, 145 / 255), label="IQR"
        )
        first_patch = mpatches.Patch(color="k", label="Average")

        kdeplot_ax.legend(
            handles=[second_color_patch, third_color_patch, first_patch] + sub_patches,
            frameon=False,
        )

        kdeplot_ax.axhline(y=0.0, color="grey", linestyle="--", alpha=0.5)
        kdeplot_ax.spines["top"].set_visible(False)
        kdeplot_ax.spines["right"].set_visible(False)
        kdeplot_ax.spines["bottom"].set_visible(False)
        kdeplot_ax.tick_params(bottom=False, left=False)

        fig.suptitle(kwargs.pop('title', "Universe Dispersion"), weight="bold")

        path = kwargs.pop('fig_path', None)
        if path is not None:
            plt.savefig(path)

        return fig, lineplot_ax, kdeplot_ax


    def draw_subset_dispersion(self):
        import matplotlib.pyplot as plt

        df2 = self._response.subset_dispersion(kind="dataframe")
        colors = self.get_plb_colors()
        plt.style.use("default")
        fig, ax = plt.subplots(figsize=(18, 5))

        for i, col in enumerate(df2.columns.tolist()):
            ax.plot(df2.loc[:, col], color=colors[i], zorder=2.5)

        ax.grid(False)
        ax.spines["bottom"].set_visible(False)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

        ax.set_xlim(df2.index[0], df2.index[-1])
        if self._response._request['metric'] != "Cumulative Return":
            ax.axhline(y=0.0, color="lightgray", linestyle="--", alpha=0.7)
        ax.set_xlabel("")
        ax.legend(
            df2.columns.tolist(),
            loc="upper center",
            bbox_to_anchor=(0.5, -0.05),
            frameon=False,
            shadow=False,
            ncol=5,
        )
        fig.suptitle("Subset Dispersion")

        plt.tight_layout()
        plt.show()
