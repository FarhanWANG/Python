from __future__ import annotations
from matplotlib import dates, ticker
from matplotlib.lines import Line2D
from matplotlib.patches import FancyArrowPatch, Patch
from matplotlib.ticker import FormatStrFormatter
from seaborn import xkcd_palette
from concurrent.futures import ThreadPoolExecutor
import pandas as pd
from pandas.tseries.offsets import BDay
import matplotlib.pyplot as plt
import numpy as np
from plbpy import session as _gl_session  # global session for fail case
from plbpy import universe
import seaborn as sns
import datetime as dt
from plbpy.utility.date_utils import datetime2str, today, to_date, date, datetime, to_datetime, payment_day, is_end_of_month
from plbpy.utility.string_utils import repeat_list, sanitize_metric, delete_word
from dateutil.relativedelta import relativedelta
import copy

from plbpy.interface.Portfolio import Portfolio
from typing import Union

class _dashboard:
    def __init__(self, assetclass = 'Equity', region = 'Global', benchmark = 'SPGLOB', end_date = to_date(today()) + relativedelta(days=-2)):
        self.assetclass = assetclass
        self.region = region
        self.benchmark = benchmark
        self.end_date = end_date
        self.session = _gl_session

        self.obj = universe.type('Pure Factor').asset_class(assetclass).region(region)
        self.obj_data = self.obj.tracks().to_frame()
        self.obj_tickers = self.obj.codes
        self.objRet = self.log_transform(self.obj_data)

        self.bmobj = universe.code(benchmark)
        self.bmobj_data = self.bmobj.tracks().to_frame()
        self.bmobjRet = self.log_transform(self.bmobj_data)

        self.fig = plt.figure(figsize=(36, 20))
        self.grid = plt.GridSpec(6, 3, hspace=1.2, wspace=0.25)
        
        self.axis_quarterly_sharpe_ratio = self.fig.add_subplot(self.grid[:3, 0])
        self.axis_yearly_sharpe_ratio = self.fig.add_subplot(self.grid[3:, 0])
        self.axis_rolling_correlation = self.fig.add_subplot(self.grid[:2, 1])
        self.axis_cumulative_return = self.fig.add_subplot(self.grid[2:4, 1])
        self.axis_rolling_volatility = self.fig.add_subplot(self.grid[4:, 1])
        self.axis_correlation = self.fig.add_subplot(self.grid[:3, 2])
        self.axis_performance_bars = self.fig.add_subplot(self.grid[3:, 2])

        self.colorScheme = {
        'Carry': '#967e9e',
        'Low Volatility': '#F1CECE',
        'Low Vol': '#F1CECE',
        'Reversion': '#b9aee1',
        'Trend': '#ccb3be',
        'Quality': '#CFC6DD',
        'Size': '#D8A0B3',
        'Value': '#8279CE',
        'Volatility': '#77446C',
        'Backwardation': '#b9aee1',
        'X Sectional': '#B65b83',
        "Momentum": '#B65b83',
        'Congestion': '#321560',
        'Intraday': '#603315',
        'Carry Dividend': '#967e9e',
        'Short Term Trend': '#321560'
    }

        self.encoder = {
            'Carry': 'CA',
            'Backwardation': 'BA',
            'Quality': 'QU',
            'Value': 'VA',
            'Size': 'SI',
            'Volatility': 'VO',
            'Momentum': 'MO',
            'Low Vol': 'LO',
            'Mean Reversion': 'ME',
            'Equity': 'EQ',
            'Fixed Income': 'FI',
            'Commodity': 'CO',
            'Credit': 'CR',
            'Foreign Exchange': 'FO',
            'US': 'US',
            'Global': 'GL',
            'Europe': 'EU',
            'Trend': 'TR'
        }

    def encode(self, string):
        return self.encoder[string]

    def pf_encode(self, factor):
        return "PF"+self.encode(factor['asset_class'])+self.encode(factor['factor'])+self.encode(factor['region'])

    def pf_decode(self, string):
        out = ""
        for k,v in self.encoder.items():
            if v == string[6:8]:
                out = k
        for k,v in self.encoder.items():
            if v == string[2:4]:
                out = out + " " + k
        for k,v in self.encoder.items():
            if v == string[4:6]:
                out = out + " " + k

        return out

    def draw_correlation_matrix(self, frame:pd.DataFrame, decode:bool=False, size:tuple=None, font:int=10, title:str='', factor_code:list = None,  cmap=None, save:dict=None, **additional_attributes) -> None:
        params = {
            'annot': True,
            'annot_kws': {"size": font},
            'fmt': '.2f',
            'vmin': -1.0,
            'vmax': 1.0,
            'square': True,
            'cbar_kws': {"shrink": .5},
            'frame': frame,
            'decode': decode,
            'size': size,
            'title': title,
            'emphasize': factor_code,
            'cmap': cmap
        }
        params.update(additional_attributes)
        return self.draw_sns_heatmap(**params)

    def SaveFile(self, path):
        self.fig.savefig(path)

    def draw_sns_heatmap(self, frame: pd.DataFrame, title: str = '', size: tuple = None, decode: Union[dict, bool] = False, emphasize: list = None, cmap=None, *args, **kwargs):
        ax = kwargs.pop('axis')
        if ax:
            pass
        elif size is not None:
            _,ax = plt.subplots(figsize=size)
        else:
            _,ax = plt.subplots()
        
    #     print(ax)
    #     print(kwargs)
        
        cols = list(frame.columns.values)
        rows = list(frame.index.values)

        # Color Scheme
        if cmap is None:
            cmap = sns.diverging_palette(220, 10, sep=26, as_cmap=True)
            cmap.set_bad(color='white', alpha=0.8)

        # Decode heatmap labels
        if isinstance(decode, dict):
            col_labels = [decode[label] for label in cols]
            row_labels = [decode[label] for label in rows]
        elif decode:
            col_labels = [self.pf_decode(label) for label in cols]
            row_labels = [self.pf_decode(label) for label in rows]
        else:
            col_labels = cols
            row_labels = rows

        ax = sns.heatmap(ax=ax,
                    data=frame,
                    cmap=cmap,
                    xticklabels=col_labels,
                    yticklabels=row_labels,
                    **kwargs)

        # Plot Cosmetics
        if isinstance(emphasize, list) and emphasize is not None:
            for factor in emphasize:
                h_rect = plt.Rectangle((0, cols.index(factor)), len(
                    cols), 1, fill=False, edgecolor='blue', lw=3)
                v_rect = plt.Rectangle((cols.index(factor), 0), 1, len(
                    cols), fill=False, edgecolor='blue', lw=3)

                ax.add_patch(h_rect)
                ax.add_patch(v_rect)

        ax.tick_params(axis="x", rotation=35)
        ax.tick_params(axis="y", rotation=0)
        if title:
            ax.set_title(title, fontsize=15, y=1.01)

        return ax
        
    def get_metrics(self, tickers, benchmark, start_date, end_date):
    
        def batch(ticker):
            asset = Portfolio(universe = universe.code(ticker)).set_benchmark(benchmark).set_start(start_date=start_date).set_end(end_date=end_date)
            asset.run_backtest()
            results = asset.result.static_metric
            return results
        
        with ThreadPoolExecutor(max_workers=30) as executor:
            data = list(executor.map(batch,tickers))
        
        df = pd.DataFrame()
        for i in data:
            df = pd.concat([df, i])
        df.index = tickers
        return df


    def log_transform(self, raw, dropna=True):
        logged = np.log(raw) - np.log(raw.shift(1))
        
        if dropna:
            logged.dropna(axis=0, how='any', inplace=True)

        return logged

    
    def rebase(self, frame):
        return (np.cumprod(np.e**frame)*100)

    def log_inverse(self, frame):
        frame = self.rebase(frame)
        if isinstance(frame, (pd.Series)):
            frame = frame.to_frame()
        return pd.concat([pd.DataFrame(data = [[100.0] * frame.shape[1]], 
                                    index = [frame.index[0] - BDay(1)],
                                    columns = frame.columns.values.tolist()), frame], axis=0)

    def generate_sharpe_ratio_arrow_graph(self, t00, t01, t10, t11, type="Quarterly", **kwargs):
        # Defaults
        if type == 'Quarterly':
            t0_color = kwargs.get('t0_color', None) or "#28869e"
            t1_color = kwargs.get('t1_color', None) or "#eba100"
            axis = kwargs.get('axis', None) or self.axis_quarterly_sharpe_ratio
            
        if type == 'Yearly':
            t0_color = kwargs.get('t0_color', None) or "#00dfeb"
            t1_color = kwargs.get('t1_color', None) or "#eba100"
            axis = kwargs.get('axis', None) or self.axis_yearly_sharpe_ratio
            
        x = "Volatility"
        y = "Return"
            
        # Extract Results
        t0_results = self.get_metrics(self.obj_tickers, self.benchmark, start_date=str(t00), end_date=str(t01))
        t1_results = self.get_metrics(self.obj_tickers, self.benchmark, start_date=str(t10), end_date=str(t11))
        
        # Create Markers and Sizes
        markers = [["$"+i[5:7].upper()+"$", 20] if i[5:7]=="SI" else ["$"+i[5:7].upper()+"$", 25] for i in self.obj_tickers]

        # Plot with Markers
        for i, index in enumerate(self.obj_tickers):
            axis.plot(t0_results.loc[index,x], t0_results.loc[index,y], marker=markers[i][0], ms=markers[i][1], color=t0_color, alpha=0.75, mfc=t0_color, mec='k', mew=.5)
            axis.plot(t1_results.loc[index,x], t1_results.loc[index,y], marker=markers[i][0], ms=markers[i][1], color=t1_color, alpha=0.75, mfc=t1_color, mec='k', mew=.5)
            
            if t0_results.loc[index,y] >= t1_results.loc[index,y]: 
                arrow_color = '#B22D59' # Red
            else:
                arrow_color = '#59A56D' # Green
                
            arrow = FancyArrowPatch(posA=(t0_results.loc[index,x], t0_results.loc[index,y]),
                                    posB=(t1_results.loc[index,x], t1_results.loc[index,y]),
                                    shrinkA=7,
                                    shrinkB=10,
                                    arrowstyle='->', mutation_scale=30, color=arrow_color, lw = 3, zorder=1) # Red Arrow
            axis.add_patch(arrow)
        
        # Cosmetics
        axis.grid(True, color='grey', linestyle='--')
        axis.axhline(y=0, color='black', linewidth=3, zorder=-1)
        axis.set_facecolor('#f7f8fA')
        axis.set_ylabel(sanitize_metric(y), size=20)
        axis.set_xlabel(sanitize_metric(x), size=20)
        yticklab = ['{:,.1f}'.format(x) for x in axis.get_yticks()]
        axis.set_yticks(axis.get_yticks())
        axis.set_yticklabels(yticklab, size=17)
        xticklab = ['{:,.1f}'.format(x) for x in axis.get_xticks()]
        axis.set_xticks(axis.get_xticks())
        axis.set_xticklabels(xticklab, size=17)
        
        axis.set_title(f'{type} Sharpe Comparison - {to_datetime(t01).strftime("%-d %b %y")} to {to_datetime(t11).strftime("%-d %b %y")}', size=22, y=1.01)
        
        # Legends
        legend_elements_markers = [
            Line2D(
                range(1),
                range(1),
                color='k',
                linewidth=0,
                marker=markers[idx][0],
                markersize=markers[idx][1],
                markerfacecolor='k',
                label = '{}'.format(
                    delete_word(i)
                )   
            ) for idx,i in enumerate(self.obj.to_frame().short_name.to_list())
        ]

        if type == 'Yearly':
            marker_legends = axis.legend(handles=legend_elements_markers, loc='upper center', ncol=4, frameon=False, bbox_to_anchor=(0.5, -0.10), fontsize=17)
            # date_legends = ax.legend(handles=legend_elements_dates, loc='upper center', ncol=3, frameon=False, bbox_to_anchor=(0.5, -0.05), fontsize=17)
            axis.add_artist(marker_legends)


    def generate_rolling_correlation(self, t0, t1, window, **kwargs):

        # Defaults
        axis = kwargs.get('axis', None) or self.axis_rolling_correlation
        set_locater_format = True if (to_datetime(t1) - to_datetime(t0)).days > 60 else False
        
        # Setup Data
        data = self.bmobjRet.join(self.objRet, how='inner')
        rolling = data.rolling(3).mean().rolling(window).corr()
        rolling.dropna(axis=0, how='all', inplace=True)
        rolling = rolling.loc[to_datetime(t0): to_datetime(t1)]
        output = {}

        for index in data.columns:
            drop_cols = [index] if index in self.bmobj.codes else [index] + self.bmobj.codes
            in2dict = rolling.xs(index, level=1).drop(drop_cols, axis=1)
            output[index] = {"frame": in2dict}
        data = output[self.bmobj.codes[0]]['frame']
            
        # Plot
        if set_locater_format:
            axis.xaxis.set_major_locator(dates.MonthLocator(bymonthday=15, interval=1))
            axis.xaxis.set_major_formatter(dates.DateFormatter('%b \n%Y'))
            axis.xaxis.set_minor_locator(dates.MonthLocator(range(2,13),1,1))
            axis.xaxis.set_minor_formatter(dates.DateFormatter("%b"))
            axis.xaxis.set_major_locator(dates.YearLocator(1,1,1))
            axis.xaxis.set_major_formatter(dates.DateFormatter("%b \n%Y"))
        else:
            axis.xaxis.set_major_locator(dates.MonthLocator(bymonthday=15, interval=1))
            axis.xaxis.set_major_formatter(dates.DateFormatter('%d \n%b'))
            axis.xaxis.set_minor_locator(dates.DayLocator([1,7,15,22,30],1))
            axis.xaxis.set_minor_formatter(dates.DateFormatter("%d"))
        
        for col in data.columns:
            label = delete_word(self.obj.code(col).to_frame().short_name.item())
            axis.plot(data.index, data.loc[:,col].values, color=self.colorScheme[label], label=label, lw=3)

        # Cosmetics
        axis.set_xlim(data.index[0], data.index[-1])
        axis.xaxis.set_tick_params(labelsize=17, which='both')
        axis.yaxis.grid(False)
        axis.spines['top'].set_visible(False)
        axis.yaxis.set_label_position('left')
        axis.set_xlabel('')
        axis.set_ylabel('')
        axis.set_ylim(-1.0, 1.0)
        yticklab = ['{:,.1f}'.format(x) for x in axis.get_yticks()]
        axis.set_yticks(axis.get_yticks())
        axis.set_yticklabels(yticklab, size=17)
        axis.grid(True, color='grey', linestyle='--', which='both')
        axis.axhline(y=0, color='black', linewidth=3, zorder=-1)
        axis.set_facecolor('#f7f8fA')
        
        axis.set_title(f'{self.bmobj.to_frame().short_name.item()} - {window}D Rolling Correlation', size=22, y=1.01)

    def generate_historical_cumulative_returns(self, t0, t1, **kwargs):

        # Defaults
        axis = kwargs.get('axis', None) or self.axis_cumulative_return
        avg_window = 3
        set_locater_format = True if (to_datetime(t1) - to_datetime(t0)).days > 60 else False
        
        # Setup Data
        data = self.log_inverse(self.objRet.rolling(avg_window).mean().dropna().loc[to_datetime(t0):to_datetime(t1),]).iloc[1:] - 100
        
        # Plot
        if set_locater_format:
            axis.xaxis.set_major_locator(dates.MonthLocator(bymonthday=15, interval=1))
            axis.xaxis.set_major_formatter(dates.DateFormatter('%b \n%Y'))
            axis.xaxis.set_minor_locator(dates.MonthLocator(range(2,13),1,1))
            axis.xaxis.set_minor_formatter(dates.DateFormatter("%b"))
            axis.xaxis.set_major_locator(dates.YearLocator(1,1,1))
            axis.xaxis.set_major_formatter(dates.DateFormatter("%b \n%Y"))
        else:
            axis.xaxis.set_major_locator(dates.MonthLocator(bymonthday=15, interval=1))
            axis.xaxis.set_major_formatter(dates.DateFormatter('%d \n%b'))
            axis.xaxis.set_minor_locator(dates.DayLocator([1,7,15,22,30],1))
            axis.xaxis.set_minor_formatter(dates.DateFormatter("%d"))
        
        for col in data.columns:
            label = delete_word(self.obj.code(col).to_frame().short_name.item())
            axis.plot(data.index, data.loc[:,col].values, color=self.colorScheme[label], label=label, lw=3)
        
        # Cosmetics
        axis.set_xlim(data.index[0], data.index[-1])
        axis.yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
        axis.tick_params(axis="y", labelsize=17)
        axis.set_ylabel("")
        axis.set_xlabel("")
        axis.xaxis.set_tick_params(labelsize=17, which='both')
        axis.grid(c = '#969696', linestyle = '--', which = 'both')
        axis.set_facecolor('#f7f8fA')
        plt.rcParams['xtick.top'] = plt.rcParams['xtick.labeltop'] = False
        axis.axhline(y=0, color='black', linewidth=3, zorder=-1)
        
        axis.set_title(f'{(to_datetime(t1) - to_datetime(t0)).days}D Performance (%)', size=22, y=1.01)

    def generate_rolling_volatility(self, t0, t1, window, **kwargs):

        # Defaults
        axis = kwargs.get('axis', None) or self.axis_rolling_volatility
        set_locater_format = True if (to_datetime(t1) - to_datetime(t0)).days > 60 else False
        
        # Setup Data
        data = self.objRet.rolling(window).std().dropna().loc[to_datetime(t0):to_datetime(t1),] * (252**0.5) * 100
        
        # Plot
        if set_locater_format:
            axis.xaxis.set_major_locator(dates.MonthLocator(bymonthday=15, interval=1))
            axis.xaxis.set_major_formatter(dates.DateFormatter('%b \n%Y'))
            axis.xaxis.set_minor_locator(dates.MonthLocator(range(2,13),1,1))
            axis.xaxis.set_minor_formatter(dates.DateFormatter("%b"))
            axis.xaxis.set_major_locator(dates.YearLocator(1,1,1))
            axis.xaxis.set_major_formatter(dates.DateFormatter("%b \n%Y"))
        else:
            axis.xaxis.set_major_locator(dates.MonthLocator(bymonthday=15, interval=1))
            axis.xaxis.set_major_formatter(dates.DateFormatter('%d \n%b'))
            axis.xaxis.set_minor_locator(dates.DayLocator([1,7,15,22,30],1))
            axis.xaxis.set_minor_formatter(dates.DateFormatter("%d"))
            
        for col in data.columns:
            label = delete_word(self.obj.code(col).to_frame().short_name.item())
            axis.plot(data.index, data.loc[:,col].values, color=self.colorScheme[label], label=label, lw=3)
        
        # Cosmetics
        axis.set_xlim(data.index[0], data.index[-1])
        axis.tick_params(axis="y", labelsize=17)
        axis.set_ylim(0, max(axis.get_yticks()))
        axis.yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
        axis.set_xlabel("")
        axis.set_ylabel("")
        axis.xaxis.set_tick_params(labelsize=17, which='both')
        axis.legend(loc='upper center', bbox_to_anchor=(0.5, -0.15), prop={'size': 17}, ncol=4, frameon=False)
        axis.grid(c = '#969696', linestyle = '--', which = 'both')
        axis.set_facecolor('#f7f8fA')
        plt.rcParams['xtick.top'] = plt.rcParams['xtick.labeltop'] = False
        
        axis.set_title(f'{window}D Rolling Volatility (%)', size=22, y=1.01)

    def generate_correlation_matrix(self, t00, t01, t10, t11, **kwargs):
        # Defaults
        axis = kwargs.get('axis', None) or self.axis_correlation
        
        # Setup Data
        data = self.objRet.rolling(3).mean().rename(columns={col: delete_word(self.obj.code(col).to_frame().short_name.item()) for col in self.objRet.columns})
        
        frame = pd.DataFrame(
            data=np.triu(data.loc[to_datetime(t00):to_datetime(t01)].corr(), k=1) + \
                np.tril(data.loc[to_datetime(t10):to_datetime(t11)].corr()),
            columns=data.columns,
            index=data.columns).replace(1.0, np.nan)
        
        axis = self.draw_correlation_matrix(frame=frame, size=frame.shape, cbar=False, font=15, axis=axis, **kwargs)
        
        axis.set_ylabel('Short Term Correlation', fontsize=20, rotation=270, labelpad=25, color='#515151')
        axis.yaxis.set_label_position('right')
        axis.set_xlabel('Long Term Correlation', fontsize=20, color='#515151')
        axis.tick_params(axis="x", labelsize=17, rotation=14)
        axis.tick_params(axis="y", labelsize=17, rotation=0)
        
        axis.set_title(f'Short Term VS Long Term Correlation', size=22, y=1.01)
    
    def generate_performance_bar_charts(self, t0, t1, window=365, annualized_window=31, **kwargs):
        # Defaults
        axis = kwargs.get('axis', None) or self.axis_performance_bars
        
        # Setup Data
        rolling_cumulative = (self.log_inverse(
            self.objRet.loc[
                to_datetime(t1) + relativedelta(years=-10): 
                    to_datetime(t1)
                ]).rolling(f'{window}D').apply(lambda x: 
                                        x.iloc[-1] - x.iloc[0]
                                        )).dropna(axis=0, how='all')
        rolling_cumulative = rolling_cumulative.iloc[:, ::-1]
        fmt = lambda x: x.strftime('%a %-d %b %Y')
        
        start_end_dates = payment_day(
            pd.DatetimeIndex([
                to_date(t1) + relativedelta(months=-12),
                to_date(t1)
            ])
        )
        if kwargs.get("debug", False):
            print("Yearly\n{} to {} -> {}".format(
                pd.DatetimeIndex(
                    [to_date(t1) + relativedelta(months=-12),to_date(t1)]
                    )[0].strftime('%a %-d %b %Y'),
                pd.DatetimeIndex(
                    [to_date(t1) + relativedelta(months=-12),to_date(t1)]
                    )[1].strftime('%a %-d %b %Y'),
                ' to '.join([fmt(i) for i in start_end_dates])
            ))
        
        latest_cumulative = self.get_metrics(rolling_cumulative.columns.values.tolist(), self.benchmark, start_date=str(to_date(start_end_dates[0])), 
                                                    end_date=str(to_date(start_end_dates[1]))
                                                    )['Return']
        
        start_end_dates = payment_day(
            pd.DatetimeIndex([
                to_date(t1) + relativedelta(months=-1) if not is_end_of_month(to_date(t1)) else to_date(t1).replace(day=1) + relativedelta(days=-1),
                to_date(t1)
            ])
        )
        
        if kwargs.get("debug", False):
            print("1 Month\n{} to {} -> {}".format(
                pd.DatetimeIndex(
                    [to_date(t1) + relativedelta(months=-1),to_date(t1)]
                    )[0].strftime('%a %-d %b %Y'),
                pd.DatetimeIndex(
                    [to_date(t1) + relativedelta(months=-1),to_date(t1)]
                    )[1].strftime('%a %-d %b %Y'),
                ' to '.join([fmt(i) for i in start_end_dates])
            ))
        
        annualised_dot = self.get_metrics(rolling_cumulative.columns.values.tolist(), self.benchmark, start_date=str(to_date(start_end_dates[0])), 
                                                    end_date=str(to_date(start_end_dates[1])))['Return']

        
        # Plot
        bar_color = lambda x: xkcd_palette(['sea blue'])[0] if x > 0.0 else xkcd_palette(['crimson'])[0]
        
        axis.barh(latest_cumulative.index, latest_cumulative.values, 0.5, color=[bar_color(ret) for ret in latest_cumulative.values.flatten().tolist()], edgecolor='#c8c8c8', lw=1.5, zorder=3)
        axis.barh(rolling_cumulative.columns, rolling_cumulative.describe().T[['min']].values.flatten(), 0.5, color='white', edgecolor='#c8c8c8', lw=1.5, zorder=1)
        axis.barh(rolling_cumulative.columns, rolling_cumulative.describe().T[['max']].values.flatten(), 0.5, color='white', edgecolor='#c8c8c8', lw=1.5, zorder=1)
        axis.scatter(y=annualised_dot.index, x=annualised_dot.values, color='orange', s=300, zorder=4)
        
        # Cosmetics
    
        axis.xaxis.set_major_locator(ticker.AutoLocator())
        axis.xaxis.set_major_formatter(FormatStrFormatter('%.1f'))
        axis.xaxis.set_minor_locator(ticker.AutoMinorLocator())
        
        xlim = max([abs(rolling_cumulative).max().max(), abs(annualised_dot.values).max()])
        
        axis.set_facecolor('#f7f8fA')
        axis.grid(c = '#969696', linestyle = '--', axis='x')
        axis.set_xlim(-xlim*1.1, xlim*1.1) # Set the range for the x-tick labels
        axis.tick_params(axis='x', labelsize=17)
        
        plt.axvline(x=0, color='grey', lw=2) # Add a line for y=0
        yticklab = [delete_word(self.obj.code(col).to_frame().short_name.item()) for col in rolling_cumulative.columns]
        axis.set_yticks(axis.get_yticks())
        axis.set_yticklabels(yticklab, rotation=0, fontsize=17)
        legend_elements= [
            Line2D(range(1), range(1), color="#ED8536", linewidth=0, marker='o', markersize=15, 
                markerfacecolor="#ED8536", label=f'Monthly Annualized Return'), # Orange Dot
            Patch(facecolor='white', edgecolor='#c8c8c8', label=f'Max/Min Yearly Return in 10 Years'), # White Bar
            Patch(facecolor='#347292', edgecolor='#c8c8c8', label=f'Current Yearly Return (+ve)'), # Blue Bar 
            Patch(facecolor='#7F1717', edgecolor='#c8c8c8', label=f'Current Yearly Return (-ve)') # Red Bar
        ] 
        axis.legend(handles=legend_elements, loc='upper center', ncol=2, frameon=False, bbox_to_anchor=(0.5, -0.09), fontsize=17)
        axis.set_title(f'Short Term VS Long Term Performance', size=22, y=1.01)