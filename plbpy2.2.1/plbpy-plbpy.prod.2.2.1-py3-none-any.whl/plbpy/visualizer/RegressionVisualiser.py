from __future__ import annotations


class RegressionVisualiser:
    @staticmethod
    def get_plb_colors():
        return [
            "#183C69",
            "#993E5C",
            "#1985A1",
            "#F2893B",
            "#996699",
            "#3D7650",
            "#7C97C2",
            "#967E9E",
            "#F1CECD",
            "#9CC5BF",
            "#71B080",
            "#60ACA7",
            "#8279CE",
            "#DBA0B3",
            "#CFC6DD",
            "#B9AEE1",
            "#4B4B4B",
            "#8B8B8B",
            "#CB4154",
        ]

    @staticmethod
    def hex_to_rbg(hex_code):
        return tuple(int(hex_code.lstrip("#")[i : i + 2], 16) for i in (0, 2, 4))

    def __init__(self, parsed_response=None):
        self._response = parsed_response

    def plot_track(self, values, **kwargs):
        import matplotlib.pyplot as plt

        figsize = kwargs.pop("figsize", (16, 5))
        fig, ax = plt.subplots(figsize=figsize)

        colors = self.get_plb_colors()
        values.plot(ax=ax, color=colors)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.set_yscale("log")
        ax.grid(True, alpha=0.3, color="lightgray")
        ax.set_title(kwargs.pop("title", "Track"))

        return fig, ax

    def cum_track(self, rolling, **kwargs):
        import matplotlib.pyplot as plt
        import numpy as np

        if rolling:
            df = self._response.rolling_cumulated_alpha_track(kind="dataframe")
        else:
            df = self._response.cumulated_alpha_track(kind="dataframe")

        fig, ax = plt.subplots(figsize=(16, 5))
        ax.plot(df, color="#183C69", label="Residuals")

        y1 = df.values.flatten()
        y2 = np.zeros(shape=y1.shape)

        ax.fill_between(
            x=df.index, y1=y1, y2=0, where=y1 > y2, facecolor="#183C69", alpha=0.25
        )
        ax.fill_between(
            x=df.index, y1=y1, y2=0, where=y1 <= y2, facecolor="#993E5C", alpha=0.25
        )

        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

        ax.grid(True, color="lightgray", alpha=0.2)
        ax.tick_params(bottom=False)

        ax.axhline(y=0, color="lightgray", linestyle="-", zorder=-1)

        ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.08), shadow=True, ncol=2)
        ax.set_title("Cumulated residuals")

        return fig, ax

    def create_tearsheet(self, **kwargs):
        import matplotlib.pyplot as plt
        import numpy as np
        import pandas as pd
        from matplotlib.ticker import NullFormatter
        import warnings

        warnings.filterwarnings("ignore")

        rows = []

        colors = self.get_plb_colors()

        # --------------------- REGRESSION TRACK ------------------
        fig, ax = plt.subplots(
            ncols=2, nrows=1, figsize=(16, 5), gridspec_kw={"width_ratios": [3, 1]}
        )

        observed = self._response.observed_track(kind="dataframe")
        regression = self._response.regression_track(kind="dataframe")
        df = pd.concat((observed, regression), axis=1).fillna(method="ffill")
        df.columns = ["o", "r"]

        df["o"].plot(zorder=2.5, color=colors[0], ax=ax[0], label="Observed")
        df["r"].plot(zorder=2.5, color=colors[1], ax=ax[0], label="Regression")
        ax[0].set_title("Track Record", weight="bold")
        ax[0].set_yscale("log")
        plt.ion()
        ax[0].yaxis.set_major_formatter(NullFormatter())
        ax[0].yaxis.set_minor_formatter(NullFormatter())
        ax[0].set_ylabel("$Log$ $Scale$")
        ax[0].legend(
            loc="upper center",
            bbox_to_anchor=(0.5, -0.14),
            shadow=True,
            ncol=2,
            fontsize=9,
        )
        ax[0].fill_between(
            x=df.index,
            y1=df["r"],
            y2=df["o"],
            where=df["r"] > df["o"],
            facecolor="#993E5C",
            alpha=0.25,
        )
        ax[0].fill_between(
            x=df.index,
            y1=df["r"],
            y2=df["o"],
            where=df["r"] <= df["o"],
            facecolor="#183C69",
            alpha=0.25,
        )

        ax[1].plot(df["o"], df["r"], "o", zorder=2.5, markerfacecolor=colors[0])
        m, b = np.polyfit(df["o"].values, df[["r"]].values, 1)
        ax[1].plot(df["o"], m * df["o"] + b, zorder=3.5, linewidth=2.5, color=colors[3])
        ax[1].set_title("Observed vs Regression", weight="bold")
        ax[1].set_ylabel("$Regression$")
        ax[1].set_xlabel("$Observed$")
        ax[1].grid(False)
        yt = ax[1].get_yticks()
        xt = ax[1].get_xticks()

        for i in yt[1:-1]:
            ax[1].axhline(y=i, color="lightgray", alpha=0.3, linewidth=0.5)

        xt = ax[1].get_xticks()

        for i in xt[1:-1]:
            ax[1].axvline(x=i, color="lightgray", alpha=0.3, linewidth=0.5)

        ax[1].set_yticks([])
        ax[1].set_xticks([])

        r2 = self._response.metric["R-Squared"][0]
        ax[1].annotate(
            f"R2: {r2}", (xt[-3], yt[1]), color="red" if r2 < 50 else "green"
        )

        for a in ax.reshape(-1):
            a.spines["right"].set_visible(False)
            a.spines["top"].set_visible(False)
            a.grid(True, color="lightgray", alpha=0.3)

        rows.append((fig, ax))

        # ---------------------- STATIC METRICS PLOTS --------------------------
        s = self._response.model_summary.iloc[1:]
        r = self._response.model_summary.iloc[0]

        fig2, ax2 = plt.subplots(ncols=3, nrows=1, figsize=(16, 4))
        s[["Beta"]].plot(kind="bar", ax=ax2[0], color=colors, width=0.9, zorder=2.5)
        vals = s["Beta"].values
        for i in ax2[0].get_xticks():
            ax2[0].annotate(
                f"{round(vals[i],2)}",
                (i - ((0.9 / len(vals)) * 0.5), vals[i] - (max(vals) / 12)),
                color="w",
                zorder=3.5,
                fontsize=10,
            )

        ax2[0].axhline(y=r["Beta"], color="red", linestyle="--", linewidth=2, zorder=3)

        ax2[0].annotate(
            "{}".format(r["Beta"]),
            (len(vals) - 0.8, r["Beta"] + max(vals) / 35),
            color="red",
        )
        ax2[0].annotate(
            "α", (-0.65, r["Beta"] + max(vals) / 35), color="red", fontsize=14
        )
        ax2[0].set_title("Beta", weight="bold")
        ax2[0].get_legend().remove()
        for i in ax2[0].get_yticks()[1:-1]:
            ax2[0].axhline(y=i, color="lightgray", alpha=0.3)

        ax2[0].set_yticks([])

        s[["Ret Attrib"]].plot(
            kind="bar", ax=ax2[1], color=colors, width=0.9, zorder=2.5
        )
        vals = s["Ret Attrib"].values
        for i in ax2[1].get_xticks():
            ax2[1].annotate(
                f"{round(vals[i],2)}",
                (i - ((0.9 / len(vals)) * 0.5), vals[i] - (max(vals) / 12)),
                color="w",
                zorder=3.5,
                fontsize=10,
            )

        ax2[1].axhline(
            y=r["Ret Attrib"], color="red", linestyle="--", linewidth=2, zorder=3
        )

        ax2[1].annotate(
            "{}".format(r["Ret Attrib"]),
            (len(vals) - 0.8, r["Ret Attrib"] + max(vals) / 35),
            color="red",
        )
        ax2[1].annotate(
            "α", (-0.65, r["Ret Attrib"] + max(vals) / 35), color="red", fontsize=14
        )

        ax2[1].set_title("Return Attribution", weight="bold")
        ax2[1].get_legend().remove()
        for i in ax2[1].get_yticks()[1:-1]:
            ax2[1].axhline(y=i, color="lightgray", alpha=0.3)

        ax2[1].set_yticks([])

        s[["Var Prop"]].plot(kind="bar", ax=ax2[2], color=colors, width=0.9, zorder=2.5)
        vals = s["Var Prop"].values
        for i in ax2[1].get_xticks():
            ax2[2].annotate(
                f"{round(vals[i],2)}",
                (i - ((0.9 / len(vals)) * 0.5), vals[i] - (max(vals) / 12)),
                color="w",
                zorder=3.5,
                fontsize=10,
            )

        ax2[2].axhline(
            y=r["Var Prop"], color="red", linestyle="--", linewidth=2, zorder=3
        )

        ax2[2].annotate(
            "{}".format(r["Var Prop"]),
            (len(vals) - 0.8, r["Var Prop"] + max(vals) / 35),
            color="red",
        )
        ax2[2].annotate(
            "α", (-0.65, r["Var Prop"] + max(vals) / 35), color="red", fontsize=14
        )
        ax2[2].set_title("Variance Proportion", weight="bold")
        ax2[2].get_legend().remove()
        for i in ax2[2].get_yticks()[1:-1]:
            ax2[2].axhline(y=i, color="lightgray", alpha=0.3)

        ax2[2].set_yticks([])

        for a in ax2.reshape(-1):
            a.spines["top"].set_visible(False)
            a.spines["right"].set_visible(False)
            a.spines["left"].set_visible(False)

        rows.append((fig2, ax2))

        # try:
        rolling_summary = self._response.rolling_model_summary
        rol = rolling_summary.unstack(level=1)
        # except Exception:
        #     print("No rolling metrics for this regression")
        if len(rol) < 1:
            print("No rolling metrics for this regression")
        else:
            fig3, ax3 = plt.subplots(nrows=1, ncols=2, figsize=(16, 5))
            df = rol["Beta"]
            df.index = pd.to_datetime(df.index).strftime("%Y-%m")
            ax3[0] = df.plot(ax=ax3[0], color=colors, zorder=2.5, marker=".")
            ax3[0].set_title("Rolling Beta", weight="bold")
            # ax3[0].legend(loc='upper center', bbox_to_anchor=(0.5, -0.15), shadow=True, ncol=4, prop={'size': 9})

            for i, (name, lines) in enumerate(zip(df.columns.tolist(), ax3[0].lines)):
                ax3[0].annotate(
                    f"{name}",
                    xy=(lines.get_xdata()[-1], lines.get_ydata()[-1]),
                    color=colors[i],
                )

            df = self._response.rolling_metric[["R-Squared"]].copy()
            df.index = pd.to_datetime(df.index).strftime("%Y-%m")
            ax3[1] = df.plot(color=colors, ax=ax3[1], zorder=2.5, marker=".")
            ax3[1].set_title("Rolling R2", weight="bold")
            ax3[1].set_xlabel("")
            ax3[1].set_ylim(-1, 102)

            for a in ax3.reshape(-1):
                a.spines["top"].set_visible(False)
                a.spines["right"].set_visible(False)
                a.grid(True, color="lightgray", alpha=0.3)
                a.get_legend().remove()

            rows.append((fig3, ax3))

            fig4, ax4 = plt.subplots(nrows=1, ncols=2, figsize=(16, 5))
            df = rol["Ret Attrib"].iloc[:, 1:]
            df.index = pd.to_datetime(df.index).strftime("%Y-%m")
            ax4[0] = df.plot(
                kind="bar", width=0.9, stacked=True, color=colors, zorder=2.5, ax=ax4[0]
            )

            ax4[0].set_title("Rolling Return Attribution", weight="bold")
            ax4[0].legend(
                loc="upper center",
                bbox_to_anchor=(0.5, -0.2),
                shadow=True,
                ncol=4,
                prop={"size": 9},
            )

            df = rol["Var Prop"].iloc[:, 1:]
            df.index = pd.to_datetime(df.index).strftime("%Y-%m")
            ax4[1] = df.plot(
                kind="bar", stacked=True, color=colors, zorder=2.5, ax=ax4[1], width=0.9
            )
            ax4[1].set_title("Rolling Variance Proportion", weight="bold")

            ax4[1].legend(
                loc="upper center",
                bbox_to_anchor=(0.5, -0.2),
                shadow=True,
                ncol=4,
                prop={"size": 9},
            )

            xticks = ax4[1].get_xticks()
            for a in ax4.reshape(-1):
                a.spines["top"].set_visible(False)
                a.spines["right"].set_visible(False)

                for i in xticks:
                    a.axvline(
                        x=i, color="lightgray", alpha=0.5, linestyle="--", linewidth=0.5
                    )
                a.grid(axis="y", color="lightgray", alpha=0.3)

            rows.append((fig4, ax4))

        return rows
