from __future__ import annotations


class HClusterVisualiser:
    @staticmethod
    def _create_universe_object(session, codes):
        """statically creates universe object from codes"""
        from plbpy import universe as _gl_universe

        obj = _gl_universe.code(codes)
        return obj

    def __init__(self, parsed_response):
        self._hcluster_universe = parsed_response.universe
        self._response = parsed_response

    def draw_matrix(self, **kwargs):
        import seaborn as sns
        import matplotlib.pyplot as plt
        import numpy as np
        import pandas as pd

        df = pd.DataFrame(
            data=np.array(self._response._correlation_values),
            index=self._response._correlation_assets,
            columns=self._response._correlation_assets,
        )

        fig, ax = plt.subplots(figsize=kwargs.pop("figsize", (10, 10)))

        sns.heatmap(
            df,
            vmin=kwargs.pop("vmin", -1.0),
            vmax=kwargs.pop("vmax", 1.0),
            cmap=sns.diverging_palette(220, 10, n=49, as_cmap=True),
            square=True,
            cbar_kws={"shrink": 0.3},
            yticklabels=kwargs.pop("yticklabels", "auto"),
            xticklabels=kwargs.pop("xticklabels", "auto"),
            ax=ax,
        )

        file_path = kwargs.pop("file_path", None)
        if file_path is not None:
            plt.savefig(file_path)

        return fig, ax
