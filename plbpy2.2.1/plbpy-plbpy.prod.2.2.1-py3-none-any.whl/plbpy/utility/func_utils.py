def whoami(call_level=1):
    import sys
    return sys._getframe(call_level).f_code.co_name


class Options:
    @classmethod
    def _from_dict(cls, dict):
        obj = cls()
        obj.__dict__.update(dict)
        return obj


def parse_options(risk_metrics: dict) -> Options:
    from plbpy.utility.string_utils import create_slug

    categories = [
        "Exposure",
        "Sensitivity",
        "HistoricalStress",
        "TransitiveStress",
        "VaR",
    ]
    ignore_keys = ["Position Date", "Value", "IR VOL*0.25"]
    return Options._from_dict(
        {
            k: Options._from_dict(
                {
                    create_slug(k, i): i
                    for i in risk_metrics[k]
                    if i not in ignore_keys
                }
            )
            for k in categories
        }
    )


def parse_segments(risk_metrics: dict) -> Options:
    from plbpy.utility.string_utils import create_slug

    categories = ["Segment"]
    ignore_keys = []
    return Options._from_dict(
        {
            k: Options._from_dict(
                {
                    create_slug(k, i): i
                    for i in risk_metrics[k]
                    if i not in ignore_keys
                }
            )
            for k in categories
        }
    )


def flatten_dict(item, date) -> dict:
    temp_dict = {"Date": date}
    for k in item.keys():
        temp_dict = {**temp_dict, **item[k]}
    return temp_dict

import numpy as np


log_returns = lambda x: np.log(x).diff().fillna(0.0)
ratio_returns = lambda x: np.cumprod(np.e**x)*100

import pandas as pd
def style_df(df: pd.DataFrame, **kwargs):
    def style_negative(v, props=''):
        return props if v!= '-' and float(v) < 0 else None

    def style_positive(v, props=''):
        return props if v!= '-' and float(v) > 0 else None

    highlight = lambda slice_of_df: 'background-color: %s' % 'lightgray'

    styled = df.copy().replace('-',np.nan).astype(float, errors='ignore')
    styled = styled.style.applymap(style_negative, props='color:red;')\
    .applymap(style_positive,props='color:green;').format('{:.2f}',na_rep='-')
    if kwargs.pop('aggregate',False):
        styled.applymap(highlight, subset=pd.IndexSlice[:, 'Aggregate'])

    return styled

price2return = lambda x: np.cumprod(1+x)*100


def style_value(v, **kwargs):
    if isinstance(v, str):
        return None
    else:
        if float(v) < 0:
            return f'color:{kwargs.pop("negative_color", "red")}'
        elif float(v) > 0:
            return f'color:{kwargs.pop("positive_color", "green")}'

def setup_style():
    return None


def style_table(table, **kwargs):
    df = table.copy()
    float_indices = []
    string_indices = []
    for c in df.columns:
        try:
            df[[c]].astype(float)
        except ValueError:
            string_indices.append(c)
        else:
            float_indices.append(c)

    highlight = lambda slice_of_df: 'background-color: %s' % kwargs.pop('highlight_color', 'lightgray')

    if kwargs.pop('color_sign', True):
        df = df.style.applymap(style_value, **kwargs, subset=float_indices)
    else:
        df = df.style

    subset_index = [i for i in float_indices if i not in kwargs.get('no_percent', [])]
    df = df.format('{:.2f} %' if kwargs.pop('space', True) else '{:.2f}%', na_rep='-', subset=subset_index).format('{}',
                                                                                                                   na_rep='-',
                                                                                                                   subset=string_indices).format(
        '{:.2f}', na_rep='-', subset=kwargs.get('no_percent', []))

    headers = {
        'selector': 'th:not(.index_name)',
        'props': 'background-color: #0C1743; color: white; text-align: center;  font-family:Fira Sans',
    }

    index_names = {
        'selector': '.index_name',
        'props': 'font-style: italic; color: darkgrey; font-weight:normal;'
    }

    font = {
        'selector': 'td',
        'props': 'font-family:monospace;'
    }

    df = df.set_table_styles([headers, index_names, font])

    add_line = kwargs.pop('add_line', None)
    if add_line is not None:
        line_kws = kwargs.pop('line_kws', {'left': False, 'right': True})
        for l in add_line:
            if l in table.columns.tolist():
                kws = [k for k, v in line_kws.items() if v]

                if 'right' in kws and 'left' not in kws:
                    td_props = 'border-right:0.5px solid black;'
                    th_props = 'border-right:0.5px solid white;'
                elif 'right' in kws and 'left' in kws:
                    td_props = 'border-right:0.5px solid black;border-left:0.5px solid black;'
                    th_props = 'border-right:0.5px solid white;border-left:0.5px solid white;'
                elif 'right' not in kws and 'left' in kws:
                    td_props = 'border-left:0.5px solid black;'
                    th_props = 'border-left:0.5px solid white;'

                line = {l: [{'selector': 'td', 'props': td_props},
                            {'selector': 'th', 'props': th_props}]}

                df = df.set_table_styles(line, overwrite=False)

            elif l in table.index.tolist():
                line = {l: [{'selector': 'td', 'props': 'border-bottom:0.5px solid black;'},
                            {'selector': 'th', 'props': 'border-bottom: 0.5px solid white'}]}
                df = df.set_table_styles(line, overwrite=False)

    bold = kwargs.pop('bold', None)
    if bold is not None:
        for b in bold:
            bold = {b: [{'selector': 'td', 'props': 'font-weight: bold; text-align:center; font-family:Work Sans'}]}
            df = df.set_table_styles(bold, overwrite=False)

    add_highlight = kwargs.pop('add_highlight', None)
    if add_highlight is not None:
        for ah in add_highlight:
            if ah in table.columns.tolist():
                subset = pd.IndexSlice[:, ah]
            elif ah in table.index.tolist():
                subset = pd.IndexSlice[ah:]
            df = df.applymap(highlight, subset=subset)

    return df

