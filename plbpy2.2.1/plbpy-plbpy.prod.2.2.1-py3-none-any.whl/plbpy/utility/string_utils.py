import json
import re
import numpy as np

str2dict = lambda x: json.loads(x)

import plbpy
code2name = lambda x: plbpy.universe.code(x).data[0]['shortName']
name2code = lambda x: plbpy.universe.short_name(x).codes[0]

# creating risk metric slugs
def create_slug(category, measure):
    slug = "".join(re.split("/", "_".join(re.split("\.| ", measure))))
    if category == 'Exposure':
        slug = slug.replace('(','_').replace('+','_plus_').replace(')','_')
    if category == "HistoricalStress":
        slug = "hs_" + slug.replace("-", "_to_")
    if category == "TransitiveStress":
        slug = (
            slug.replace("+", "plus_")
            .replace("-", "minus_")
            .replace("%", "pct")
            .replace("*", "_times_")
            .replace("&", "_and_")
        )
        slug = slug
    if category == "Sensitivity":
        slug = (
            slug.replace(">", "plus_")
            .replace("[", "_")
            .replace("]", "_")
            .replace("(", "_")
            .replace(")", "_")
        )
    if category == "VaR":
        slug = slug.replace("%", "pct").replace(',','_')
    return slug


flatten = lambda t: [item for sublist in t for item in sublist]


flatten_irregular = (
    lambda irregular_list: [
        element for item in irregular_list for element in flatten_irregular(item)
    ]
    if type(irregular_list) is list
    else [irregular_list]
)

def repeat_list(list1, list2):
    return np.array(list1 * len(list2)).reshape(len(list2), len(list1)).tolist()

def camel_to_snake(name):
    name = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
    return re.sub("([a-z0-9])([A-Z])", r"\1_\2", name).lower()

from typing import Union

def delete_word(shortname): # Shorten the names displayed in the graph
    z = shortname.replace('PLB Pure Factor', '')
    z = z.strip()

    if 'Equity' in z: z = z.replace('Equity ', '')
    if 'Fixed Income' in z: z = z.replace('Fixed Income ', '')
    if 'Commodity' in z: z = z.replace('Commodity ', '')
    if 'Credit' in z: z = z.replace('Credit ', '')
    if 'Foreign Exchange' in z: z = z.replace('Foreign Exchange ', '')
    if 'FX' in z: z = z.replace('FX', '')

    z = z.strip()
    
    if 'US' in z: z = z.replace('US ', '')
    if 'Global' in z: z = z.replace('Global ', '')
    if 'Europe' in z: z = z.replace('Europe ', '')
    if 'Emerging' in z: z = z.replace("Emerging", '')
    
    z=z.strip()
    
    if z == 'Mean Reversion': z = z.replace('Mean Reversion', 'Reversion')
    if z == 'Cross Sectional': z = z.replace('Cross Sectional', 'X Sectional')
    if z == 'Carry Backwardation': z = z.replace('Carry Backwardation', 'Backwardation')
    # if z == 'Carry Dividend': z = z.replace('Carry Dividend', 'Backwardation')

    return z.strip()

def sanitize_metric(metric): #Return words the the first letter being capital letter
    if metric == 'return': return 'Return Ann.(%)'
    if metric == 'returnCum': return 'Return Cum.(%)'
    if metric == 'volatility': return 'Volatility (%)'
    if metric == 'skew': return 'Skew (%)'
    if metric == 'kurtosis': return 'Kurtosis (%)'
    if metric == 'sharpe': return 'Sharpe (%)'
    if metric == 'sortino': return 'Sortino (%)'
    if metric == 'omega': return 'Omega (%)'
    if metric == 'calmar': return 'Calmar (%)'
    if metric == 'var': return 'VaR (%)'
    if metric == 'cvar': return 'CVaR (%)'
    if metric == 'mvar': return 'MVar (%)'
    if metric == 'autocor': return 'Autocor (%)'
    return metric

def to_snake_case(name):

    name = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', name)
    name = re.sub('__([A-Z])', r'_\1', name)
    name = re.sub('([a-z0-9])([A-Z])', r'\1_\2', name)
    return name.lower()

def to_camel_case(snake_str):
    components = snake_str.split('_')
    return components[0] + ''.join(x.title() for x in components[1:])

def compare_str_list(l1 , l2):
    """
    checks if elements of l1 are in l2.
    """
    l1 = set([i.lower() for i in l1])
    l2 = set([j.lower() for j in l2])
    return (l1.issubset(l2))
