import datetime as dt
from datetime import datetime, date
from typing import Any, Callable, Union
from pandas.tseries.holiday import USFederalHolidayCalendar
from pandas.tseries.offsets import *
import calendar


BDayUS = CustomBusinessDay(calendar=USFederalHolidayCalendar())       


def is_business_day(date):
    """
    Checks if passed date is a business date
    """
    return to_date(date) == to_date(date + 0*BDayUS)


def next_business_day(date):
    """
    Returns the next business date. If current date is a business day, returns current date
    """
    return date if is_business_day(to_date(date)) else datetime2str(to_date(date) + 1*BDayUS)


str2datetime: Callable[[Any], Union[datetime, Any]] = (
    lambda x: dt.datetime.strptime(x, "%Y-%m-%d")
    if isinstance(x, str)
    else str2datetime(x.strftime("%Y-%m-%d"))
)


def is_yyyy_mm_dd(date):
    if not isinstance(date, str):
        return False
    else:
        d = date.split('-')
        if len(d)!=3 or len(d[0])!=4 or len(d[1])!=2 or len(d[2])!=2:
            return False

def get_next_bus_pandas(dates):

    fwd = dates.map(lambda x: x + BDay(1))

    return fwd.where(~in_next_month(dates, fwd), dates.map(lambda x: x - BDay(1)))

def payment_day(dates):

    return dates.where(is_weekday(dates), get_next_bus_pandas(dates))


def is_weekday(dates):

    return ~dates.day_name().isin(['Saturday', 'Sunday'])


def is_end_of_month(date):

    return date.day == calendar.monthrange(date.year, date.month)[1]


def in_next_month(dates1, dates2):

    return dates1.month == dates2.month - 1


datetime2str: Callable[[Any], Any] = lambda x: x.strftime("%Y-%m-%d")

to_date: Callable[[Any], date] = lambda x: str2datetime(x).date()

to_datetime: Callable[[Any], Union[datetime, Any]] = lambda x: str2datetime(x)

today: Callable[[], datetime] = lambda: dt.datetime.today()  # noqa: E731

difference = lambda start, end: (end - start).days  # noqa: E731


def to_excel_date(YYYY_MM_DD):
    # Input Date format should be "YYYY-MM-DD"
    base = dt.datetime(1899, 12, 30).date()
    YYYY_MM_DD = YYYY_MM_DD.split("-")
    delta = (
        dt.datetime(int(YYYY_MM_DD[0]), int(YYYY_MM_DD[1]), int(YYYY_MM_DD[2])).date()
        - base
    )

    return int(float(delta.days) + (float(delta.seconds) / 86400))


from_excel_date = lambda excel_date: dt.datetime.fromordinal(
    dt.datetime(1900, 1, 1).toordinal() + excel_date - 2
)

